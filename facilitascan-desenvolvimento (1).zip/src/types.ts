/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface OCRField {
  id: string;
  name: string;
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface PreprocessSettings {
  denoise: boolean;
  contrast: boolean;
  binarize: boolean;
  sharpen: boolean;
  deskew: boolean;
  zoom: number;
}

export interface OCRModel {
  id: string;
  name: string;
  language: string;
  fields: OCRField[];
  templateImage: string; // Data URL or reference
  preprocessSettings?: PreprocessSettings;
  createdAt: number;
}

export interface ExtractionResult {
  id: string;
  fileName: string;
  modelName: string;
  modelId: string;
  date: number;
  data: Record<string, string>;
  status: 'completed' | 'failed';
  fileSize: number;
  fileType: string;
}

export interface UserProfile {
  firstName: string;
  lastName: string;
  email: string;
  whatsapp: string;
  companyName: string;
  companyNif: string;
  companyAddress: string;
  avatar?: string;
  plan: 'Basico' | 'Pro' | 'Empresarial' | 'Gratuito' | 'Trial';
  expiryDate?: number;
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  timestamp: number;
  read: boolean;
  type: 'info' | 'success' | 'warning' | 'error';
}

export interface AppSettings {
  language: string;
  theme: 'light' | 'dark';
  timezone: string;
  dateFormat: string;
  ocr: {
    highQuality: boolean;
    autoLanguage: boolean;
    autoCorrection: boolean;
    preserveFormatting: boolean;
  };
  export: {
    format: 'csv' | 'json' | 'txt';
    delimiter: string;
    includeHeaders: boolean;
  };
  data: {
    retention: number;
    saveActivityHistory: boolean;
  };
}
