import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

const resources = {
  pt: {
    translation: {
      "nav": {
        "dashboard": "Painel",
        "createModel": "Criar Modelo",
        "extract": "Extração",
        "files": "Ficheiros",
        "settings": "Definições",
        "admin": "Painel Admin",
        "profile": "Perfil",
        "notifications": "Notificações",
        "logout": "Sair"
      },
      "common": {
        "loading": "Carregando...",
        "error": "Erro",
        "success": "Sucesso",
        "search": "Pesquisar...",
        "cancel": "Cancelar",
        "confirm": "Confirmar",
        "save": "Guardar",
        "delete": "Eliminar",
        "edit": "Editar",
        "view": "Visualizar",
        "export": "Exportar",
        "invalidCode": "Código incorreto.",
        "backupSuccess": "Backup restaurado com sucesso!",
        "backupError": "Ficheiro de backup inválido.",
        "deleteConfirm": "Tem certeza que deseja excluir esta extração?",
        "bulkView": "Visualizando {{count}} ficheiros.",
        "bulkDelete": "Remover {{count}} itens?",
        "underConstruction": {
            "title": "Página em construção",
            "subtitle": "Lamentamos o inconveniente. Esta funcionalidade está a ser implementada.",
            "back": "Voltar ao Painel"
        }
      },
      "dashboard": {
        "title": "Painel",
        "subtitle": "Visão geral das suas atividades de OCR",
        "trialStatus": "Versão de Teste ({{days}} dias restantes)",
        "trialStatusExpired": "Versão de Teste (Expirada)",
        "modelsCreated": "Modelos Criados",
        "extractionsPerformed": "Extrações Realizadas",
        "filesProcessed": "Arquivos Processados",
        "quickActions": "Ações Rápidas",
        "subscription": "Assinatura",
        "recentFiles": "Arquivos Recentes",
        "noFiles": "Nenhum arquivo processado ainda",
        "clearLicense": "Limpar Licença",
        "test": "Teste",
        "plan": "Plano",
        "extractions": "Extrações",
        "expiry": "Expiração",
        "status": "Status",
        "active": "Ativo",
        "pending": "Pendente/Esgotado",
        "viewAll": "Ver todos",
        "fileDetails": {
          "title": "Detalhes do Arquivo",
          "subtitle": "Informações completas do arquivo selecionado",
          "model": "Modelo",
          "typeFormat": "Tipo/Formato",
          "size": "Tamanho",
          "uploadDate": "Data de upload",
          "status": "Status",
          "completed": "Concluído",
          "failed": "Falhou",
          "description": "Descrição/Observações",
          "jsonResult": "Resultado da extração (JSON)"
        },
        "deleteFile": {
          "title": "Eliminar Arquivo?",
          "confirm": "Tem certeza que deseja excluir permanentemente o arquivo",
          "actionCannotBeUndone": "Esta ação não pode ser desfeita.",
          "confirmAction": "Sim, Eliminar"
        },
        "downloadFile": {
          "title": "Baixar Extração",
          "subtitle": "Selecione o formato desejado para descarregar os dados de"
        },
        "support": {
          "title": "Suporte",
          "help": "Ajuda",
          "tutorials": "Vídeo Tutoriais",
          "customerSupport": "Apoio ao Cliente"
        }
      },
      "admin": {
        "title": "Painel Admin",
        "subtitle": "Visão geral do sistema de licenças",
        "stats": {
          "activeLicenses": "Licenças Ativas",
          "activePlans": "Planos Ativos",
          "issuedLicenses": "Licenças Emitidas",
          "totalRevenue": "Faturamento Total"
        },
        "nav": {
          "dashboard": "Dashboard",
          "clients": "Clientes / Planos",
          "import": "Importar Pedido",
          "generate": "Gerar Licença",
          "history": "Histórico"
        },
        "history": {
          "title": "Últimas Licenças Geradas",
          "subtitle": "Histórico de licenças manuais",
          "clear": "Limpar Histórico",
          "clearConfirm": "Limpar histórico do painel?",
          "noLicenses": "Nenhuma licença gerada ainda",
          "export": "Exportar"
        },
        "import": {
          "subtitle": "Importe um ficheiro .enc para processar o pedido de licença",
          "dropTitle": "Arraste o ficheiro .enc aqui",
          "dropSubtitle": "ou clique para selecionar no computador",
          "ready": "Sistema Pronto"
        },
        "clients": {
          "subtitle": "Gerencie os planos pagos pelos clientes",
          "newClient": "Novo Cliente",
          "clientName": "Nome do Cliente",
          "id": "ID",
          "status": "STATUS",
          "paymentDate": "Desde",
          "activatedLicenses": "Licenças Ativadas",
          "paid": "PAGO",
          "errorName": "Insira o nome do cliente",
          "successPlan": "Plano registado com sucesso!",
          "errorImport": "Erro ao processar arquivo .enc.",
          "errorNoEnc": "Por favor, importe um ficheiro de pedido (.enc) primeiro.",
          "errorNoName": "Por favor, insira o nome do cliente.",
          "errorNoSub": "Subscrição selecionada não encontrada.",
          "errorLimit": "Limite atingido! O plano {{plan}} suporta apenas {{max}} licenças.",
          "isolateConfirm": "Este pedido não está vinculado a nenhum plano pago. Deseja gerar uma licença isolada?",
          "successGen": "Sucesso! Licença gerada e vinculada ao plano.",
          "deleteConfirm": "Tem certeza que deseja eliminar a licença de \"{{client}}\"? Esta ação removerá o registo histórico permanentemente.",
          "deletePlanConfirm": "Tem certeza que deseja eliminar o plano de \"{{client}}\"? Esta ação não removerá as licenças já emitidas, mas impedirá novas ativações para este plano.",
          "deleteSuccess": "Licença eliminada com sucesso.",
          "deletePlanSuccess": "Plano eliminado com sucesso."
        },
        "generate": {
            "title": "Gerar Licença",
            "subtitle": "Preencha os dados e gere a licença encriptada",
            "noImportTitle": "Nenhum pedido importado",
            "noImportDesc": "Importe um ficheiro .enc primeiro na aba \"Importar Pedido\".",
            "readyTitle": "Pedido Importado de {{name}}",
            "readyDesc": "Pronto para gerar licença offline ({{plan}})",
            "validRequest": "PEDIDO VÁLIDO",
            "linkPlan": "Vincular a um Plano Pago (Opcional)",
            "noLink": "-- Gerar Licença Isolada (Sem Vínculo) --",
            "linkHint": "* Se selecionado, contará como uma licença usada no plano do cliente.",
            "formTitle": "Formulário de Licença",
            "clientLabel": "Nome do Cliente",
            "planLabel": "Plano",
            "deviceLabel": "Device Hash",
            "validityLabel": "Validade (meses)",
            "valueLabel": "Valor Unitário",
            "notesLabel": "Notas / Observações (Opcional)",
            "notesPlaceholder": "Ex: Licença nº 001 - Enviada via WhatsApp",
            "clear": "Limpar",
            "action": "Gerar Licença"
        },
        "modals": {
          "details": {
            "title": "Detalhes da Licença",
            "client": "Cliente",
            "plan": "Plano",
            "device": "Dispositivo (Hash)",
            "issuedAt": "Data de Emissão",
            "expiry": "Expiração",
            "notes": "Observações",
            "export": "Exportar Dados"
          },
          "export": {
            "title": "Exportar Licença",
            "subtitle": "Escolha o formato da exportação para o cliente",
            "pdf": "PDF Document",
            "pdfSub": "Formato de Impressão",
            "csv": "Excel / CSV",
            "csvSub": "Planilha de Dados",
            "json": "JSON Raw",
            "jsonSub": "Backup Técnico"
          }
        }
      },
      "license": {
          "gate": {
              "title": "Licença Necessária",
              "subtitle": "Para usar o FacilitaScan, você precisa de uma licença válida. Ative sua licença para continuar.",
              "deviceId": "ID do Dispositivo:",
              "copyId": "Copiar ID",
              "copyIdSuccess": "ID do dispositivo copiado!",
              "startActivation": "Iniciar Ativação (Gerar Pedido)",
              "or": "Ou",
              "activateFile": "Ativar via Ficheiro (.lic)",
              "noLicense": "Não tem uma licença? ",
              "contactAdmin": "Entre em contacto com o administrador.",
              "adminAccess": "Acesso Admin (Dev)",
              "resetLicense": "Limpar Licença / Reset (Teste)"
          },
          "modal": {
              "title": "Activar Plano Licença",
              "offlineProcess": "Processo Offline",
              "offlineDesc": "Siga os 3 passos abaixo para ativar sua licença permanentemente.",
              "step1": "Dados do Pedido",
              "step2": "Enviar ao Administrador",
              "step3": "Importar Licença",
              "plansTitle": "Planos Disponíveis",
              "mostPopular": "Mais Popular",
              "paymentTitle": "Dados para Pagamento",
              "paymentDesc": "Efetue o pagamento via Afrimoney",
              "afrimoney": "Afrimoney:",
              "copy": "COPIAR",
              "beneficiary": "Beneficiário: FACILITASCAN SOLUTIONS LTD",
              "copySuccess": "Número Afrimoney Copiado!",
              "fullName": "Nome Completo *",
              "fullNamePlaceholder": "Seu nome completo",
              "plan": "Plano *",
              "paymentMethod": "Método de Pagamento *",
              "generateRequest": "Gerar Pedido de Licença",
              "hasFile": "Já tem o ficheiro? Ir para ativação",
              "requestSuccess": "Pedido gerado com sucesso!",
              "requestHint": "O ficheiro pedido_licensa.enc foi baixado.",
              "instructionsTitle": "Instruções de Ativação",
              "instr1": "Anexe o ficheiro do Pedido",
              "instr1Sub": "O ficheiro \"pedido_licenca.enc\" que o sistema baixou agora mesmo.",
              "instr2": "Anexe o Comprovativo",
              "instr2Sub": "O talão de transferência Afrimoney efetuado para o nº 951006421.",
              "instr3": "Envie para o Administrador",
              "instr3Sub": "Envie ambos via WhatsApp para 951 006 421.",
              "sendWhatsapp": "Enviar p/ WhatsApp",
              "sendEmail": "Enviar por Email",
              "receivedLicense": "Já recebi a licença",
              "importTitle": "Importar Licença",
              "importSubtitle": "Selecione o ficheiro de licença (.lic) que recebeu do administrador:",
              "clickToSelect": "Clique para selecionar ou arraste o ficheiro",
              "licFiles": "Ficheiros .lic",
              "validating": "Validando Licença...",
              "activateAction": "Ativar Licença",
              "errorName": "Por favor, insira o seu nome."
          }
      },
      "extraction": {
        "title": "Extrair Dados",
        "subtitle": "Extraia informações de documentos usando IA",
        "selectModel": "Selecionar Modelo",
        "chooseModel": "Escolha um modelo...",
        "uploadFiles": "Carregar Arquivo(s)",
        "dropFiles": "Arraste arquivos aqui ou clique para selecionar",
        "filesSelected": "arquivo(s) selecionado(s)",
        "extract": "Começar Extração",
        "processing": "Processando...",
        "result": "Resultado da Extração",
        "preview": "Preview da Imagem",
        "waiting": "Aguardando Processamento",
        "waitingSubtitle": "Configure o modelo e carregue um ficheiro para visualizar os resultados aqui.",
        "limitReached": "Limite Atingido"
      },
      "files": {
        "subtitle": "Gerencie todos os seus arquivos e extrações",
        "filter": "Filtrar",
        "file": "Arquivo",
        "model": "Modelo",
        "date": "Data",
        "actions": "Ações",
        "noResults": "Nenhum resultado encontrado"
      },
      "plans": {
        "title": "Planos e Preços",
        "subtitle": "Escolha o nível de produtividade que sua empresa precisa para crescer",
        "basic": "Básico",
        "pro": "Pro",
        "enterprise": "Enterprise",
        "free": "Gratuito",
        "unlimitedLocal": "Recursos ilimitados localmente",
        "upgrade": "Upgrade",
        "monthly": "mês",
        "startNow": "Começar agora",
        "features": {
          "extractions": "Extrações/mês",
          "models": "Modelos",
          "licenses": "Licenças (PCs)",
          "support": "Suporte",
          "facialLogin": "Login Facial (Biometria)",
          "api": "API + Integrações"
        }
      },
      "notifications": {
        "title": "Notificações",
        "subtitle": "Fique por dentro das últimas actividades do seu app.",
        "markAllRead": "Marcar Todas",
        "clearAll": "Limpar Tudo",
        "clearConfirm": "Deseja eliminar todas as notificações?",
        "filters": {
          "all": "Todas",
          "read": "Lidas",
          "unread": "Não lidas"
        },
        "empty": {
          "title": "Tudo limpo por aqui!",
          "subtitle": "Você não tem notificações nesta categoria."
        },
        "footer": "Fim das notificações",
        "reload": "Recarregar Notificações",
        "close": "Fechar",
        "delete": "Eliminar",
        "types": {
          "expiryWarn": {
            "title": "Aviso de Expiração",
            "message": "A sua licença irá expirar em {{days}} {{unit}}. Renove em breve para não perder o acesso."
          },
          "limitWarn": {
            "title": "Limite de Extrações",
            "message": "Restam apenas {{count}} extrações disponíveis na sua licença atual."
          },
          "modelCreated": {
            "title": "Modelo Criado",
            "message": "O modelo \"{{name}}\" foi salvo com sucesso."
          },
          "extractionSuccess": {
            "title": "Extração Concluída",
            "message": "Dados extraídos de {{name}}."
          },
          "welcome": {
            "title": "Bem-vindo ao FacilitaScan!",
            "message": "Estamos felizes por tê-lo connosco. Comece por criar o seu primeiro modelo ou explore as funcionalidades de extração inteligente."
          },
          "trialActivated": {
            "title": "Versão de Teste Ativada",
            "message": "Aproveite 15 dias de acesso gratuito com todas as funcionalidades. Expira a {{date}}."
          },
          "trialExpired": {
            "title": "Versão de Teste Expirada",
            "message": "O seu período de teste terminou. Adquira uma licença definitiva para continuar a usar o FacilitaScan."
          },
          "modelDeleted": {
            "title": "Modelo Removido",
            "message": "O modelo foi excluído permanentemente."
          }
        }
      },
      "settings": {
        "title": "Configurações",
        "subtitle": "Personalize as configurações do sistema",
        "general": {
          "title": "Preferências Gerais",
          "subtitle": "Configure as funções principais do sistema",
          "language": "Idioma do Sistema",
          "languageHint": "A interface será traduzida automaticamente",
          "timezone": "Fuso Horário",
          "timezoneHint": "Sincronização com o horário local",
          "dateFormat": "Formato de Data",
          "theme": "Tema da Interface",
          "themeHint": "Alternar estética visual do FacilitaScan",
          "light": "Claro",
          "dark": "Escuro"
        },
        "ocr": {
          "title": "OCR Intelligent",
          "subtitle": "Extração avançada de dados",
          "highQuality": "Alta Qualidade",
          "highQualityDesc": "Processamento neural preciso",
          "autoLanguage": "Detecção Automática",
          "autoLanguageDesc": "Identificar idioma nos docs",
          "autoCorrection": "Sugestões de Texto",
          "autoCorrectionDesc": "Corrigir falhas de digitalização",
          "preserveFormatting": "Rigor de Layout",
          "preserveFormattingDesc": "Manter estrutura original"
        },
        "export": {
          "title": "Fluxo de Dados",
          "subtitle": "Configure as opções de exportação",
          "format": "Formato Padrão",
          "delimiter": "Delimitador (CSV)",
          "headers": "Incluir Cabeçalhos",
          "headersDesc": "Títulos das colunas no topo"
        },
        "security": {
          "title": "Segurança de Acesso",
          "subtitle": "Proteja seus dados com PIN local",
          "procedure": "Procedimento de Alteração",
          "currentCode": "Código Atual",
          "newCode": "Novo Código",
          "confirm": "Confirmação",
          "confirmPlaceholder": "Repita o novo código",
          "update": "Atualizar Segurança",
          "riskZone": "Zona de Risco",
          "riskText": "Ao remover o código de acesso, qualquer pessoa com acesso físico ao dispositivo poderá visualizar seus documentos e históricos. Esta ação é irreversível e exige confirmação.",
          "disable": "Desativar Proteção Local"
        },
        "data": {
          "title": "Gestão de Dados",
          "subtitle": "Controle seu armazenamento privado",
          "sovereignty": "Soberania de Dados Garantida",
          "sovereigntyDesc": "Criptografia em repouso e zero latência. Nenhum dado sai deste hardware.",
          "retention": "Políticas de Retenção",
          "retentionHint": "Auto-destruição de arquivos processados",
          "retentionOptions": {
            "30": "Ciclo de 30 dias",
            "90": "Ciclo de 90 dias",
            "365": "Ciclo Anual",
            "0": "Memória Permanente"
          },
          "activity": "Atividade",
          "activityDesc": "Histórico Ativo",
          "backup": "Criar Backup Completo",
          "restore": "Restaurar de Ficheiro",
          "clearAll": "Apagar Todo o Banco de Dados Local"
        },
        "actions": {
          "restoreDefaults": "Restaurar Padrões",
          "save": "Salvar Configurações"
        }
      },
      "help": {
        "title": "Ajuda",
        "subtitle": "Encontre respostas e suporte para usar o aplicativo",
        "faq": "Perguntas Frequentes",
        "channels": {
          "whatsapp": "Suporte rápido via mensagem",
          "email": "Respondemos em até 24 horas",
          "contact": "Contatar",
          "sendEmail": "Enviar Email"
        },
        "questions": {
          "q1": "Como criar um modelo de OCR?",
          "a1": "Acesse Criar Modelo, carregue uma imagem exemplo, desenhe as áreas de extração e confirme cada campo. Depois clique em Salvar Modelo.",
          "q2": "Quais formatos de arquivo são suportados?",
          "a2": "Atualmente o app suporta arquivos de imagem (JPG, PNG). Caso o seu fluxo inclua PDF, recomendamos converter para imagem antes do upload.",
          "q3": "Os meus dados são enviados para algum servidor?",
          "a3": "Não. O processamento acontece localmente no navegador (Tesseract.js) e os modelos/resultados ficam salvos no seu dispositivo (LocalStorage).",
          "q4": "Como exportar os dados extraídos?",
          "a4": "Após a extração, utilize os botões de exportação (JSON/CSV) ou copie rapidamente o resultado. Em Arquivos você também pode baixar os resultados.",
          "q5": "Como ativar um plano offline?",
          "a5": "No popup Activar Plano, selecione a aba Ativação Offline, gere o código do dispositivo e envie via WhatsApp junto do comprovativo para receber o código de resposta.",
          "q6": "A licença continua válida após reiniciar o PC?",
          "a6": "Sim. A licença é armazenada no navegador (LocalStorage) e permanece válida após reiniciar o PC. Apenas precisa de manter o mesmo navegador e não limpar os dados.",
          "q7": "O que invalida a licença?",
          "a7": "Invalidam a licença: Limpar dados do navegador, usar outro navegador, usar outro perfil, reformatar o sistema, ou quando a data de expiração passar. Não invalidam: Reiniciar o PC, fechar e abrir o navegador, ficar horas sem usar.",
          "q8": "Perdi a licença ao limpar dados. Como recupero?",
          "a8": "Guarde sempre o ficheiro de licença (.lic) que recebeu ao activar. Se perder a licença, envie o ficheiro novamente via WhatsApp para que seja reenviado ou activado manualmente."
        }
      },
      "tutorials": {
        "title": "Vídeo Tutoriais",
        "subtitle": "Aprenda a usar o FacilitaScan com nossos tutoriais em vídeo",
        "featured": "Em Destaque",
        "watch": "Assistir",
        "clickToWatch": "Clique para assistir",
        "duration": "Duração",
        "items": {
          "t1": {
            "title": "Primeiros Passos no FacilitaScan",
            "desc": "Visão geral do app: acesso, modelos, extração, exportação e configurações"
          },
          "t2": {
            "title": "Como Ativar a Biometria Facial"
          },
          "t3": {
            "title": "Como Criar um Modelo de OCR"
          },
          "t4": {
            "title": "Como Extrair e Testar Dados"
          },
          "t5": {
            "title": "Ativação Offline e Importação de Licença"
          }
        }
      },
      "about": {
        "title": "Sobre",
        "subtitle": "Informações sobre o aplicativo OCR",
        "tagline": "Facilitando a sua vida com segurança",
        "version": "Versão",
        "offlineTitle": "App 100% Offline",
        "offlineDesc": "O OCR - Extração Inteligente é uma solução moderna e eficiente para digitalização e extração de dados de documentos. Desenvolvido com foco em privacidade e desempenho, o aplicativo funciona 100% offline, garantindo que seus dados permaneçam seguros no seu dispositivo.",
        "featuresTitle": "Principais Funcionalidades",
        "features": {
          "models": "Modelos Personalizados",
          "modelsDesc": "Crie modelos para qualquer tipo de documento",
          "extraction": "Extração Rápida",
          "extractionDesc": "Processamento local de alta velocidade",
          "offline": "100% Offline",
          "offlineDesc": "Funciona sem conexão com internet",
          "formats": "Múltiplos Formatos",
          "formatsDesc": "Exporte para CSV, Excel, JSON e PDF"
        },
        "technical": {
          "title": "Informações Técnicas",
          "appType": "Tipo de Aplicativo",
          "storage": "Armazenamento",
          "compatibility": "Compatibilidade",
          "developer": "Desenvolvedor"
        },
        "copyright": "© 2026 OCR - Extração Inteligente. Todos os direitos reservados.",
        "footer": "FacilitaScan - Interface de OCR e gestão de extrações."
      },
      "createModel": {
        "title": "Criar Modelo de OCR",
        "subtitle": "Defina áreas personalizadas para extração de dados",
        "settings": "Configurações",
        "modelName": "Nome do Modelo",
        "modelNamePlaceholder": "Ex: Fatura de Energia",
        "fieldName": "Nome do Campo",
        "fieldNamePlaceholder": "Ex: Valor Total",
        "confirmArea": "Confirmar Área",
        "instructions": "1. Digite o nome &rarr; 2. Selecione na imagem &rarr; 3. Confirme",
        "language": "Idioma",
        "languages": {
          "pt": "Português",
          "en": "Inglês",
          "es": "Espanhol"
        },
        "templateImage": "Imagem Template",
        "selectFile": "Selecionar Ficheiro",
        "definedFields": "Campos Definidos",
        "testing": "Testando Extração...",
        "test": "Testar Extração",
        "save": "Salvar Modelo",
        "workspace": "Área de Trabalho",
        "previewActive": "PREVIEW ATIVO",
        "selection": "Seleção",
        "move": "Mover",
        "resetView": "Resetar Vista",
        "deleteField": "Eliminar campo",
        "uploadPrompt": "Carregue uma imagem exemplo para começar",
        "dragPrompt": "Arraste para definir as áreas de extração",
        "results": "Resultados da Extração",
        "fieldsExtracted": "CAMPOS EXTRAÍDOS",
        "pending": "Pendente...",
        "errors": {
          "fieldExists": "Já existe um campo com este nome.",
          "ocrFailed": "Falha ao testar OCR.",
          "missingFields": "Por favor, preencha o nome do modelo, carregue uma imagem e adicione pelo menos um campo."
        }
      },
      "profile": {
        "title": "Perfil",
        "subtitle": "Gerencie suas informações e preferências",
        "models": "Modelos",
        "extractions": "Extrações",
        "personalInfo": "Informações Pessoais",
        "firstName": "Nome",
        "lastName": "Sobrenome",
        "firstNamePlaceholder": "Usuário",
        "lastNamePlaceholder": "OCR",
        "email": "Email",
        "whatsapp": "Contacto Whatsapp",
        "updateInfo": "Atualizar Informações",
        "company": "Empresa",
        "companyName": "Nome da Empresa",
        "companyNamePlaceholder": "Ex: TechDoc Solutions",
        "nif": "NIF",
        "nifPlaceholder": "Ex: 123456789",
        "address": "Endereço (Opcional)",
        "addressPlaceholder": "Ex: Luanda, Angola",
        "updateCompany": "Atualizar Empresa",
        "accessCode": "Código de Acesso",
        "currentCode": "Código Actual",
        "newCode": "Novo Código",
        "confirmNewCode": "Confirmar Novo Código",
        "changeCode": "Alterar Código",
        "faceLogin": "Login Facial",
        "biometryActive": "Biometria ativa. Amostras guardadas: 5/5. Sensibilidade:",
        "biometryNone": "Nenhuma biometria configurada. Registre seu rosto para maior segurança.",
        "sensitivity": "Sensibilidade Facial",
        "sensitivityHint": "Mais baixo = mais rigoroso. Mais alto = mais tolerante.",
        "saveSensitivity": "Guardar Sensibilidade",
        "registerFace": "Registar Rosto",
        "clearBiometry": "Limpar Biometria",
        "biometryFooter": "Guarde até 5 amostras do mesmo rosto para melhorar o reconhecimento offline.",
        "removeBiometryTitle": "Remover Biometria?",
        "removeBiometryConfirm": "Tem certeza que deseja remover o acesso facial? Sua segurança será reduzida.",
        "alerts": {
          "faceSuccess": "Biometria facial registada com sucesso!",
          "biometryRemoved": "Biometria removida.",
          "updated": "atualizado com sucesso!"
        }
      }
    }
  },
  en: {
    translation: {
      "nav": {
        "dashboard": "Dashboard",
        "createModel": "Create Model",
        "extract": "Extraction",
        "files": "Files",
        "settings": "Settings",
        "admin": "Admin Panel",
        "profile": "Profile",
        "notifications": "Notifications",
        "logout": "Logout"
      },
      "common": {
        "loading": "Loading...",
        "error": "Error",
        "success": "Success",
        "search": "Search...",
        "cancel": "Cancel",
        "confirm": "Confirm",
        "save": "Save",
        "delete": "Delete",
        "edit": "Edit",
        "view": "View",
        "export": "Export",
        "close": "Close",
        "details": "Details",
        "clear": "Clear",
        "download": "Download",
        "unlimited": "UNLIMITED",
        "invalidCode": "Incorrect code.",
        "backupSuccess": "Backup restored successfully!",
        "backupError": "Invalid backup file.",
        "deleteConfirm": "Are you sure you want to delete this extraction?",
        "bulkView": "Viewing {{count}} files.",
        "bulkDelete": "Remove {{count}} items?",
        "underConstruction": {
            "title": "Page under construction",
            "subtitle": "We apologize for the inconvenience. This feature is being implemented.",
            "back": "Back to Dashboard"
        }
      },
      "dashboard": {
        "title": "Dashboard",
        "subtitle": "Overview of your OCR activities",
        "trialStatus": "Trial Version ({{days}} days remaining)",
        "trialStatusExpired": "Trial Version (Expired)",
        "modelsCreated": "Models Created",
        "extractionsPerformed": "Extractions Performed",
        "filesProcessed": "Files Processed",
        "quickActions": "Quick Actions",
        "subscription": "Subscription",
        "recentFiles": "Recent Files",
        "noFiles": "No files processed yet",
        "clearLicense": "Clear License",
        "test": "Test",
        "plan": "Plan",
        "extractions": "Extractions",
        "expiry": "Expiry",
        "status": "Status",
        "active": "Active",
        "pending": "Pending/Exhausted",
        "viewAll": "View all",
        "total": "Total",
        "fileDetails": {
          "title": "File Details",
          "subtitle": "Full information for the selected file",
          "model": "Model",
          "typeFormat": "Type/Format",
          "size": "Size",
          "uploadDate": "Upload Date",
          "status": "Status",
          "completed": "Completed",
          "failed": "Failed",
          "description": "Description/Notes",
          "jsonResult": "Extraction Result (JSON)"
        },
        "deleteFile": {
          "title": "Delete File?",
          "confirm": "Are you sure you want to permanently delete",
          "actionCannotBeUndone": "This action cannot be undone.",
          "confirmAction": "Yes, Delete"
        },
        "downloadFile": {
          "title": "Download Extraction",
          "subtitle": "Select desired format to download data for"
        },
        "support": {
          "title": "Support",
          "help": "Help",
          "tutorials": "Video Tutorials",
          "customerSupport": "Customer Support"
        }
      },
      "admin": {
        "title": "Admin Panel",
        "subtitle": "Overview of the license system",
        "stats": {
          "activeLicenses": "Active Licenses",
          "activePlans": "Active Plans",
          "issuedLicenses": "Issued Licenses",
          "totalRevenue": "Total Revenue"
        },
        "nav": {
          "dashboard": "Dashboard",
          "clients": "Clients / Plans",
          "import": "Import Request",
          "generate": "Generate License",
          "history": "History"
        },
        "history": {
          "title": "Last Generated Licenses",
          "subtitle": "Manual license history",
          "clear": "Clear History",
          "clearConfirm": "Clear dashboard history?",
          "noLicenses": "No licenses generated yet",
          "export": "Export"
        },
        "import": {
          "subtitle": "Import an .enc file to process the license request",
          "dropTitle": "Drop the .enc file here",
          "dropSubtitle": "or click to select from computer",
          "ready": "System Ready"
        },
        "clients": {
          "subtitle": "Manage plans paid by clients",
          "newClient": "New Client",
          "clientName": "Client Name",
          "id": "ID",
          "status": "STATUS",
          "paymentDate": "Since",
          "activatedLicenses": "Activated Licenses",
          "paid": "PAID",
          "errorName": "Enter client name",
          "successPlan": "Plan registered successfully!",
          "errorImport": "Error processing .enc file.",
          "errorNoEnc": "Please import a request file (.enc) first.",
          "errorNoName": "Please enter client name.",
          "errorNoSub": "Selected subscription not found.",
          "errorLimit": "Limit reached! The {{plan}} plan only supports {{max}} licenses.",
          "isolateConfirm": "This request is not linked to any paid plan. Do you want to generate an isolated license?",
          "successGen": "Success! License generated and linked to plan.",
          "deleteConfirm": "Are you sure you want to delete the license for \"{{client}}\"? This will permanently remove history.",
          "deletePlanConfirm": "Are you sure you want to delete the plan for \"{{client}}\"? This action will not remove already issued licenses, but will prevent new activations for this plan.",
          "deleteSuccess": "License deleted successfully.",
          "deletePlanSuccess": "Plan deleted successfully."
        },
        "generate": {
            "title": "Generate License",
            "subtitle": "Fill in the details and generate the encrypted license",
            "noImportTitle": "No request imported",
            "noImportDesc": "Import an .enc file first in the \"Import Request\" tab.",
            "readyTitle": "Request Imported from {{name}}",
            "readyDesc": "Ready to generate offline license ({{plan}})",
            "validRequest": "VALID REQUEST",
            "linkPlan": "Link to a Paid Plan (Optional)",
            "noLink": "-- Generate Isolated License (No Link) --",
            "linkHint": "* If selected, it will count as a used license in the client's plan.",
            "formTitle": "License Form",
            "clientLabel": "Client Name",
            "planLabel": "Plan",
            "deviceLabel": "Device Hash",
            "validityLabel": "Validity (months)",
            "valueLabel": "Unit Value",
            "notesLabel": "Notes / Observations (Optional)",
            "notesPlaceholder": "Ex: License No. 001 - Sent via WhatsApp",
            "clear": "Clear",
            "action": "Generate License"
        },
        "modals": {
          "details": {
            "title": "License Details",
            "client": "Client",
            "plan": "Plan",
            "device": "Device (Hash)",
            "issuedAt": "Issue Date",
            "expiry": "Expiry",
            "notes": "Notes",
            "export": "Export Data"
          },
          "export": {
            "title": "Export License",
            "subtitle": "Choose export format for client",
            "pdf": "PDF Document",
            "pdfSub": "Print Format",
            "csv": "Excel / CSV",
            "csvSub": "Spreadsheet",
            "json": "JSON Raw",
            "jsonSub": "Technical Backup"
          }
        }
      },
      "license": {
          "gate": {
              "title": "License Required",
              "subtitle": "To use FacilitaScan, you need a valid license. Activate your license to continue.",
              "deviceId": "Device ID:",
              "copyId": "Copy ID",
              "copyIdSuccess": "Device ID copied!",
              "startActivation": "Start Activation (Generate Request)",
              "or": "Or",
              "activateFile": "Activate via File (.lic)",
              "noLicense": "Don't have a license? ",
              "contactAdmin": "Contact the administrator.",
              "adminAccess": "Admin Access (Dev)",
              "resetLicense": "Clear License / Reset (Test)"
          },
          "modal": {
              "title": "Activate License Plan",
              "offlineProcess": "Offline Process",
              "offlineDesc": "Follow the 3 steps below to activate your license permanently.",
              "step1": "Request Details",
              "step2": "Send to Administrator",
              "step3": "Import License",
              "plansTitle": "Available Plans",
              "mostPopular": "Most Popular",
              "paymentTitle": "Payment Details",
              "paymentDesc": "Make payment via Afrimoney",
              "afrimoney": "Afrimoney:",
              "copy": "COPY",
              "beneficiary": "Beneficiary: FACILITASCAN SOLUTIONS LTD",
              "copySuccess": "Afrimoney number copied!",
              "fullName": "Full Name *",
              "fullNamePlaceholder": "Your full name",
              "plan": "Plan *",
              "paymentMethod": "Payment Method *",
              "generateRequest": "Generate License Request",
              "hasFile": "Already have the file? Go to activation",
              "requestSuccess": "Request generated successfully!",
              "requestHint": "The file pedido_licensa.enc was downloaded.",
              "instructionsTitle": "Activation Instructions",
              "instr1": "Attach the Request file",
              "instr1Sub": "The \"pedido_licenca.enc\" file that the system just downloaded.",
              "instr2": "Attach proof of payment",
              "instr2Sub": "The Afrimoney transfer receipt for No. 951006421.",
              "instr3": "Send to Administrator",
              "instr3Sub": "Send both via WhatsApp to 951 006 421.",
              "sendWhatsapp": "Send via WhatsApp",
              "sendEmail": "Send via Email",
              "receivedLicense": "I already received the license",
              "importTitle": "Import License",
              "importSubtitle": "Select the license file (.lic) you received from the administrator:",
              "clickToSelect": "Click to select or drag file",
              "licFiles": "License Files (.lic)",
              "validating": "Validating License...",
              "activateAction": "Activate License",
              "errorName": "Please enter your name."
          }
      },
      "extraction": {
        "title": "Extract Data",
        "subtitle": "Extract information from documents using AI",
        "selectModel": "Select Model",
        "chooseModel": "Choose a model...",
        "uploadFiles": "Upload File(s)",
        "dropFiles": "Drop files here or click to select",
        "filesSelected": "file(s) selected",
        "extract": "Start Extraction",
        "processing": "Processing...",
        "result": "Extraction Result",
        "preview": "Image Preview",
        "waiting": "Waiting for Processing",
        "waitingSubtitle": "Configure the model and upload a file to view results here.",
        "limitReached": "Limit Reached"
      },
      "files": {
        "subtitle": "Manage all your files and extractions",
        "filter": "Filter",
        "file": "File",
        "model": "Model",
        "date": "Date",
        "actions": "Actions",
        "noResults": "No results found"
      },
      "plans": {
        "title": "Plans and Pricing",
        "subtitle": "Choose the level of productivity your company needs to grow",
        "basic": "Basic",
        "pro": "Pro",
        "enterprise": "Enterprise",
        "free": "Free",
        "unlimitedLocal": "Unlimited local resources",
        "upgrade": "Upgrade",
        "monthly": "month",
        "startNow": "Start now",
        "features": {
          "extractions": "Extractions/month",
          "models": "Models",
          "licenses": "Licenses (PCs)",
          "support": "Support",
          "facialLogin": "Facial Login (Biometrics)",
          "api": "API + Integrations"
        }
      },
      "notifications": {
        "title": "Notifications",
        "subtitle": "Stay up to date with the latest activities of your app.",
        "markAllRead": "Mark All as Read",
        "clearAll": "Clear All",
        "clearConfirm": "Do you want to delete all notifications?",
        "filters": {
          "all": "All",
          "read": "Read",
          "unread": "Unread"
        },
        "empty": {
          "title": "All clear here!",
          "subtitle": "You have no notifications in this category."
        },
        "footer": "End of notifications",
        "reload": "Reload Notifications",
        "close": "Close",
        "delete": "Delete",
        "types": {
          "expiryWarn": {
            "title": "Expiration Warning",
            "message": "Your license will expire in {{days}} {{unit}}. Renew soon to keep access."
          },
          "limitWarn": {
            "title": "Extraction Limit",
            "message": "Only {{count}} extractions available in your current license."
          },
          "modelCreated": {
            "title": "Model Created",
            "message": "Model \"{{name}}\" was saved successfully."
          },
          "extractionSuccess": {
            "title": "Extraction Completed",
            "message": "Data extracted from {{name}}."
          },
          "welcome": {
            "title": "Welcome to FacilitaScan!",
            "message": "We're glad to have you here. Start by creating your first model or explore the intelligent extraction features."
          },
          "trialActivated": {
            "title": "Trial Version Activated",
            "message": "Enjoy 15 days of free access with all features. Expires on {{date}}."
          },
          "trialExpired": {
            "title": "Trial Version Expired",
            "message": "Your trial period has ended. Purchase a permanent license to continue using FacilitaScan."
          },
          "modelDeleted": {
            "title": "Model Removed",
            "message": "The model has been permanently deleted."
          }
        }
      },
      "settings": {
        "title": "Settings",
        "subtitle": "Personalize system settings",
        "general": {
          "title": "General Preferences",
          "subtitle": "Configure main system functions",
          "language": "System Language",
          "languageHint": "The interface will be automatically translated",
          "timezone": "Timezone",
          "timezoneHint": "Sync with local time",
          "dateFormat": "Date Format",
          "theme": "Interface Theme",
          "themeHint": "Toggle visual aesthetics of FacilitaScan",
          "light": "Light",
          "dark": "Dark"
        },
        "ocr": {
          "title": "Intelligent OCR",
          "subtitle": "Advanced data extraction",
          "highQuality": "High Quality",
          "highQualityDesc": "Precise neural processing",
          "autoLanguage": "Automatic Detection",
          "autoLanguageDesc": "Identify language in documents",
          "autoCorrection": "Text Suggestions",
          "autoCorrectionDesc": "Fix scanning flaws",
          "preserveFormatting": "Layout Rigor",
          "preserveFormattingDesc": "Maintain original structure"
        },
        "export": {
          "title": "Data Flow",
          "subtitle": "Configure export options",
          "format": "Default Format",
          "delimiter": "Delimiter (CSV)",
          "headers": "Include Headers",
          "headersDesc": "Column titles at the top"
        },
        "security": {
          "title": "Access Security",
          "subtitle": "Protect your data with local PIN",
          "procedure": "Change Procedure",
          "currentCode": "Current Code",
          "newCode": "New Code",
          "confirm": "Confirmation",
          "confirmPlaceholder": "Repeat the new code",
          "update": "Update Security",
          "riskZone": "Risk Zone",
          "riskText": "By removing the access code, anyone with physical access to the device will be able to view your documents and history. This action is irreversible and requires confirmation.",
          "disable": "Disable Local Protection"
        },
        "data": {
          "title": "Data Management",
          "subtitle": "Control your private storage",
          "sovereignty": "Guaranteed Data Sovereignty",
          "sovereigntyDesc": "Encryption at rest and zero latency. No data leaves this hardware.",
          "retention": "Retention Policies",
          "retentionHint": "Auto-destruction of processed files",
          "retentionOptions": {
            "30": "30-day cycle",
            "90": "90-day cycle",
            "365": "Annual cycle",
            "0": "Permanent Memory"
          },
          "activity": "Activity",
          "activityDesc": "Active History",
          "backup": "Create Full Backup",
          "restore": "Restore from File",
          "clearAll": "Delete All Local Database"
        },
        "actions": {
          "restoreDefaults": "Restore Defaults",
          "save": "Save Settings"
        }
      },
      "help": {
        "title": "Help",
        "subtitle": "Find answers and support for using the app",
        "faq": "Frequently Asked Questions",
        "channels": {
          "whatsapp": "Quick support via message",
          "email": "We respond within 24 hours",
          "contact": "Contact",
          "sendEmail": "Send Email"
        },
        "questions": {
          "q1": "How to create an OCR model?",
          "a1": "Go to Create Model, upload a sample image, draw extraction areas and confirm each field. Then click Save Model.",
          "q2": "Which file formats are supported?",
          "a2": "Currently the app supports image files (JPG, PNG). If your workflow includes PDF, we recommend converting to image before upload.",
          "q3": "Is my data sent to any server?",
          "a3": "No. Processing happens locally in the browser (Tesseract.js) and models/results are saved on your device (LocalStorage).",
          "q4": "How to export extracted data?",
          "a4": "After extraction, use export buttons (JSON/CSV) or quickly copy the result. In Files you can also download results.",
          "q5": "How to activate an offline plan?",
          "a5": "In the Activate Plan popup, select the Offline Activation tab, generate device code and send via WhatsApp with proof of payment to receive response code.",
          "q6": "Does the license remain valid after restarting the PC?",
          "a6": "Yes. License is stored in the browser (LocalStorage) and remains valid after restarting. You just need to keep same browser and not clear data.",
          "q7": "What invalidates the license?",
          "a7": "Invalidates license: Clearing browser data, using another browser, using another profile, reformatting system, or when expiry date passes. Doesn't invalidate: Restarting PC, closing and opening browser, staying hours without use.",
          "q8": "I lost license by clearing data. How do I recover?",
          "a8": "Always keep license file (.lic) received upon activation. If you lose license, send file again via WhatsApp so it can be resent or manually activated."
        }
      },
      "tutorials": {
        "title": "Video Tutorials",
        "subtitle": "Learn how to use FacilitaScan with our video tutorials",
        "featured": "Featured",
        "watch": "Watch",
        "clickToWatch": "Click to watch",
        "duration": "Duration",
        "items": {
          "t1": {
            "title": "First Steps in FacilitaScan",
            "desc": "App overview: access, models, extraction, export and settings"
          },
          "t2": {
            "title": "How to Activate Face Biometrics"
          },
          "t3": {
            "title": "How to Create an OCR Model"
          },
          "t4": {
            "title": "How to Extract and Test Data"
          },
          "t5": {
            "title": "Offline Activation and License Import"
          }
        }
      },
      "about": {
        "title": "About",
        "subtitle": "Information about the OCR app",
        "tagline": "Facilitating your life with security",
        "version": "Version",
        "offlineTitle": "100% Offline App",
        "offlineDesc": "OCR - Intelligent Extraction is a modern and efficient solution for scanning and data extraction from documents. Developed with a focus on privacy and performance, the app works 100% offline, ensuring your data remains secure on your device.",
        "featuresTitle": "Main Features",
        "features": {
          "models": "Custom Models",
          "modelsDesc": "Create models for any type of document",
          "extraction": "Fast Extraction",
          "extractionDesc": "High-speed local processing",
          "offline": "100% Offline",
          "offlineDesc": "Works without internet connection",
          "formats": "Multiple Formats",
          "formatsDesc": "Export to CSV, Excel, JSON and PDF"
        },
        "technical": {
          "title": "Technical Information",
          "appType": "App Type",
          "storage": "Storage",
          "compatibility": "Compatibility",
          "developer": "Developer"
        },
        "copyright": "© 2026 OCR - Intelligent Extraction. All rights reserved.",
        "footer": "FacilitaScan - OCR interface and extraction management."
      },
      "createModel": {
        "title": "Create OCR Model",
        "subtitle": "Define custom areas for data extraction",
        "settings": "Settings",
        "modelName": "Model Name",
        "modelNamePlaceholder": "Ex: Energy Invoice",
        "fieldName": "Field Name",
        "fieldNamePlaceholder": "Ex: Total Amount",
        "confirmArea": "Confirm Area",
        "instructions": "1. Type name &rarr; 2. Select on image &rarr; 3. Confirm",
        "language": "Language",
        "languages": {
          "pt": "Portuguese",
          "en": "English",
          "es": "Spanish"
        },
        "templateImage": "Template Image",
        "selectFile": "Select File",
        "definedFields": "Defined Fields",
        "testing": "Testing Extraction...",
        "test": "Test Extraction",
        "save": "Save Model",
        "workspace": "Workspace",
        "previewActive": "PREVIEW ACTIVE",
        "selection": "Selection",
        "move": "Move",
        "resetView": "Reset View",
        "deleteField": "Delete field",
        "uploadPrompt": "Upload a sample image to start",
        "dragPrompt": "Drag to define extraction areas",
        "results": "Extraction Results",
        "fieldsExtracted": "FIELDS EXTRACTED",
        "pending": "Pending...",
        "errors": {
          "fieldExists": "A field with this name already exists.",
          "ocrFailed": "Failed to test OCR.",
          "missingFields": "Please enter model name, upload an image and add at least one field."
        }
      },
      "profile": {
        "title": "Profile",
        "subtitle": "Manage your information and preferences",
        "models": "Models",
        "extractions": "Extractions",
        "personalInfo": "Personal Information",
        "firstName": "First Name",
        "lastName": "Last Name",
        "firstNamePlaceholder": "User",
        "lastNamePlaceholder": "OCR",
        "email": "Email",
        "whatsapp": "Whatsapp Contact",
        "updateInfo": "Update Information",
        "company": "Company",
        "companyName": "Company Name",
        "companyNamePlaceholder": "Ex: TechDoc Solutions",
        "nif": "NIF",
        "nifPlaceholder": "Ex: 123456789",
        "address": "Address (Optional)",
        "addressPlaceholder": "Ex: Luanda, Angola",
        "updateCompany": "Update Company",
        "accessCode": "Access Code",
        "currentCode": "Current Code",
        "newCode": "New Code",
        "confirmNewCode": "Confirm New Code",
        "changeCode": "Change Code",
        "faceLogin": "Face Login",
        "biometryActive": "Biometry active. Saved samples: 5/5. Sensitivity:",
        "biometryNone": "No biometry configured. Register your face for better security.",
        "sensitivity": "Face Sensitivity",
        "sensitivityHint": "Lower = stricter. Higher = more tolerant.",
        "saveSensitivity": "Save Sensitivity",
        "registerFace": "Register Face",
        "clearBiometry": "Clear Biometry",
        "biometryFooter": "Save up to 5 samples of the same face to improve offline recognition.",
        "removeBiometryTitle": "Remove Biometry?",
        "removeBiometryConfirm": "Are you sure you want to remove face access? Your security will be reduced.",
        "alerts": {
          "faceSuccess": "Face biometry registered successfully!",
          "biometryRemoved": "Biometry removed.",
          "updated": "successfully updated!"
        }
      }
    }
  },
  fr: {
    translation: {
      "nav": {
        "dashboard": "Tableau de Bord",
        "createModel": "Créer un Modèle",
        "extract": "Extraction",
        "files": "Fichiers",
        "settings": "Paramètres",
        "admin": "Panneau d'Administration",
        "profile": "Profil",
        "logout": "Déconnexion"
      },
      "common": {
        "loading": "Chargement...",
        "error": "Erreur",
        "success": "Succès",
        "search": "Rechercher...",
        "cancel": "Annuler",
        "confirm": "Confirmer",
        "save": "Enregistrer",
        "delete": "Supprimer",
        "edit": "Modifier",
        "view": "Voir",
        "export": "Exporter",
        "close": "Fermer",
        "details": "Détails",
        "clear": "Effacer",
        "download": "Télécharger",
        "unlimited": "ILLIMITÉ",
        "invalidCode": "Code incorrect.",
        "backupSuccess": "Sauvegarde restaurée avec succès !",
        "backupError": "Fichier de sauvegarde invalide.",
        "deleteConfirm": "Êtes-vous sûr de vouloir supprimer cette extraction ?",
        "bulkView": "Visualisation de {{count}} fichiers.",
        "bulkDelete": "Supprimer {{count}} éléments ?",
        "underConstruction": {
            "title": "Page en construction",
            "subtitle": "Nous nous excusons pour le désagrément. Cette fonctionnalité est en cours d'implémentation.",
            "back": "Retour au Tableau de Bord"
        }
      },
      "dashboard": {
        "title": "Tableau de Bord",
        "subtitle": "Aperçu de vos activités OCR",
        "modelsCreated": "Modèles Créés",
        "extractionsPerformed": "Extractions Effectuées",
        "filesProcessed": "Fichiers Traités",
        "quickActions": "Actions Rapides",
        "subscription": "Abonnement",
        "recentFiles": "Fichiers Récents",
        "noFiles": "Aucun fichier traité pour le moment",
        "clearLicense": "Effacer la licence",
        "test": "Test",
        "plan": "Plan",
        "extractions": "Extractions",
        "expiry": "Expiration",
        "status": "Statut",
        "active": "Actif",
        "pending": "En attente/Epuisé",
        "viewAll": "Voir tout",
        "total": "Total",
        "fileDetails": {
          "title": "Détails du Fichier",
          "subtitle": "Informations complètes pour le fichier sélectionné",
          "model": "Modèle",
          "typeFormat": "Type/Format",
          "size": "Taille",
          "uploadDate": "Date de téléchargement",
          "status": "Statut",
          "completed": "Terminé",
          "failed": "Échoué",
          "description": "Description/Notes",
          "jsonResult": "Résultat de l'extraction (JSON)"
        },
        "deleteFile": {
          "title": "Supprimer le fichier ?",
          "confirm": "Êtes-vous sûr de vouloir supprimer définitivement",
          "actionCannotBeUndone": "Cette action est irréversible.",
          "confirmAction": "Oui, Supprimer"
        },
        "downloadFile": {
          "title": "Télécharger l'extraction",
          "subtitle": "Sélectionnez le format souhaité pour télécharger les données de"
        },
        "support": {
          "title": "Support",
          "help": "Aide",
          "tutorials": "Tutoriels Vidéo",
          "customerSupport": "Service Client"
        }
      },
      "admin": {
        "title": "Panneau d'administration",
        "subtitle": "Aperçu du système de licence",
        "stats": {
          "activeLicenses": "Licences Actives",
          "activePlans": "Plans Actifs",
          "issuedLicenses": "Licences Émises",
          "totalRevenue": "Chiffre d'Affaires Total"
        },
        "nav": {
          "dashboard": "Tableau de bord",
          "clients": "Clients / Plans",
          "import": "Importer Demande",
          "generate": "Générer Licence",
          "history": "Historique"
        },
        "history": {
          "title": "Dernières Licences Générées",
          "subtitle": "Historique manuel des licences",
          "clear": "Effacer l'historique",
          "clearConfirm": "Effacer l'historique du tableau de bord ?",
          "noLicenses": "Aucune licence générée pour le moment",
          "export": "Exporter"
        },
        "import": {
          "subtitle": "Importer un fichier .enc pour traiter la demande de licence",
          "dropTitle": "Déposez le fichier .enc ici",
          "dropSubtitle": "ou cliquez pour sélectionner sur l'ordinateur",
          "ready": "Système Prêt"
        },
        "clients": {
          "subtitle": "Gérer les forfaits payés par les clients",
          "newClient": "Nouveau Client",
          "clientName": "Nom du Client",
          "id": "ID",
          "status": "STATUT",
          "paymentDate": "Depuis",
          "activatedLicenses": "Licences Activées",
          "paid": "PAYÉ",
          "errorName": "Entrez le nom du client",
          "successPlan": "Plan enregistré avec succès !",
          "errorImport": "Erreur lors du traitement du fichier .enc.",
          "errorNoEnc": "Veuillez d'abord importer un fichier de demande (.enc).",
          "errorNoName": "Veuillez entrer le nom du client.",
          "errorNoSub": "Abonnement sélectionné introuvable.",
          "errorLimit": "Limite atteinte ! Le plan {{plan}} ne prend en charge que {{max}} licences.",
          "isolateConfirm": "Cette demande n'est liée à aucun plan payant. Voulez-vous générer une licence isolée ?",
          "successGen": "Succès ! Licence générée et liée au plan.",
          "deleteConfirm": "Êtes-vous sûr de vouloir supprimer la licence de \"{{client}}\" ? Cela supprimera définitivement l'historique.",
          "deleteSuccess": "Licence supprimée avec succès."
        },
        "generate": {
            "title": "Générer une Licence",
            "subtitle": "Remplissez les détails et gérez la licence cryptée",
            "noImportTitle": "Aucune demande importée",
            "noImportDesc": "Importez d'abord un fichier .enc dans l'onglet \"Importer Demande\".",
            "readyTitle": "Demande importée de {{name}}",
            "readyDesc": "Prêt à générer une licence hors ligne ({{plan}})",
            "validRequest": "DEMANDE VALIDE",
            "linkPlan": "Lier à un plan payant (Optionnel)",
            "noLink": "-- Générer une licence isolée (sans lien) --",
            "linkHint": "* Si sélectionné, cela comptera comme une licence utilisée dans le plan du client.",
            "formTitle": "Formulaire de Licence",
            "clientLabel": "Nom du Client",
            "planLabel": "Plan",
            "deviceLabel": "Hash de l'appareil",
            "validityLabel": "Validité (mois)",
            "valueLabel": "Valeur Unitaire",
            "notesLabel": "Notes / Observations (Optionnel)",
            "notesPlaceholder": "Ex: Licence n° 001 - Envoyée via WhatsApp",
            "clear": "Effacer",
            "action": "Générer la Licence"
        },
        "modals": {
          "details": {
            "title": "Détails de la Licence",
            "client": "Client",
            "plan": "Plan",
            "device": "Appareil (Hash)",
            "issuedAt": "Date d'Émission",
            "expiry": "Expiration",
            "notes": "Notes",
            "export": "Exporter les Données"
          },
          "export": {
            "title": "Exporter la Licence",
            "subtitle": "Choisissez le format d'exportation pour le client",
            "pdf": "Document PDF",
            "pdfSub": "Format d'Impression",
            "csv": "Excel / CSV",
            "csvSub": "Feuille de Calcul",
            "json": "JSON Brut",
            "jsonSub": "Sauvegarde Technique"
          }
        }
      },
      "license": {
          "gate": {
              "title": "Licence Requise",
              "subtitle": "Pour utiliser FacilitaScan, vous avez besoin d'une licence valide. Activez votre licence pour continuer.",
              "deviceId": "ID de l'appareil :",
              "copyId": "Copier l'ID",
              "copyIdSuccess": "ID de l'appareil copié !",
              "startActivation": "Démarrer l'activation (Générer une demande)",
              "or": "Ou",
              "activateFile": "Activer via Fichier (.lic)",
              "noLicense": "Vous n'avez pas de licence ? ",
              "contactAdmin": "Contactez l'administrateur.",
              "adminAccess": "Accès Admin (Dev)",
              "resetLicense": "Effacer la licence / Réinitialiser (Test)"
          },
          "modal": {
              "title": "Activer le Forfait de Licence",
              "offlineProcess": "Processus Hors Ligne",
              "offlineDesc": "Suivez les 3 étapes ci-dessous pour activer votre licence de manière permanente.",
              "step1": "Détails de la demande",
              "step2": "Envoyer à l'administrateur",
              "step3": "Importer la licence",
              "plansTitle": "Plans Disponibles",
              "mostPopular": "Le plus populaire",
              "paymentTitle": "Détails du paiement",
              "paymentDesc": "Effectuez le paiement via Afrimoney",
              "afrimoney": "Afrimoney :",
              "copy": "COPIER",
              "beneficiary": "Bénéficiaire : FACILITASCAN SOLUTIONS LTD",
              "copySuccess": "Numéro Afrimoney copié !",
              "fullName": "Nom Complet *",
              "fullNamePlaceholder": "Votre nom complet",
              "plan": "Plan *",
              "paymentMethod": "Mode de Paiement *",
              "generateRequest": "Générer une demande de licence",
              "hasFile": "Vous avez déjà le fichier ? Aller à l'activation",
              "requestSuccess": "Demande générée avec succès !",
              "requestHint": "Le fichier pedido_licensa.enc a été téléchargé.",
              "instructionsTitle": "Instructions d'activation",
              "instr1": "Joindre le fichier de demande",
              "instr1Sub": "Le fichier \"pedido_licenca.enc\" que le système vient de télécharger.",
              "instr2": "Joindre la preuve de paiement",
              "instr2Sub": "Le reçu de transfert Afrimoney pour le n° 951006421.",
              "instr3": "Envoyer à l'administrateur",
              "instr3Sub": "Envoyer les deux via WhatsApp au 951 006 421.",
              "sendWhatsapp": "Envoyer par WhatsApp",
              "sendEmail": "Envoyer par Email",
              "receivedLicense": "J'ai déjà reçu la licence",
              "importTitle": "Importer la licence",
              "importSubtitle": "Sélectionnez le fichier de licence (.lic) que vous avez reçu de l'administrateur :",
              "clickToSelect": "Cliquez pour sélectionner ou faites glisser le fichier",
              "licFiles": "Fichiers de licence (.lic)",
              "validating": "Validation de la licence...",
              "activateAction": "Activer la licence",
              "errorName": "Veuillez entrer votre nom."
          }
      },
      "extraction": {
        "title": "Extraire des Données",
        "subtitle": "Extraire des informations de documents à l'aide de l'IA",
        "selectModel": "Sélectionner le Modèle",
        "chooseModel": "Choisir un modèle...",
        "uploadFiles": "Charger le(s) fichier(s)",
        "dropFiles": "Déposez les fichiers ici ou cliquez pour sélectionner",
        "filesSelected": "fichier(s) sélectionné(s)",
        "extract": "Démarrer l'extraction",
        "processing": "Traitement...",
        "result": "Résultat de l'extraction",
        "preview": "Aperçu de l'image",
        "waiting": "En attente de traitement",
        "waitingSubtitle": "Configurez le modèle et téléchargez un fichier pour voir les résultats ici.",
        "limitReached": "Limite Atteinte"
      },
      "files": {
        "subtitle": "Gérez tous vos fichiers et extractions",
        "filter": "Filtrer",
        "file": "Fichier",
        "model": "Modèle",
        "date": "Date",
        "actions": "Actions",
        "noResults": "Aucun résultat trouvé"
      },
      "plans": {
        "title": "Plans et Tarifs",
        "subtitle": "Choisissez le niveau de productivité dont votre entreprise a besoin pour croître",
        "basic": "Basique",
        "pro": "Pro",
        "enterprise": "Entreprise",
        "free": "Gratuit",
        "unlimitedLocal": "Ressources locales illimitées",
        "upgrade": "Mettre à niveau",
        "monthly": "mois",
        "startNow": "Commencer maintenant",
        "features": {
          "extractions": "Extractions/mois",
          "models": "Modèles",
          "licenses": "Licences (PCs)",
          "support": "Support",
          "facialLogin": "Connexion Faciale (Biométrie)",
          "api": "API + Intégrations"
        }
      },
      "notifications": {
        "title": "Notifications",
        "subtitle": "Restez informé des dernières activités de votre application.",
        "markAllRead": "Tout marquer comme lu",
        "clearAll": "Tout effacer",
        "clearConfirm": "Voulez-vous supprimer toutes les notifications ?",
        "filters": {
          "all": "Toutes",
          "read": "Lues",
          "unread": "Non lues"
        },
        "empty": {
          "title": "Tout est propre ici !",
          "subtitle": "Vous n'avez aucune notification dans cette catégorie."
        },
        "footer": "Fin des notifications",
        "reload": "Recharger les notifications",
        "close": "Fermer",
        "delete": "Supprimer",
        "types": {
          "expiryWarn": {
            "title": "Avertissement d'expiration",
            "message": "Votre licence expirera dans {{days}} {{unit}}. Renouvelez-la bientôt pour conserver l'accès."
          },
          "limitWarn": {
            "title": "Limite d'extraction",
            "message": "Seulement {{count}} extractions disponibles dans votre licence actuelle."
          },
          "modelCreated": {
            "title": "Modèle Créé",
            "message": "Le modèle \"{{name}}\" a été enregistré avec succès."
          },
          "extractionSuccess": {
            "title": "Extraction Terminée",
            "message": "Données extraites de {{name}}."
          },
          "modelDeleted": {
            "title": "Modèle Supprimé",
            "message": "Le modèle a été supprimé définitivement."
          }
        }
      },
      "settings": {
        "title": "Paramètres",
        "subtitle": "Personnalisez les paramètres du système",
        "general": {
          "title": "Préférences Générales",
          "subtitle": "Configurez les fonctions principales du système",
          "language": "Langue du Système",
          "languageHint": "L'interface sera automatiquement traduite",
          "timezone": "Fuseau Horaire",
          "timezoneHint": "Synchronisation avec l'heure locale",
          "dateFormat": "Format de Date",
          "theme": "Thème de l'Interface",
          "themeHint": "Basculer l'esthétique visuelle de FacilitaScan",
          "light": "Clair",
          "dark": "Sombre"
        },
        "ocr": {
          "title": "OCR Intelligent",
          "subtitle": "Extraction de données avancée",
          "highQuality": "Haute Qualité",
          "highQualityDesc": "Traitement neural précis",
          "autoLanguage": "Détection Automatique",
          "autoLanguageDesc": "Identifier la langue dans les documents",
          "autoCorrection": "Suggestions de Texte",
          "autoCorrectionDesc": "Corriger les défauts de numérisation",
          "preserveFormatting": "Rigueur de Mise en Page",
          "preserveFormattingDesc": "Maintenir la structure originale"
        },
        "export": {
          "title": "Flux de Données",
          "subtitle": "Configurer les options d'exportation",
          "format": "Format par Défaut",
          "delimiter": "Délimiteur (CSV)",
          "headers": "Inclure les En-têtes",
          "headersDesc": "Titres des colonnes en haut"
        },
        "security": {
          "title": "Sécurité d'Accès",
          "subtitle": "Protégez vos données avec un PIN local",
          "procedure": "Procédure de Modification",
          "currentCode": "Code Actuel",
          "newCode": "Nouveau Code",
          "confirm": "Confirmation",
          "confirmPlaceholder": "Répétez le nouveau code",
          "update": "Mettre à jour la sécurité",
          "riskZone": "Zone de Risque",
          "riskText": "En supprimant le code d'accès, toute personne ayant un accès physique à l'appareil pourra consulter vos documents et votre historique. Cette action est irréversible et nécessite une confirmation.",
          "disable": "Désactiver la Protection Locale"
        },
        "data": {
          "title": "Gestion des Données",
          "subtitle": "Contrôlez votre stockage privé",
          "sovereignty": "Souveraineté des Données Garantie",
          "sovereigntyDesc": "Cryptage au repos et latence zéro. Aucune donnée ne quitte ce matériel.",
          "retention": "Politiques de Rétention",
          "retentionHint": "Auto-destruction des fichiers traités",
          "retentionOptions": {
            "30": "Cycle de 30 jours",
            "90": "Cycle de 90 jours",
            "365": "Cycle Annuel",
            "0": "Mémoire Permanente"
          },
          "activity": "Activité",
          "activityDesc": "Historique Actif",
          "backup": "Créer une Sauvegarde Complète",
          "restore": "Restaurer à partir d'un fichier",
          "clearAll": "Supprimer toute la base de données locale"
        },
        "actions": {
          "restoreDefaults": "Restaurer les Valeurs par Défaut",
          "save": "Enregistrer les Paramètres"
        }
      },
      "help": {
        "title": "Aide",
        "subtitle": "Trouvez des réponses et de l'aide pour utiliser l'application",
        "faq": "Foire Aux Questions",
        "channels": {
          "whatsapp": "Support rapide via message",
          "email": "Nous répondons sous 24 heures",
          "contact": "Contacter",
          "sendEmail": "Envoyer un Email"
        },
        "questions": {
          "q1": "Comment créer un modèle OCR ?",
          "a1": "Allez dans Créer un Modèle, téléchargez une image exemple, dessinez les zones d'extraction et confirmez chaque champ. Cliquez ensuite sur Enregistrer le Modèle.",
          "q2": "Quels formats de fichiers sont pris en charge ?",
          "a2": "Actuellement, l'application prend en charge les fichiers image (JPG, PNG). Si votre flux inclut des PDF, nous vous recommandons de les convertir en image avant le téléchargement.",
          "q3": "Mes données sont-elles envoyées vers un serveur ?",
          "a3": "Non. Le traitement s'effectue localement dans le navigateur (Tesseract.js) et les modèles/résultats sont enregistrés sur votre appareil (LocalStorage).",
          "q4": "Comment exporter les données extraites ?",
          "a4": "Après l'extraction, utilisez les boutons d'exportation (JSON/CSV) ou copiez rapidement le résultat. Dans Fichiers, vous pouvez également télécharger les résultats.",
          "q5": "Comment activer un forfait hors ligne ?",
          "a5": "Dans la fenêtre Activer le forfait, sélectionnez l'onglet Activation Hors Ligne, générez le code de l'appareil et envoyez-le via WhatsApp avec la preuve de paiement pour recevoir le code de réponse.",
          "q6": "La licence reste-t-elle valide après le redémarrage du PC ?",
          "a6": "Oui. La licence est stockée dans le navigateur (LocalStorage) et reste valide après le redémarrage. Vous devez simplement conserver le même navigateur et ne pas effacer les données.",
          "q7": "Qu'est-ce qui invalide la licence ?",
          "a7": "Invalident la licence : Effacer les données du navigateur, utiliser un autre navigateur, utiliser un autre profil, reformater le système, ou lorsque la date d'expiration est passée. N'invalident pas : Redémarrer le PC, fermer et ouvrir le navigateur, rester des heures sans utilisation.",
          "q8": "J'ai perdu ma licence en effaçant les données. Comment la récupérer ?",
          "a8": "Conservez toujours le fichier de licence (.lic) reçu lors de l'activation. Si vous perdez la licence, envoyez à nouveau le fichier via WhatsApp pour qu'il soit renvoyé ou activé manuellement."
        }
      },
      "tutorials": {
        "title": "Tutoriels Vidéo",
        "subtitle": "Apprenez à utiliser FacilitaScan avec nos tutoriels vidéo",
        "featured": "En Vedette",
        "watch": "Regarder",
        "clickToWatch": "Cliquez pour regarder",
        "duration": "Durée",
        "items": {
          "t1": {
            "title": "Premiers pas dans FacilitaScan",
            "desc": "Aperçu de l'application : accès, modèles, extraction, exportation et paramètres"
          },
          "t2": {
            "title": "Comment activer la biométrie faciale"
          },
          "t3": {
            "title": "Comment créer un modèle OCR"
          },
          "t4": {
            "title": "Comment extraire et tester des données"
          },
          "t5": {
            "title": "Activation hors ligne et importation de licence"
          }
        }
      },
      "about": {
        "title": "À Propos",
        "subtitle": "Informations sur l'application OCR",
        "tagline": "Faciliter votre vie avec sécurité",
        "version": "Version",
        "offlineTitle": "Application 100% Hors Ligne",
        "offlineDesc": "OCR - Extraction Intelligente est une solution moderne et efficace pour la numérisation et l'extraction de données à partir de documents. Développée avec un accent sur la confidentialité et la performance, l'application fonctionne à 100% hors ligne, garantissant que vos données restent en sécurité sur votre appareil.",
        "featuresTitle": "Caractéristiques Principales",
        "features": {
          "models": "Modèles Personnalisés",
          "modelsDesc": "Créez des modèles pour tout type de document",
          "extraction": "Extraction Rapide",
          "extractionDesc": "Traitement local à haute vitesse",
          "offline": "100% Hors Ligne",
          "offlineDesc": "Fonctionne sans connexion Internet",
          "formats": "Plusieurs Formats",
          "formatsDesc": "Exportez vers CSV, Excel, JSON et PDF"
        },
        "technical": {
          "title": "Informations Techniques",
          "appType": "Type d'Application",
          "storage": "Stockage",
          "compatibility": "Compatibilité",
          "developer": "Développeur"
        },
        "copyright": "© 2026 OCR - Extraction Intelligente. Tous droits réservés.",
        "footer": "FacilitaScan - Interface OCR et gestion des extractions."
      },
      "createModel": {
        "title": "Créer um Modèle OCR",
        "subtitle": "Définir des zones personnalisées pour l'extraction de données",
        "settings": "Paramètres",
        "modelName": "Nom du Modèle",
        "modelNamePlaceholder": "Ex: Facture d'énergie",
        "fieldName": "Nom du Champ",
        "fieldNamePlaceholder": "Ex: Montant Total",
        "confirmArea": "Confirmer la Zone",
        "instructions": "1. Saisissez le nom &rarr; 2. Sélectionnez sur l'image &rarr; 3. Confirmez",
        "language": "Langue",
        "languages": {
          "pt": "Portugais",
          "en": "Anglais",
          "es": "Espagnol"
        },
        "templateImage": "Image Modèle",
        "selectFile": "Sélectionner un fichier",
        "definedFields": "Champs Définis",
        "testing": "Test d'extraction...",
        "test": "Tester l'extraction",
        "save": "Enregistrer le Modèle",
        "workspace": "Espace de Travail",
        "previewActive": "PREVIEW ACTIF",
        "selection": "Sélection",
        "move": "Déplacer",
        "resetView": "Réinitialiser la vue",
        "deleteField": "Supprimer le champ",
        "uploadPrompt": "Chargez une image exemple pour commencer",
        "dragPrompt": "Faites glisser pour définir les zones d'extraction",
        "results": "Résultats de l'Extraction",
        "fieldsExtracted": "CHAMPS EXTRAITS",
        "pending": "En attente...",
        "errors": {
          "fieldExists": "Un champ avec ce nom existe déjà.",
          "ocrFailed": "Échec du test OCR.",
          "missingFields": "Veuillez saisir le nom du modèle, charger une image et ajouter au moins un champ."
        }
      },
      "profile": {
        "title": "Profil",
        "subtitle": "Gérez vos informations et préférences",
        "models": "Modèles",
        "extractions": "Extractions",
        "personalInfo": "Informations Personnelles",
        "firstName": "Prénom",
        "lastName": "Nom",
        "firstNamePlaceholder": "Utilisateur",
        "lastNamePlaceholder": "OCR",
        "email": "Email",
        "whatsapp": "Contact Whatsapp",
        "updateInfo": "Mettre à jour les informations",
        "company": "Entreprise",
        "companyName": "Nom de l'entreprise",
        "companyNamePlaceholder": "Ex: TechDoc Solutions",
        "nif": "NIF",
        "nifPlaceholder": "Ex: 123456789",
        "address": "Adresse (Optionnel)",
        "addressPlaceholder": "Ex: Luanda, Angola",
        "updateCompany": "Mettre à jour l'entreprise",
        "accessCode": "Code d'accès",
        "currentCode": "Code actuel",
        "newCode": "Nouveau code",
        "confirmNewCode": "Confirmer le nouveau code",
        "changeCode": "Modifier le code",
        "faceLogin": "Connexion Faciale",
        "biometryActive": "Biométrie active. Échantillons enregistrés: 5/5. Sensibilité:",
        "biometryNone": "Aucune biométrie configurée. Enregistrez votre visage pour plus de sécurité.",
        "sensitivity": "Sensibilité Faciale",
        "sensitivityHint": "Plus bas = plus strict. Plus haut = plus tolérant.",
        "saveSensitivity": "Enregistrer la sensibilité",
        "registerFace": "Enregistrer le visage",
        "clearBiometry": "Effacer la biométrie",
        "biometryFooter": "Enregistrez jusqu'à 5 échantillons du même visage pour améliorer la reconnaissance hors ligne.",
        "removeBiometryTitle": "Supprimer la biométrie ?",
        "removeBiometryConfirm": "Êtes-vous sûr de vouloir supprimer l'accès facial ? Votre sécurité sera réduite.",
        "alerts": {
          "faceSuccess": "Biométrie faciale enregistrée avec succès !",
          "biometryRemoved": "Biométrie supprimée.",
          "updated": "mis à jour avec succès !"
        }
      }
    }
  }
};

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources,
    fallbackLng: 'pt',
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;
