/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as pdfjsLib from 'pdfjs-dist';

// Configure PDF.js worker using Vite-native pattern
pdfjsLib.GlobalWorkerOptions.workerSrc = new URL(
  'pdfjs-dist/build/pdf.worker.min.mjs',
  import.meta.url
).toString();

export function clamp(v: number, min: number = 0, max: number = 255) {
  return Math.max(min, Math.min(max, v));
}

export async function convertPdfToImage(file: File): Promise<string> {
  const arrayBuffer = await file.arrayBuffer();
  
  // Ensure worker is set (redundant but safe)
  if (!pdfjsLib.GlobalWorkerOptions.workerSrc) {
    pdfjsLib.GlobalWorkerOptions.workerSrc = new URL(
      'pdfjs-dist/build/pdf.worker.min.mjs',
      import.meta.url
    ).toString();
  }

  const loadingTask = pdfjsLib.getDocument({ 
    data: arrayBuffer,
    useWorkerFetch: true,
    isEvalSupported: false 
  } as any);
  const pdf = await loadingTask.promise;
  const page = await pdf.getPage(1); // Get first page for template
  
  const viewport = page.getViewport({ scale: 2.0 }); // High quality scale
  const canvas = document.createElement('canvas');
  const context = canvas.getContext('2d')!;
  canvas.height = viewport.height;
  canvas.width = viewport.width;

  await page.render({
    canvasContext: context,
    viewport: viewport,
    canvas: canvas // Explicitly pass canvas
  } as any).promise;

  return canvas.toDataURL('image/jpeg', 0.9);
}

export function makeCanvasCopy(sourceCanvas: HTMLCanvasElement) {
  const c = document.createElement('canvas');
  c.width = sourceCanvas.width;
  c.height = sourceCanvas.height;
  const ctx = c.getContext('2d');
  if (ctx) ctx.drawImage(sourceCanvas, 0, 0);
  return c;
}

export function applyGrayContrast(ctx: CanvasRenderingContext2D, width: number, height: number) {
  const imageData = ctx.getImageData(0, 0, width, height);
  const d = imageData.data;
  let min = 255;
  let max = 0;

  for (let i = 0; i < d.length; i += 4) {
    const g = (d[i] * 0.299 + d[i + 1] * 0.587 + d[i + 2] * 0.114) | 0;
    if (g < min) min = g;
    if (g > max) max = g;
  }

  const range = Math.max(1, max - min);
  for (let i = 0; i < d.length; i += 4) {
    const g = (d[i] * 0.299 + d[i + 1] * 0.587 + d[i + 2] * 0.114) | 0;
    const v = clamp(((g - min) * 255) / range);
    d[i] = d[i + 1] = d[i + 2] = v;
  }
  ctx.putImageData(imageData, 0, 0);
}

export function applyAdaptiveBinarize(ctx: CanvasRenderingContext2D, width: number, height: number) {
  const imageData = ctx.getImageData(0, 0, width, height);
  const d = imageData.data;
  const gray = new Uint8Array(width * height);

  for (let i = 0, j = 0; i < d.length; i += 4, j++) {
    gray[j] = (d[i] * 0.299 + d[i + 1] * 0.587 + d[i + 2] * 0.114) | 0;
  }

  const sampleBins = new Uint32Array(256);
  for (let i = 0; i < gray.length; i++) sampleBins[gray[i]]++;
  const total = gray.length;
  const target = Math.floor(total * 0.55);
  let acc = 0;
  let thr = 128;
  for (let i = 0; i < 256; i++) {
    acc += sampleBins[i];
    if (acc >= target) {
      thr = i;
      break;
    }
  }

  const dynamic = Math.max(8, Math.min(26, Math.floor((255 - thr) * 0.15)));
  const finalThr = thr - dynamic;

  for (let i = 0, j = 0; i < d.length; i += 4, j++) {
    const v = gray[j] < finalThr ? 0 : 255;
    d[i] = d[i + 1] = d[i + 2] = v;
  }

  ctx.putImageData(imageData, 0, 0);
}

export function makeScaledCanvas(sourceCanvas: HTMLCanvasElement, scale: number) {
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(sourceCanvas.width * scale));
  c.height = Math.max(1, Math.round(sourceCanvas.height * scale));
  const ctx = c.getContext('2d');
  if (!ctx) return c;
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(sourceCanvas, 0, 0, c.width, c.height);
  return c;
}

export function scoreOcrCandidate(text: string, confidence: number): number {
  const t = text.trim();
  const conf = Number.isFinite(confidence) ? confidence : 0;
  if (!t) return conf * 0.15;

  const len = t.length;
  const validChars = (t.match(/[0-9A-Za-zÀ-ÖØ-öø-ÿ]/g) || []).length;
  const qualityRatio = validChars / Math.max(1, len);
  const lenBoost = Math.min(20, len * 0.5);

  return conf + (qualityRatio * 22) + lenBoost;
}

export async function processImageWithSettings(canvas: HTMLCanvasElement, settings: any): Promise<HTMLCanvasElement> {
  const ctx = canvas.getContext('2d');
  if (!ctx) return canvas;

  // Apply zoom if needed (by resizing canvas)
  if (settings.zoom !== 100) {
    const scale = settings.zoom / 100;
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = canvas.width * scale;
    tempCanvas.height = canvas.height * scale;
    const tctx = tempCanvas.getContext('2d')!;
    tctx.drawImage(canvas, 0, 0, tempCanvas.width, tempCanvas.height);
    canvas.width = tempCanvas.width;
    canvas.height = tempCanvas.height;
    ctx.drawImage(tempCanvas, 0, 0);
  }

  // Basic filters using Canvas context manipulation or ImageData
  // For simplicity and speed, we apply the ones we implemented
  if (settings.contrast) {
    applyGrayContrast(ctx, canvas.width, canvas.height);
  }

  if (settings.denoise) {
    applyMedianFilter(ctx, canvas.width, canvas.height);
  }

  if (settings.sharpen) {
    applySharpen(ctx, canvas.width, canvas.height);
  }

  if (settings.binarize) {
    applyAdaptiveBinarize(ctx, canvas.width, canvas.height);
  }

  return canvas;
}

export function applySharpen(ctx: CanvasRenderingContext2D, width: number, height: number) {
  const imageData = ctx.getImageData(0, 0, width, height);
  const data = imageData.data;
  const copy = new Uint8ClampedArray(data);
  const mix = 0.5;

  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      for (let c = 0; c < 3; c++) {
        const i = (y * width + x) * 4 + c;
        const sum = 
          -1 * copy[((y - 1) * width + (x - 1)) * 4 + c] +
          -1 * copy[((y - 1) * width + x) * 4 + c] +
          -1 * copy[((y - 1) * width + (x + 1)) * 4 + c] +
          -1 * copy[(y * width + (x - 1)) * 4 + c] +
           9 * copy[(y * width + x) * 4 + c] +
          -1 * copy[(y * width + (x + 1)) * 4 + c] +
          -1 * copy[((y + 1) * width + (x - 1)) * 4 + c] +
          -1 * copy[((y + 1) * width + x) * 4 + c] +
          -1 * copy[((y + 1) * width + (x + 1)) * 4 + c];
        
        data[i] = clamp(sum);
      }
    }
  }
  ctx.putImageData(imageData, 0, 0);
}

export function applyMedianFilter(ctx: CanvasRenderingContext2D, width: number, height: number) {
  const imageData = ctx.getImageData(0, 0, width, height);
  const data = imageData.data;
  const copy = new Uint8ClampedArray(data);

  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      for (let c = 0; c < 3; c++) {
        const i = (y * width + x) * 4 + c;
        const vals = [
          copy[((y - 1) * width + (x - 1)) * 4 + c],
          copy[((y - 1) * width + x) * 4 + c],
          copy[((y - 1) * width + (x + 1)) * 4 + c],
          copy[(y * width + (x - 1)) * 4 + c],
          copy[(y * width + x) * 4 + c],
          copy[(y * width + (x + 1)) * 4 + c],
          copy[((y + 1) * width + (x - 1)) * 4 + c],
          copy[((y + 1) * width + x) * 4 + c],
          copy[((y + 1) * width + (x + 1)) * 4 + c]
        ].sort((a, b) => a - b);
        data[i] = vals[4];
      }
    }
  }
  ctx.putImageData(imageData, 0, 0);
}
