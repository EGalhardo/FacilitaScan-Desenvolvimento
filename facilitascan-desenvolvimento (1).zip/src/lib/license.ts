/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import CryptoJS from 'crypto-js';

// Ofuscação básica para dificultar a leitura direta por bots/scrapers
const _0x_a = ['FACI', 'LITA', 'SCAN', '2026', 'KEY'];
const _0x_get = () => _0x_a.join('');

const LICENSE_KEY = 'facilitascan_license';
const EXTRACTIONS_KEY = 'facilitascan_extractions_count';
const CARRYOVER_KEY = 'facilitascan_extractions_carryover';
const TIME_TRACKING_KEY = 'facilitascan_time_tracking';
const DB_NAME = 'facilitascan_faceauth_db';
const PROFILE_STORE = 'profiles';

export interface PlanLimits {
  name: string;
  maxExtractions: number;
  maxModels: number;
}

export const PLAN_CONFIG: Record<string, PlanLimits> = {
  'Gratuito': { name: 'Gratuito', maxExtractions: 0, maxModels: 0 },
  'Trial': { name: 'Trial', maxExtractions: 50, maxModels: 5 },
  'Basico': { name: 'Basico', maxExtractions: 100, maxModels: 10 },
  'Pro': { name: 'Pro', maxExtractions: 600, maxModels: 40 },
  'Empresarial': { name: 'Empresarial', maxExtractions: 3000, maxModels: 200 }
};

// Função interna para obter a chave (não exportada diretamente como string plana)
const getK = () => _0x_get();

/**
 * Ativa uma licença de teste de 15 dias para novos utilizadores
 */
export function activateTrial(): boolean {
  try {
    const deviceId = generateDeviceFingerprint();
    const expiry = Date.now() + (15 * 24 * 60 * 60 * 1000); // 15 dias
    
    const trialLicense = {
      deviceId,
      name: 'Utilizador Trial',
      plan: 'Trial',
      issuedAt: Date.now(),
      expiry,
      signature: CryptoJS.HmacSHA256(deviceId + expiry, getK()).toString()
    };
    
    const encrypted = CryptoJS.AES.encrypt(JSON.stringify(trialLicense), getK()).toString();
    localStorage.setItem(LICENSE_KEY, encrypted);
    localStorage.setItem('isTrialActivated', 'true');
    resetExtractions();
    return true;
  } catch (e) {
    console.error('Falha ao ativar trial:', e);
    return false;
  }
}

export function getExtractionsCount(): number {
  return parseInt(localStorage.getItem(EXTRACTIONS_KEY) || '0', 10);
}

export function incrementExtractions(count: number = 1) {
  const current = getExtractionsCount();
  localStorage.setItem(EXTRACTIONS_KEY, (current + count).toString());
}

export function resetExtractions() {
  localStorage.setItem(EXTRACTIONS_KEY, '0');
}

export function clearLicense() {
  localStorage.removeItem(LICENSE_KEY);
  localStorage.removeItem(CARRYOVER_KEY);
  // Definir extrações para um valor alto para "bloquear" o plano gratuito e mostrar o LicenseGate
  localStorage.setItem(EXTRACTIONS_KEY, '999');
  window.location.reload(); // Recarregar para forçar o gate de licença
}

async function openDB() {
  return new Promise<IDBDatabase>((resolve, reject) => {
    try {
      const req = indexedDB.open(DB_NAME, 1);
      
      // Timeout de segurança para evitar espera infinita
      const timeout = setTimeout(() => {
        reject(new Error('Timeout ao abrir base de dados biográfica.'));
      }, 5000);

      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(PROFILE_STORE)) {
          db.createObjectStore(PROFILE_STORE, { keyPath: 'userId' });
        }
      };
      
      req.onsuccess = () => {
        clearTimeout(timeout);
        resolve(req.result);
      };
      
      req.onerror = () => {
        clearTimeout(timeout);
        reject(req.error);
      };

      req.onblocked = () => {
        clearTimeout(timeout);
        console.warn('Conexão IndexDB bloqueada por outra aba.');
        // Não rejeitar imediatamente, pois pode desbloquear em breve, mas logar.
      };
    } catch (e) {
      reject(e);
    }
  });
}

export async function saveBiometricData(userId: string, embeddings: number[][]) {
  const db = await openDB();
  const tx = db.transaction(PROFILE_STORE, 'readwrite');
  tx.objectStore(PROFILE_STORE).put({ userId, embeddings, updatedAt: Date.now() });
  return new Promise((resolve) => tx.oncomplete = resolve);
}

export async function getBiometricData(userId: string): Promise<any> {
  const db = await openDB();
  const tx = db.transaction(PROFILE_STORE, 'readonly');
  const req = tx.objectStore(PROFILE_STORE).get(userId);
  return new Promise((resolve) => req.onsuccess = () => resolve(req.result));
}

export async function deleteBiometricData(userId: string) {
  const db = await openDB();
  const tx = db.transaction(PROFILE_STORE, 'readwrite');
  tx.objectStore(PROFILE_STORE).delete(userId);
  return new Promise((resolve) => tx.oncomplete = resolve);
}

export function calculateL2Distance(a: number[], b: number[]): number {
  if (a.length !== b.length) return Infinity;
  let sum = 0;
  for (let i = 0; i < a.length; i++) {
    const d = a[i] - b[i];
    sum += d * d;
  }
  return Math.sqrt(sum);
}

export function generateDeviceFingerprint(): string {
  try {
    const components = [
      navigator.userAgent,
      navigator.language,
      navigator.platform,
      (navigator as any).hardwareConcurrency?.toString() || '0',
      screen.width.toString(),
      screen.height.toString()
    ];
    
    // Canvas fingerprinting (simplified)
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.textBaseline = 'top';
      ctx.font = '14px Arial';
      ctx.fillText('FacilitaScan', 2, 2);
      components.push(canvas.toDataURL());
    }

    const hash = CryptoJS.SHA256(components.join('|||')).toString();
    return 'FS-' + hash.substring(0, 16).toUpperCase();
  } catch (e) {
    return 'FS-UNKNOWN';
  }
}

export function verifyLicense(): { valid: boolean; plan: string; expiry?: number; extractionsUsed: number; maxExtractions: number; maxModels: number } {
  const extractionsUsed = getExtractionsCount();
  const carryOver = parseInt(localStorage.getItem(CARRYOVER_KEY) || '0', 10);
  
  try {
    const encrypted = localStorage.getItem(LICENSE_KEY);
    if (!encrypted) {
      const plan = 'Gratuito';
      const config = PLAN_CONFIG[plan];
      const max = config.maxExtractions;
      // Para o plano gratuito, não aplicamos carryOver
      return { 
        valid: extractionsUsed < max, 
        plan, 
        extractionsUsed, 
        maxExtractions: max,
        maxModels: config.maxModels
      };
    }

    const bytes = CryptoJS.AES.decrypt(encrypted, getK());
    const decryptedData = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));

    const deviceId = generateDeviceFingerprint();
    if (decryptedData.deviceId !== deviceId) {
      return { valid: false, plan: 'Gratuito', extractionsUsed, maxExtractions: PLAN_CONFIG['Gratuito'].maxExtractions, maxModels: PLAN_CONFIG['Gratuito'].maxModels };
    }

    const now = Date.now();
    if (decryptedData.expiry < now) {
      // Licença expirada, mas ainda podemos estar no gate de ativação
      // O carryOver é preservado para quando uma nova licença for ativada
      return { valid: false, plan: 'Gratuito', extractionsUsed, maxExtractions: PLAN_CONFIG['Gratuito'].maxExtractions, maxModels: PLAN_CONFIG['Gratuito'].maxModels };
    }

    const plan = decryptedData.plan || 'Gratuito';
    const config = PLAN_CONFIG[plan] || PLAN_CONFIG['Gratuito'];
    const totalMax = config.maxExtractions + carryOver;

    if (extractionsUsed >= totalMax) {
      return { 
        valid: false, 
        plan, 
        expiry: decryptedData.expiry,
        extractionsUsed,
        maxExtractions: totalMax,
        maxModels: config.maxModels
      };
    }

    return { 
      valid: true, 
      plan, 
      expiry: decryptedData.expiry,
      extractionsUsed,
      maxExtractions: totalMax,
      maxModels: config.maxModels
    };
  } catch (e) {
    return { valid: false, plan: 'Gratuito', extractionsUsed, maxExtractions: PLAN_CONFIG['Gratuito'].maxExtractions, maxModels: PLAN_CONFIG['Gratuito'].maxModels };
  }
}

export function generateLicenseRequest(name: string, plan: string): string {
  const request = {
    deviceId: generateDeviceFingerprint(),
    name,
    plan,
    requestedAt: Date.now()
  };
  return CryptoJS.AES.encrypt(JSON.stringify(request), getK()).toString();
}

/**
 * Descriptografa um pedido (.enc) de forma segura
 */
export function decryptLicenseRequest(encryptedRequest: string): any {
  try {
    const bytes = CryptoJS.AES.decrypt(encryptedRequest, getK());
    const decryptedStr = bytes.toString(CryptoJS.enc.Utf8);
    if (!decryptedStr) return null;
    return JSON.parse(decryptedStr);
  } catch (e) {
    return null;
  }
}

export function generateLicense(requestEnc: string, months: number, planOverride?: string): string {
  try {
    const requestData = decryptLicenseRequest(requestEnc);
    if (!requestData) throw new Error('Pedido inválido');
    
    const expiry = Date.now() + (months * 30 * 24 * 60 * 60 * 1000);
    const finalPlan = planOverride || requestData.plan || 'Gratuito';
    
    const license = {
      deviceId: requestData.deviceId,
      name: requestData.name,
      plan: finalPlan,
      issuedAt: Date.now(),
      expiry: expiry,
      signature: CryptoJS.HmacSHA256(requestData.deviceId + expiry, getK()).toString()
    };
    
    return CryptoJS.AES.encrypt(JSON.stringify(license), getK()).toString();
  } catch (e) {
    throw new Error('Falha ao gerar licença: Dados do pedido inválidos.');
  }
}

export function activateLicense(licenseEnc: string): boolean {
  try {
    const bytes = CryptoJS.AES.decrypt(licenseEnc, getK());
    const licenseData = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
    
    const currentDevice = generateDeviceFingerprint();
    if (licenseData.deviceId !== currentDevice) {
      throw new Error('Esta licença foi gerada para outro dispositivo.');
    }
    
    if (licenseData.expiry < Date.now()) {
      throw new Error('Esta licença já expirou.');
    }

    // Validar assinatura para evitar edição manual do JSON
    const expectedSig = CryptoJS.HmacSHA256(licenseData.deviceId + licenseData.expiry, getK()).toString();
    if (licenseData.signature !== expectedSig) {
      throw new Error('Assinatura de licença inválida ou corrompida.');
    }

    // Lógica de Carryover: Adicionar extrações restantes da licença anterior
    // Primeiro, precisamos ler a licença ATUAL antes de subscrever
    const currentLicenseEnc = localStorage.getItem(LICENSE_KEY);
    let carryOverBonus = 0;

    if (currentLicenseEnc) {
      try {
        const oldBytes = CryptoJS.AES.decrypt(currentLicenseEnc, getK());
        const oldData = JSON.parse(oldBytes.toString(CryptoJS.enc.Utf8));
        const oldConfig = PLAN_CONFIG[oldData.plan];
        
        if (oldConfig) {
          const used = getExtractionsCount();
          // O carryOver anterior também deve ser considerado para acumular
          const oldCarryOver = parseInt(localStorage.getItem(CARRYOVER_KEY) || '0', 10);
          const oldTotalMax = oldConfig.maxExtractions + oldCarryOver;
          
          if (used < oldTotalMax) {
            carryOverBonus = oldTotalMax - used;
          }
        }
      } catch (err) {
        console.error('Erro ao calcular carryover da licença anterior:', err);
      }
    }

    // Salvar novo carryover acumulado
    if (carryOverBonus > 0) {
      localStorage.setItem(CARRYOVER_KEY, carryOverBonus.toString());
    } else {
      // Se não houve bônus (ou se a licença anterior já tinha esgotado tudo), resetamos o carryover
      localStorage.setItem(CARRYOVER_KEY, '0');
    }

    localStorage.setItem(LICENSE_KEY, licenseEnc);
    resetExtractions(); // Resetar extrações USADAS para 0
    return true;
  } catch (e: any) {
    alert(e.message || 'Erro ao ativar licença.');
    return false;
  }
}
