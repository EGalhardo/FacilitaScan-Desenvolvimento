/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Files as FilesIcon, 
  Search, 
  Trash2, 
  Eye, 
  Download,
  Calendar,
  Filter,
  X,
  FileText,
  Info,
  CheckCircle2,
  Table
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useTranslation } from 'react-i18next';
import { ExtractionResult } from '../types';

interface FilesProps {
  results: ExtractionResult[];
  onDelete: (id: string) => void;
  onView?: (result: ExtractionResult) => void;
}

export default function FilesView({ results, onDelete, onView }: FilesProps) {
  const { t } = useTranslation();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFile, setSelectedFile] = useState<ExtractionResult | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  
  const filteredResults = results.filter(r => 
    r.fileName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    r.modelName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleViewModel = (result: ExtractionResult) => {
    setSelectedFile(result);
    if (onView) onView(result);
  };

  const confirmDelete = () => {
    if (deleteConfirmId) {
      onDelete(deleteConfirmId);
      setDeleteConfirmId(null);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in relative">
      <header>
        <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">{t('nav.files')}</h1>
        <p className="text-gray-500 text-sm md:text-base">{t('files.subtitle')}</p>
      </header>

      <div className="bg-white rounded-2xl shadow-md p-5 border border-gray-200">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-[3] relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input 
              type="text" 
              placeholder={t('files.filter')} 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all"
            />
          </div>
          {searchTerm !== '' && (
            <button 
              onClick={() => setSearchTerm('')}
              className="px-5 py-3 bg-blue-50 text-blue-600 rounded-xl font-bold text-sm flex items-center justify-center gap-2 hover:bg-blue-100 transition-colors md:flex-1"
            >
              <X className="w-4 h-4" />
              {t('common.clear') || 'Limpar'}
            </button>
          )}
        </div>
      </div>

      {/* Search results summary */}
      {searchTerm !== '' && (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-blue-50 border border-blue-100 p-4 rounded-xl flex items-center justify-between"
        >
          <div className="flex items-center gap-3">
            <Search className="w-5 h-5 text-blue-600" />
            <p className="text-sm font-bold text-gray-700">
              {t('common.search') || 'Resultados para'}: <span className="text-blue-600">"{searchTerm}"</span>
            </p>
          </div>
          <span className="bg-blue-600 text-white text-[10px] font-black px-3 py-1 rounded-full uppercase">
            {filteredResults.length} {filteredResults.length === 1 ? 'item' : 'itens'}
          </span>
        </motion.div>
      )}

      {/* Files Table / List */}
      <div className="bg-white rounded-2xl shadow-md border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-blue-600 text-white font-bold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="px-6 py-4">{t('files.file')}</th>
                <th className="px-6 py-4">{t('files.model')}</th>
                <th className="px-6 py-4">{t('files.date')}</th>
                <th className="px-6 py-4">{t('dashboard.status')}</th>
                <th className="px-6 py-4 text-right">{t('files.actions')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredResults.length > 0 ? (
                filteredResults.map(result => (
                  <tr key={result.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-9 h-9 bg-blue-50 rounded-lg flex items-center justify-center text-blue-600">
                          <FilesIcon className="w-5 h-5" />
                        </div>
                        <span className="text-sm font-bold text-gray-900 truncate max-w-[150px] md:max-w-xs">{result.fileName}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-xs font-semibold text-gray-600">
                      {result.modelName}
                    </td>
                    <td className="px-6 py-4">
                        <div className="flex items-center text-xs text-gray-500">
                            <Calendar className="w-3.5 h-3.5 mr-1.5" />
                            {new Date(result.date).toLocaleDateString()}
                        </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-green-100 text-green-700 uppercase">
                        {result.status === 'completed' ? t('dashboard.fileDetails.completed') : t('dashboard.fileDetails.failed')}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end space-x-2">
                        <button 
                           onClick={() => handleViewModel(result)}
                           className="p-2 text-gray-400 hover:text-blue-600 transition-colors"
                           title={t('common.view')}
                        >
                          <Eye className="w-5 h-5" />
                        </button>
                        <button 
                          onClick={() => setDeleteConfirmId(result.id)}
                          className="p-2 text-gray-400 hover:text-red-500 transition-colors"
                          title={t('common.delete')}
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="px-6 py-20 text-center text-gray-400 font-medium">
                    {searchTerm ? t('files.noResults') : t('dashboard.noFiles')}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detail Modal */}
      <AnimatePresence>
        {selectedFile && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white rounded-[32px] shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col relative"
            >
              {/* Header */}
              <div className="p-8 pb-4 flex items-start justify-between">
                <div>
                  <h2 className="text-2xl font-black text-gray-900 mb-1">Detalhes do Arquivo</h2>
                  <p className="text-gray-400 font-medium text-sm">Informações completas do arquivo selecionado</p>
                </div>
                <button 
                  onClick={() => setSelectedFile(null)}
                  className="w-10 h-10 rounded-full bg-gray-50 flex items-center justify-center text-gray-400 hover:bg-gray-100 hover:text-gray-900 transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="px-8 pb-8 overflow-y-auto flex-1 custom-scrollbar">
                <div className="pt-4 border-t border-gray-100 mb-8">
                   <div className="flex items-center gap-4">
                      <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600">
                         <FilesIcon className="w-8 h-8" />
                      </div>
                      <div>
                        <h3 className="text-lg font-black text-gray-900 leading-tight">{selectedFile.fileName}</h3>
                        <p className="text-sm font-bold text-gray-400">Modelo: <span className="text-blue-600">{selectedFile.modelName}</span></p>
                      </div>
                   </div>
                </div>

                {/* Info Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
                  <div className="p-5 bg-white border border-gray-100 rounded-2xl shadow-sm hover:border-blue-100 transition-all">
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-2">Tipo/Formato</span>
                    <span className="text-sm font-black text-gray-900 uppercase">
                      {selectedFile.fileType.split('/')[1]?.toUpperCase() || selectedFile.fileType || '---'}
                    </span>
                  </div>
                  <div className="p-5 bg-white border border-gray-100 rounded-2xl shadow-sm hover:border-blue-100 transition-all">
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-2">Tamanho</span>
                    <span className="text-sm font-black text-gray-900">{formatFileSize(selectedFile.fileSize)}</span>
                  </div>
                  <div className="p-5 bg-white border border-gray-100 rounded-2xl shadow-sm hover:border-blue-100 transition-all">
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-2">Data de upload</span>
                    <span className="text-sm font-black text-gray-900">{new Date(selectedFile.date).toLocaleString()}</span>
                  </div>
                  <div className="p-5 bg-white border border-gray-100 rounded-2xl shadow-sm hover:border-blue-100 transition-all">
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-2">Status</span>
                    <div className="flex items-center gap-1.5">
                       <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                       <span className="text-sm font-black text-gray-900 uppercase">{selectedFile.status === 'completed' ? 'Concluído' : 'Falhou'}</span>
                    </div>
                  </div>
                </div>

                <div className="mb-8">
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-2">Descrição/Observações</span>
                    <div className="p-5 bg-white border border-gray-100 rounded-2xl shadow-sm min-h-[60px] text-sm text-gray-500 font-medium">
                      ---
                    </div>
                </div>

                <div>
                   <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-2">Resultado da extração (JSON)</span>
                   <div className="bg-gray-900 rounded-2xl p-6 font-mono text-[11px] text-green-400 overflow-x-auto shadow-inner leading-relaxed">
                      <pre>{JSON.stringify(selectedFile.data, null, 2)}</pre>
                   </div>
                </div>
              </div>

              {/* Footer */}
              <div className="p-8 pt-0 border-t border-gray-50 mt-auto flex justify-end">
                <button 
                  onClick={() => setSelectedFile(null)}
                  className="px-8 py-3.5 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 transition-all active:scale-[0.98] shadow-lg shadow-blue-100"
                >
                  Sair
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {deleteConfirmId && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-8 text-center"
            >
              <div className="w-20 h-20 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-6">
                <Trash2 className="w-10 h-10 text-red-500" />
              </div>
              <h3 className="text-2xl font-black text-gray-900 mb-3">Eliminar Arquivo?</h3>
              <p className="text-gray-500 font-medium mb-8 leading-relaxed">
                Tem certeza que deseja excluir permanentemente o arquivo <span className="text-gray-900 font-bold">"{results.find(r => r.id === deleteConfirmId)?.fileName}"</span>? Esta ação não pode ser desfeita.
              </p>
              <div className="flex gap-4">
                <button 
                  onClick={() => setDeleteConfirmId(null)}
                  className="flex-1 px-6 py-4 bg-gray-100 text-gray-600 font-bold rounded-2xl hover:bg-gray-200 transition-all font-sans"
                >
                  Cancelar
                </button>
                <button 
                  onClick={confirmDelete}
                  className="flex-1 px-6 py-4 bg-red-600 text-white font-bold rounded-2xl hover:bg-red-700 shadow-lg shadow-red-100 transition-all font-sans"
                >
                  Sim, Eliminar
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

