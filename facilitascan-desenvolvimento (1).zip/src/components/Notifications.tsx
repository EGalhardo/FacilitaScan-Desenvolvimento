/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Bell, 
  Trash2, 
  CheckCircle2, 
  Inbox, 
  RotateCcw,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useTranslation } from 'react-i18next';
import { AppNotification } from '../types';

interface NotificationsViewProps {
  notifications: AppNotification[];
  onMarkRead: (id: string) => void;
  onMarkAllRead: () => void;
  onDelete: (id: string) => void;
}

export default function NotificationsView({ 
  notifications, 
  onMarkRead, 
  onMarkAllRead, 
  onDelete 
}: NotificationsViewProps) {
  const { t } = useTranslation();
  const [filter, setFilter] = useState<'all' | 'unread' | 'read'>('all');
  const [selectedNotification, setSelectedNotification] = useState<AppNotification | null>(null);

  const unreadCount = notifications.filter(n => !n.read).length;

  const handleNotificationClick = (n: AppNotification) => {
    setSelectedNotification(n);
    if (!n.read) {
      onMarkRead(n.id);
    }
  };

  const clearAll = () => {
    if (notifications.length > 0 && confirm(t('notifications.clearConfirm'))) {
      notifications.forEach(n => onDelete(n.id));
    }
  };

  const filteredNotifications = notifications.filter(n => {
    if (filter === 'all') return true;
    if (filter === 'unread') return !n.read;
    if (filter === 'read') return n.read;
    return true;
  });

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fade-in relative">
      <header className="flex items-center justify-between">
        <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-1">{t('notifications.title')}</h1>
            <p className="text-sm text-gray-500 font-medium">{t('notifications.subtitle')}</p>
        </div>
        <div className="flex gap-2">
            <button 
                onClick={onMarkAllRead}
                disabled={unreadCount === 0}
                className="flex items-center gap-2 px-4 py-2 text-sm font-bold text-blue-600 hover:bg-blue-50 rounded-xl transition-colors disabled:opacity-50"
            >
                <CheckCircle2 className="w-4 h-4" /> {t('notifications.markAllRead')}
            </button>
            <button 
                onClick={clearAll}
                className="flex items-center gap-2 px-4 py-2 text-sm font-bold text-red-600 hover:bg-red-50 rounded-xl transition-colors"
            >
                <Trash2 className="w-4 h-4" /> {t('notifications.clearAll')}
            </button>
        </div>
      </header>

      <div className="flex gap-2 p-1 bg-gray-100 rounded-2xl w-fit">
          <button 
            onClick={() => setFilter('all')}
            className={`px-6 py-2 rounded-xl text-sm font-bold transition-all ${filter === 'all' ? 'bg-white shadow-md text-blue-600' : 'text-gray-500 hover:text-gray-700'}`}
          >
              {t('notifications.filters.all')}
          </button>
          <button 
            onClick={() => setFilter('read')}
            className={`px-6 py-2 rounded-xl text-sm font-bold transition-all ${filter === 'read' ? 'bg-white shadow-md text-blue-600' : 'text-gray-500 hover:text-gray-700'}`}
          >
              {t('notifications.filters.read')}
          </button>
          <button 
            onClick={() => setFilter('unread')}
            className={`px-6 py-2 rounded-xl text-sm font-bold transition-all flex items-center gap-2 ${filter === 'unread' ? 'bg-white shadow-md text-blue-600' : 'text-gray-500 hover:text-gray-700'}`}
          >
              {t('notifications.filters.unread')}
              {unreadCount > 0 && <span className="w-5 h-5 rounded-full bg-blue-600 text-white text-[10px] flex items-center justify-center font-black">{unreadCount}</span>}
          </button>
      </div>

      <div className="space-y-3">
          {filteredNotifications.length > 0 ? (
              filteredNotifications.map(n => (
                  <motion.div 
                    layout
                    key={n.id}
                    onClick={() => handleNotificationClick(n)}
                    className={`group relative bg-white p-5 rounded-2xl border transition-all cursor-pointer ${n.read ? 'border-gray-100' : 'border-blue-100 shadow-md shadow-blue-50/50'}`}
                  >
                      <div className="flex gap-4">
                          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0 ${
                              n.type === 'success' ? 'bg-green-100 text-green-600' : 
                              n.type === 'warning' ? 'bg-amber-100 text-amber-600' :
                              n.type === 'error' ? 'bg-red-100 text-red-600' : 'bg-blue-100 text-blue-600'
                          }`}>
                              <Bell className="w-6 h-6" />
                          </div>
                          <div className="flex-1 min-w-0">
                              <div className="flex justify-between items-start mb-1">
                                  <h3 className={`font-bold text-gray-900 truncate pr-10 ${!n.read ? 'text-blue-900' : 'text-gray-700'}`}>{n.title}</h3>
                                  <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest flex-shrink-0">
                                      {new Date(n.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                  </span>
                              </div>
                              <p className={`text-sm leading-relaxed truncate ${n.read ? 'text-gray-400' : 'text-gray-600'}`}>{n.message}</p>
                          </div>
                      </div>

                      <div className="absolute top-4 right-4 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button 
                            onClick={(e) => { e.stopPropagation(); onDelete(n.id); }}
                            className="p-2 hover:bg-red-50 text-red-500 rounded-lg transition-colors" title={t('common.delete')}
                          >
                              <Trash2 className="w-4 h-4" />
                          </button>
                      </div>
                      {!n.read && (
                          <div className="absolute top-1/2 -right-1 -translate-y-1/2 w-2 h-2 bg-blue-600 rounded-full shadow-lg shadow-blue-400" />
                      )}
                  </motion.div>
                ))
          ) : (
              <div className="p-20 text-center space-y-4 bg-gray-50 rounded-3xl border-2 border-dashed border-gray-200">
                  <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto text-gray-400">
                    <Inbox className="w-10 h-10" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900">{t('notifications.empty.title')}</h3>
                    <p className="text-sm text-gray-500">{t('notifications.empty.subtitle')}</p>
                  </div>
              </div>
          )}
      </div>

      <footer className="pt-10 flex flex-col items-center gap-4 text-center">
          <p className="text-xs text-gray-400 font-bold uppercase tracking-[0.2em]">{t('notifications.footer')}</p>
          <button 
            onClick={() => window.location.reload()}
            className="flex items-center gap-2 text-xs font-black text-blue-600 hover:underline"
          >
              <RotateCcw className="w-3.5 h-3.5" /> {t('notifications.reload')}
          </button>
      </footer>

      {/* Notification Detail Modal */}
      <AnimatePresence>
        {selectedNotification && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-white rounded-3xl shadow-2xl max-w-lg w-full p-8 relative"
            >
              <button 
                onClick={() => setSelectedNotification(null)}
                className="absolute top-6 right-6 text-gray-400 hover:text-gray-900 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>

              <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-6 ${
                  selectedNotification.type === 'success' ? 'bg-green-100 text-green-600' : 
                  selectedNotification.type === 'warning' ? 'bg-amber-100 text-amber-600' :
                  selectedNotification.type === 'error' ? 'bg-red-100 text-red-600' : 'bg-blue-100 text-blue-600'
              }`}>
                  <Bell className="w-8 h-8" />
              </div>

              <div className="mb-8">
                <div className="flex items-center justify-between gap-2 mb-2">
                   <h3 className="text-2xl font-black text-gray-900 leading-tight">
                     {selectedNotification.title}
                   </h3>
                   <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest whitespace-nowrap bg-gray-50 px-2 py-1 rounded-md">
                      {new Date(selectedNotification.timestamp).toLocaleDateString()}
                   </span>
                </div>
                <div className="text-gray-600 font-medium leading-relaxed">
                  {selectedNotification.message}
                </div>
              </div>

              <div className="flex gap-3">
                <button 
                  onClick={() => setSelectedNotification(null)}
                  className="flex-1 px-6 py-4 bg-gray-100 text-gray-700 font-bold rounded-2xl hover:bg-gray-200 transition-all active:scale-[0.98]"
                >
                  {t('notifications.close')}
                </button>
                <button 
                  onClick={() => { onDelete(selectedNotification.id); setSelectedNotification(null); }}
                  className="px-6 py-4 bg-red-50 text-red-600 font-bold rounded-2xl hover:bg-red-100 transition-all active:scale-[0.98]"
                >
                  {t('notifications.delete')}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
