import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  FileUp, 
  Key, 
  ShieldCheck, 
  LogOut, 
  Users, 
  Clock, 
  CheckCircle2, 
  AlertTriangle,
  FileText,
  DollarSign,
  Download,
  Search,
  Plus,
  Trash2,
  Eye,
  Share2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useTranslation } from 'react-i18next';
import CryptoJS from 'crypto-js';
import { generateLicense, decryptLicenseRequest } from '../lib/license';

type AdminPage = 'dashboard' | 'subscriptions' | 'import' | 'generate' | 'management';

interface Subscription {
  id: string;
  clientName: string;
  plan: string;
  maxLicenses: number;
  usedLicenses: number;
  paymentDate: number;
  status: 'Ativa' | 'Expirada';
  notes?: string;
}

interface AdminPanelProps {
  onBack: () => void;
}

export function AdminPanel({ onBack }: AdminPanelProps) {
  const { t } = useTranslation();
  const [activePage, setActivePage] = useState<AdminPage>('dashboard');
  const [importStatus, setImportStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [pendingEnc, setPendingEnc] = useState<string>('');
  const [selectedSubscriptionId, setSelectedSubscriptionId] = useState<string>('');
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  // Carregar dados salvos
  const [generatedLicenses, setGeneratedLicenses] = useState<any[]>(() => {
    const saved = localStorage.getItem('fs_admin_generated_licenses');
    return saved ? JSON.parse(saved) : [];
  });

  const [subscriptions, setSubscriptions] = useState<Subscription[]>(() => {
    const saved = localStorage.getItem('fs_admin_subscriptions');
    return saved ? JSON.parse(saved) : [];
  });

  const PLAN_VALUES: Record<string, number> = {
    'Basico': 45000,
    'Pro': 120000,
    'Empresarial': 350000
  };

  const stats = [
    { label: t('admin.stats.activeLicenses'), value: generatedLicenses.filter(l => l.status === 'Ativa').length.toString(), icon: CheckCircle2, color: 'text-green-500', bg: 'bg-green-50', tag: t('dashboard.active') },
    { label: t('admin.stats.activePlans'), value: subscriptions.length.toString(), icon: Users, color: 'text-blue-500', bg: 'bg-blue-50', tag: 'Clientes' },
    { label: t('admin.stats.issuedLicenses'), value: (generatedLicenses.length).toString(), icon: FileText, color: 'text-indigo-500', bg: 'bg-indigo-50', tag: 'Stats' },
    { label: t('admin.stats.totalRevenue'), value: `${subscriptions.reduce((acc, s) => acc + (PLAN_VALUES[s.plan] || 0), 0).toLocaleString()} Kz`, icon: DollarSign, color: 'text-purple-500', bg: 'bg-purple-50', tag: t('dashboard.total') || 'Total' },
  ];

  const [clientName, setClientName] = useState('');
  const [deviceHash, setDeviceHash] = useState('');
  const [validity, setValidity] = useState(1);
  const [plan, setPlan] = useState('Pro');
  const [notes, setNotes] = useState('');
  
  // Estados para modais de ação
  const [visualizingLicense, setVisualizingLicense] = useState<any | null>(null);
  const [exportingLicense, setExportingLicense] = useState<any | null>(null);
  const [showExportModal, setShowExportModal] = useState(false);

  // Sincronizar plano e nome quando seleciona uma subscrição
  React.useEffect(() => {
    if (selectedSubscriptionId) {
      const sub = subscriptions.find(s => s.id === selectedSubscriptionId);
      if (sub) {
        setPlan(sub.plan);
        if (!clientName) setClientName(sub.clientName);
      }
    }
  }, [selectedSubscriptionId, subscriptions]);

  const PLAN_LIMITS: Record<string, number> = {
    'Basico': 1,
    'Pro': 5,
    'Empresarial': 10
  };

  const PLAN_PRICES: Record<string, string> = {
    'Basico': '45.000 Kz',
    'Pro': '120.000 Kz',
    'Empresarial': '350.000 Kz'
  };

  const [newSub, setNewSub] = useState({ name: '', plan: 'Pro' });

  const handleAddSubscription = () => {
    if (!newSub.name) return alert(t('admin.clients.errorName'));
    const sub: Subscription = {
      id: 'SUB-' + Math.random().toString(36).substring(2, 7).toUpperCase(),
      clientName: newSub.name,
      plan: newSub.plan,
      maxLicenses: PLAN_LIMITS[newSub.plan as keyof typeof PLAN_LIMITS] || 1,
      usedLicenses: 0,
      paymentDate: Date.now(),
      status: 'Ativa'
    };
    const updated = [sub, ...subscriptions];
    setSubscriptions(updated);
    localStorage.setItem('fs_admin_subscriptions', JSON.stringify(updated));
    setNewSub({ name: '', plan: 'Pro' });
    alert(t('admin.clients.successPlan'));
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>, subId?: string) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const content = event.target?.result as string;
          setPendingEnc(content);
          
          const data = decryptLicenseRequest(content);
          if (!data) throw new Error('Falha na decriptação');
          
          setClientName(data.name || '');
          setDeviceHash(data.deviceId || '');
          setPlan(data.plan || 'Pro');

          // Se vier de uma subscrição específica, usa esse ID
          if (subId) {
            setSelectedSubscriptionId(subId);
          } else {
            // Tentar encontrar subscrição correspondente pelo nome
            const matchingSub = subscriptions.find(s => s.clientName.toLowerCase() === (data.name || '').toLowerCase());
            if (matchingSub) {
              setSelectedSubscriptionId(matchingSub.id);
            }
          }
          
          setImportStatus('success');
          setActivePage('generate');
        } catch (err) {
          alert(t('admin.clients.errorImport'));
          setImportStatus('error');
        }
      };
      reader.readAsText(file);
    }
  };

  const handleGenerateRealLicense = () => {
    try {
      if (!pendingEnc) {
        return alert(t('admin.clients.errorNoEnc'));
      }

      if (!clientName) {
        return alert(t('admin.clients.errorNoName'));
      }

      let finalPlan = plan;

      // Validação rigorosa de subscrição
      if (selectedSubscriptionId) {
        const subIndex = subscriptions.findIndex(s => s.id === selectedSubscriptionId);
        if (subIndex === -1) {
          return alert(t('admin.clients.errorNoSub'));
        }
        
        const sub = subscriptions[subIndex];
        if (sub.usedLicenses >= sub.maxLicenses) {
          return alert(t('admin.clients.errorLimit', { 
            plan: sub.plan,
            max: sub.maxLicenses
          }));
        }
        
        // Se houver subscrição, o plano da licença DEVE ser o da subscrição
        finalPlan = sub.plan;
      } else {
         if (!confirm(t('admin.clients.isolateConfirm'))) {
           return;
         }
      }

      // Tentar gerar a licença (pode lançar erro se o .enc for inválido)
      const licenseEnc = generateLicense(pendingEnc, validity, finalPlan);
      
      const newLicense = {
        id: 'LIC-' + Math.random().toString(36).substring(2, 9).toUpperCase(),
        client: clientName,
        plan: finalPlan,
        deviceId: deviceHash,
        issuedAt: Date.now(),
        expiry: Date.now() + (validity * 30 * 24 * 60 * 60 * 1000),
        status: 'Ativa',
        subscriptionId: selectedSubscriptionId || null,
        notes: notes
      };
      
      // Atualizar histórico de licenças
      const updatedLicenses = [newLicense, ...generatedLicenses];
      setGeneratedLicenses(updatedLicenses);
      localStorage.setItem('fs_admin_generated_licenses', JSON.stringify(updatedLicenses));

      // Atualizar contador da subscrição se aplicável
      if (selectedSubscriptionId) {
        const updatedSubs = subscriptions.map(s => {
          if (s.id === selectedSubscriptionId) {
            return { ...s, usedLicenses: s.usedLicenses + 1 };
          }
          return s;
        });
        setSubscriptions(updatedSubs);
        localStorage.setItem('fs_admin_subscriptions', JSON.stringify(updatedSubs));
      }

      // Preparar Download
      const blob = new Blob([licenseEnc], { type: 'application/octet-stream' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `licenca_${clientName.replace(/\s+/g, '_').toLowerCase()}.lic`;
      document.body.appendChild(link);
      link.click();
      
      // Cleanup cleanup cleanup
      setTimeout(() => {
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
      }, 200);

      // Limpar estados apenas após sucesso
      setNotes('');
      setPendingEnc('');
      setImportStatus('idle');
      setSelectedSubscriptionId('');
      setClientName('');
      setDeviceHash('');
      
      alert(t('admin.clients.successGen'));
      setActivePage('dashboard');
    } catch (err: any) {
      console.error('Erro na geração de licença:', err);
      alert(err.message || 'Erro ao gerar licenciamento. Verifique o ficheiro de pedido.');
    }
  };

  const handleDeleteLicense = (id: string, client: string) => {
    if (window.confirm(t('admin.clients.deleteConfirm', { client: client }))) {
      const updated = generatedLicenses.filter(l => l.id !== id);
      setGeneratedLicenses(updated);
      localStorage.setItem('fs_admin_generated_licenses', JSON.stringify(updated));
      alert(t('admin.clients.deleteSuccess'));
    }
  };

  const handleDeleteSubscription = (id: string, client: string) => {
    if (window.confirm(t('admin.clients.deletePlanConfirm', { client: client }))) {
      const updated = subscriptions.filter(s => s.id !== id);
      setSubscriptions(updated);
      localStorage.setItem('fs_admin_subscriptions', JSON.stringify(updated));
      alert(t('admin.clients.deletePlanSuccess'));
    }
  };

  const handleExport = (format: 'pdf' | 'csv' | 'json') => {
    if (!exportingLicense) return;
    
    // Simulação de exportação
    alert(`Exportando licença de ${exportingLicense.client} no formato ${format.toUpperCase()}...`);
    setShowExportModal(false);
    setExportingLicense(null);
  };

  return (
    <div className="flex h-screen bg-[#F8FAFC]">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-gray-100 flex flex-col">
        <div className="p-6 border-b border-gray-50 flex items-center gap-3">
          <img 
            src="https://i.postimg.cc/jdtbwWnP/Icone-de-scanner-minimalista-em-vetor-novo.png" 
            className="w-10 h-10 rounded-xl object-cover" 
            alt="FacilitaScan Logo" 
          />
          <div>
            <h1 className="text-lg font-black text-gray-900 leading-none">FacilitaScan</h1>
            <p className="text-[10px] font-bold text-gray-400 mt-1 uppercase tracking-wider">Admin Panel</p>
          </div>
        </div>

        <nav className="flex-1 p-4 flex flex-col gap-2">
          {[
            { id: 'dashboard', label: t('admin.nav.dashboard'), icon: LayoutDashboard },
            { id: 'subscriptions', label: t('admin.nav.clients'), icon: Users },
            { id: 'import', label: t('admin.nav.import'), icon: FileUp },
            { id: 'generate', label: t('admin.nav.generate'), icon: Key },
            { id: 'management', label: t('admin.nav.history'), icon: FileText },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActivePage(item.id as AdminPage)}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all ${
                activePage === item.id 
                ? 'bg-blue-50 text-blue-600' 
                : 'text-gray-500 hover:bg-gray-50'
              }`}
            >
              <item.icon className="w-5 h-5" />
              {item.label}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-gray-50">
          <div className="bg-gray-50 rounded-2xl p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center text-blue-600">
              <Users className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-gray-900 truncate">Administrador</p>
              <p className="text-[10px] text-gray-400 uppercase font-black">v2.0</p>
            </div>
            <button 
              onClick={onBack}
              title={t('nav.logout')}
              className="px-3 py-2 bg-white rounded-lg border border-gray-100 text-gray-400 hover:text-red-500 hover:border-red-100 transition-all shadow-sm flex items-center gap-2 group"
            >
              <LogOut className="w-4 h-4" />
              <span className="text-[10px] font-black uppercase hidden group-hover:block transition-all">{t('nav.logout')}</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Content */}
      <main className="flex-1 overflow-y-auto p-8">
        <AnimatePresence mode="wait">
          {activePage === 'dashboard' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              <div>
                <h2 className="text-3xl font-black text-gray-900 leading-none">{t('admin.nav.dashboard')}</h2>
                <p className="text-gray-500 mt-2 font-medium">{t('admin.subtitle')}</p>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-4 gap-6">
                {stats.map((stat, i) => (
                  <div key={i} className="bg-white p-6 rounded-3xl border border-gray-50 shadow-sm relative overflow-hidden group">
                    <div className="flex justify-between items-start mb-4">
                      <div className={`p-3 rounded-xl ${stat.bg} ${stat.color}`}>
                        <stat.icon className="w-6 h-6" />
                      </div>
                      <span className={`text-[10px] font-black px-2 py-1 rounded-lg uppercase ${stat.bg} ${stat.color}`}>
                        {stat.tag}
                      </span>
                    </div>
                    <p className="text-4xl font-black text-gray-900 leading-none mb-2">{stat.value}</p>
                    <p className="text-sm font-bold text-gray-400">{stat.label}</p>
                  </div>
                ))}
              </div>

              {/* Table Section */}
              <div className="bg-white rounded-3xl border border-gray-50 shadow-sm p-8">
                <div className="flex justify-between items-center mb-8">
                  <div>
                    <h3 className="text-xl font-black text-gray-900">{t('admin.history.title')}</h3>
                    <p className="text-sm text-gray-400 font-medium">{t('admin.history.subtitle')}</p>
                  </div>
                  {generatedLicenses.length > 0 && (
                    <button 
                      onClick={() => {
                        if(confirm(t('admin.history.clearConfirm'))) {
                          setGeneratedLicenses([]);
                          localStorage.removeItem('fs_admin_generated_licenses');
                        }
                      }}
                      className="text-red-500 text-sm font-black hover:underline"
                    >
                      {t('admin.history.clear')}
                    </button>
                  )}
                </div>
                
                {generatedLicenses.length === 0 ? (
                  <div className="text-center py-12 text-gray-400 font-medium italic">
                    {t('admin.history.noLicenses')}
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead>
                        <tr className="border-b border-gray-50 text-[10px] font-black text-gray-400 uppercase tracking-widest">
                          {/* ID Column Head */}
                          <th className="pb-4">{t('admin.clients.id')}</th>
                          <th className="pb-4">{t('admin.clients.clientName')}</th>
                          <th className="pb-4">{t('admin.generate.planLabel')}</th>
                          <th className="pb-4">{t('admin.generate.valueLabel')}</th>
                          <th className="pb-4">{t('admin.modals.details.expiry')}</th>
                          <th className="pb-4">{t('admin.clients.status')}</th>
                          <th className="pb-4 text-right">{t('common.actions')}</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-50">
                        {generatedLicenses.slice(0, 10).map((lic) => (
                          <tr key={lic.id} className="group hover:bg-gray-50/50 transition-colors">
                            <td className="py-4 font-mono text-xs text-gray-400">{lic.id}</td>
                            <td className="py-4">
                              <p className="text-sm font-bold text-gray-900">{lic.client}</p>
                              <p className="text-[10px] text-gray-400 font-mono truncate max-w-[100px]">{lic.deviceId}</p>
                            </td>
                            <td className="py-4">
                              <span className="px-2 py-1 bg-blue-50 text-blue-600 rounded-lg text-[10px] font-black uppercase">
                                {lic.plan}
                              </span>
                            </td>
                            <td className="py-4 text-[10px] font-black text-gray-900">
                               {PLAN_PRICES[lic.plan as keyof typeof PLAN_PRICES] || '---'}
                            </td>
                            <td className="py-4 text-xs font-bold text-gray-600">
                              {new Date(lic.expiry).toLocaleDateString()}
                            </td>
                            <td className="py-4">
                              <span className="px-2 py-1 bg-green-50 text-green-600 rounded-lg text-[10px] font-black uppercase">
                                {lic.status}
                              </span>
                            </td>
                            <td className="py-4 text-right">
                               <div className="flex justify-end gap-2 pr-2">
                                  <button 
                                    onClick={() => setVisualizingLicense(lic)}
                                    className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
                                    title="Visualizar Detalhes"
                                  >
                                    <Eye className="w-4 h-4" />
                                  </button>
                                  <button 
                                    onClick={() => { setExportingLicense(lic); setShowExportModal(true); }}
                                    className="p-2 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-lg transition-all"
                                    title="Exportar Licença"
                                  >
                                    <Share2 className="w-4 h-4" />
                                  </button>
                                  <button 
                                    onClick={() => handleDeleteLicense(lic.id, lic.client)}
                                    className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                                    title="Eliminar"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                               </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {activePage === 'subscriptions' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
               <div className="flex justify-between items-end">
                <div>
                  <h2 className="text-3xl font-black text-gray-900 leading-none">{t('admin.nav.clients')}</h2>
                  <p className="text-gray-500 mt-2 font-medium">{t('admin.clients.subtitle') || 'Gerencie os planos pagos pelos clientes'}</p>
                </div>
                <div className="flex gap-4 items-center bg-white p-4 rounded-3xl border border-gray-50 shadow-sm">
                   <div className="space-y-1">
                      <p className="text-[10px] font-black text-gray-400 uppercase">{t('admin.clients.newClient') || 'Novo Cliente'}</p>
                      <input 
                        type="text" 
                        placeholder={t('admin.clients.clientName') || 'Nome do Cliente'}
                        value={newSub.name}
                        onChange={e => setNewSub({...newSub, name: e.target.value})}
                        className="bg-gray-50 border-none rounded-lg px-3 py-2 text-sm font-bold outline-none focus:ring-1 focus:ring-blue-200"
                      />
                   </div>
                   <div className="space-y-1">
                      <p className="text-[10px] font-black text-gray-400 uppercase">{t('dashboard.plan')}</p>
                      <select 
                        value={newSub.plan}
                        onChange={e => setNewSub({...newSub, plan: e.target.value})}
                        className="bg-gray-50 border-none rounded-lg px-3 py-2 text-sm font-bold outline-none focus:ring-1 focus:ring-blue-200"
                      >
                        <option value="Basico">{t('plans.basic') || 'Básico'}</option>
                        <option value="Pro">Pro</option>
                        <option value="Empresarial">{t('plans.enterprise') || 'Enterprise'}</option>
                      </select>
                   </div>
                   <button 
                    onClick={handleAddSubscription}
                    className="p-3 bg-blue-600 text-white rounded-2xl hover:bg-blue-700 transition-all shadow-lg shadow-blue-100"
                   >
                    <Plus className="w-5 h-5" />
                   </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {subscriptions.map((sub) => (
                  <div key={sub.id} className="bg-white rounded-3xl border border-gray-50 shadow-sm p-6 relative group overflow-hidden">
                    <div className="flex justify-between items-start mb-6">
                      <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl">
                        <Users className="w-6 h-6" />
                      </div>
                      <button 
                        type="button"
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          console.log('Delete button clicked for sub:', sub.id);
                          handleDeleteSubscription(sub.id, sub.clientName);
                        }}
                        className="p-3 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all cursor-pointer relative z-[100] group/del"
                        title="Eliminar Plano"
                      >
                        <Trash2 className="w-5 h-5 pointer-events-none" />
                      </button>
                    </div>
                    
                    <h3 className="text-xl font-black text-gray-900 mb-1">{sub.clientName}</h3>
                    <div className="flex items-center gap-2 mb-6">
                      <span className="px-2 py-1 bg-gray-100 text-gray-500 rounded-lg text-[10px] font-black uppercase">
                        {sub.plan}
                      </span>
                      <span className="text-[10px] font-bold text-gray-400">Desde {new Date(sub.paymentDate).toLocaleDateString()}</span>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <p className="text-xs font-bold text-gray-500">Licenças Ativadas</p>
                          <p className="text-xs font-black text-gray-900">{sub.usedLicenses} / {sub.maxLicenses}</p>
                        </div>
                        <div className="w-full h-2 bg-gray-50 rounded-full overflow-hidden">
                          <div 
                            className={`h-full transition-all duration-1000 ${sub.usedLicenses >= sub.maxLicenses ? 'bg-amber-500' : 'bg-blue-600'}`} 
                            style={{ width: `${(sub.usedLicenses / sub.maxLicenses) * 100}%` }}
                          />
                        </div>
                      </div>

                      <button 
                        onClick={() => {
                          setSelectedSubscriptionId(sub.id);
                          fileInputRef.current?.click();
                        }}
                        disabled={sub.usedLicenses >= sub.maxLicenses}
                        className="w-full py-3 bg-blue-50 text-blue-600 rounded-xl font-bold text-xs hover:bg-blue-600 hover:text-white transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:bg-gray-50 disabled:text-gray-300"
                      >
                         <FileUp className="w-4 h-4" /> Ativar Nova Licença
                      </button>

                      <div className="pt-4 border-t border-gray-50 flex items-center justify-between">
                         <p className="text-[10px] font-black text-gray-400 uppercase">ID: {sub.id}</p>
                         <p className="text-[10px] font-black text-green-600 uppercase bg-green-50 px-2 py-1 rounded-lg">PAGO</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Hidden input for quick activation */}
              <input 
                type="file" 
                ref={fileInputRef}
                className="hidden" 
                accept=".enc" 
                onChange={(e) => handleImportFile(e, selectedSubscriptionId)} 
              />
            </motion.div>
          )}

          {activePage === 'import' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
               <div>
                <h2 className="text-3xl font-black text-gray-900 leading-none">{t('admin.nav.import')}</h2>
                <p className="text-gray-500 mt-2 font-medium">{t('admin.import.subtitle') || 'Importe um ficheiro .enc para processar o pedido de licença'}</p>
              </div>

              <div className="bg-white rounded-3xl border border-gray-50 shadow-sm p-12 flex flex-col items-center">
                <div className="w-full max-w-2xl border-2 border-dashed border-blue-100 rounded-[2rem] p-16 flex flex-col items-center justify-center group hover:border-blue-300 hover:bg-blue-50/10 transition-all cursor-pointer relative overflow-hidden">
                  <input 
                    type="file" 
                    accept=".enc" 
                    onChange={(e) => {
                      handleImportFile(e);
                      e.target.value = '';
                    }}
                    className="absolute inset-0 opacity-0 cursor-pointer z-10"
                  />
                  <div className="p-6 bg-blue-50 text-blue-600 rounded-3xl mb-6 group-hover:scale-110 transition-all duration-500 shadow-sm">
                    <FileUp className="w-10 h-10" />
                  </div>
                  <h3 className="text-2xl font-black text-gray-900 mb-2">{t('admin.import.dropTitle') || 'Arraste o ficheiro .enc aqui'}</h3>
                  <p className="text-gray-400 font-bold text-base">{t('admin.import.dropSubtitle') || 'ou clique para selecionar no computador'}</p>
                  
                  <div className="mt-8 flex items-center gap-2 px-4 py-2 bg-gray-50 rounded-full border border-gray-100">
                    <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{t('admin.import.ready') || 'Sistema Pronto'}</span>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {activePage === 'generate' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
               <div>
                <h2 className="text-3xl font-black text-gray-900 leading-none">Gerar Licença</h2>
                <p className="text-gray-500 mt-2 font-medium">Preencha os dados e gere a licença encriptada</p>
              </div>

              <div className="bg-white rounded-3xl border border-gray-50 shadow-sm p-8">
                 {importStatus !== 'success' ? (
                  <div className="bg-blue-50 rounded-2xl p-8 border border-blue-100 text-center">
                    <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center mx-auto mb-4 text-blue-600">
                        <Clock className="w-6 h-6" />
                    </div>
                    <h3 className="text-lg font-black text-blue-900 mb-1">Nenhum pedido importado</h3>
                    <p className="text-blue-700 font-medium text-sm">
                        Importe um ficheiro .enc primeiro na aba "Importar Pedido".
                    </p>
                  </div>
                ) : (
                   <div className="space-y-6">
                    <div className="bg-green-50 rounded-2xl p-8 border border-green-100 flex items-center justify-between">
                      <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-green-600 shadow-sm">
                              <CheckCircle2 className="w-6 h-6" />
                          </div>
                          <div>
                              <h3 className="text-lg font-black text-green-900 mb-1">Pedido Importado de {clientName}</h3>
                              <p className="text-green-700 font-medium text-sm">Pronto para gerar licença offline ({plan})</p>
                          </div>
                      </div>
                      <span className="bg-white px-4 py-2 rounded-full text-xs font-black text-green-600 border border-green-200 uppercase">
                          PEDIDO VÁLIDO
                      </span>
                    </div>

                    <div className="bg-blue-50 rounded-2xl p-6 border border-blue-100">
                        <label className="block text-xs font-black text-blue-900 uppercase mb-3 tracking-widest pl-1">Vincular a um Plano Pago (Opcional)</label>
                        <select 
                          value={selectedSubscriptionId}
                          onChange={e => setSelectedSubscriptionId(e.target.value)}
                          className="w-full px-5 py-4 bg-white border border-blue-200 rounded-xl font-bold text-gray-900 outline-none focus:ring-2 focus:ring-blue-500"
                        >
                          <option value="">-- Gerar Licença Isolada (Sem Vínculo) --</option>
                          {subscriptions.map(s => (
                            <option key={s.id} value={s.id}>
                              {s.clientName} ({s.plan}) - {s.usedLicenses}/{s.maxLicenses} Licenças Usadas
                            </option>
                          ))}
                        </select>
                        <p className="text-[10px] text-blue-700 mt-2 italic">* Se selecionado, contará como uma licença usada no plano do cliente.</p>
                    </div>
                   </div>
                )}

                <div className="mt-12">
                   <h3 className="text-xl font-black text-gray-900 mb-8 border-b border-gray-50 pb-4">Formulário de Licença</h3>
                   
                   <div className="grid grid-cols-2 gap-8">
                      <div className="space-y-2">
                        <label className="text-sm font-black text-gray-700">Nome do Cliente</label>
                        <input 
                          type="text" 
                          value={clientName}
                          onChange={(e) => setClientName(e.target.value)}
                          placeholder="Nome completo"
                          className="w-full px-5 py-4 bg-gray-50 border border-gray-100 rounded-xl font-medium focus:ring-2 focus:ring-blue-100 focus:bg-white outline-none transition-all"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-black text-gray-700">Plano</label>
                        <select 
                          value={plan}
                          onChange={(e) => setPlan(e.target.value)}
                          className="w-full px-5 py-4 bg-gray-50 border border-gray-100 rounded-xl font-medium focus:ring-2 focus:ring-blue-100 focus:bg-white outline-none transition-all appearance-none cursor-pointer"
                        >
                          <option>Basico</option>
                          <option>Pro</option>
                          <option>Empresarial</option>
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-black text-gray-700">Device Hash</label>
                        <input 
                          type="text" 
                          value={deviceHash}
                          readOnly
                          placeholder="Hash do dispositivo"
                          disabled
                          className="w-full px-5 py-4 bg-gray-100 border border-gray-100 rounded-xl font-mono text-xs text-gray-500"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-black text-gray-700">Validade (meses)</label>
                        <input 
                          type="text" 
                          value="1 mês"
                          readOnly
                          className="w-full px-5 py-4 bg-gray-100 border border-gray-100 rounded-xl font-medium text-gray-500 cursor-not-allowed"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-black text-gray-700">Valor Unitário</label>
                        <div className="w-full px-5 py-4 bg-blue-50 border border-blue-100 rounded-xl font-black text-blue-600 flex items-center gap-2">
                           <DollarSign className="w-4 h-4" />
                           {PLAN_PRICES[plan] || '---'}
                        </div>
                      </div>
                      <div className="space-y-2 col-span-2">
                        <label className="text-sm font-black text-gray-700">Notas / Observações (Opcional)</label>
                        <textarea 
                          value={notes}
                          onChange={(e) => setNotes(e.target.value)}
                          placeholder="Ex: Licença nº 001 - Enviada via WhatsApp"
                          className="w-full px-5 py-4 bg-gray-50 border border-gray-100 rounded-xl font-medium focus:ring-2 focus:ring-blue-100 focus:bg-white outline-none transition-all h-24 resize-none"
                        />
                      </div>
                   </div>

                   <div className="flex justify-end gap-4 mt-12">
                      <button 
                         onClick={() => {
                           setClientName('');
                           setDeviceHash('');
                           setPendingEnc('');
                           setImportStatus('idle');
                           setSelectedSubscriptionId('');
                           setNotes('');
                         }}
                         className="px-8 py-4 text-gray-500 font-black hover:bg-gray-50 rounded-xl transition-all"
                      >
                        Limpar
                      </button>
                      <button 
                        onClick={handleGenerateRealLicense}
                        className="px-8 py-4 bg-blue-600 text-white font-black rounded-xl hover:bg-blue-700 shadow-lg shadow-blue-100 transition-all flex items-center gap-3"
                      >
                        <Key className="w-5 h-5" />
                        Gerar Licença
                      </button>
                   </div>
                </div>
              </div>
            </motion.div>
          )}

          {activePage === 'management' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
               <div>
                <h2 className="text-3xl font-black text-gray-900 leading-none">{t('admin.nav.history')}</h2>
                <p className="text-gray-500 mt-2 font-medium">{t('admin.history.subtitle')}</p>
              </div>

              <div className="bg-white rounded-3xl border border-gray-50 shadow-sm p-8">
                <div className="flex justify-between items-center mb-8">
                   <div className="flex gap-4">
                      <button className="px-5 py-2.5 bg-green-500 text-white rounded-xl text-sm font-bold flex items-center gap-2">
                        <Download className="w-4 h-4" /> {t('admin.history.export')} CSV
                      </button>
                   </div>
                   <div className="flex gap-2 p-1 bg-gray-50 rounded-xl">
                      {[t('common.all'), t('dashboard.active'), 'Expiradas', 'Revogadas'].map((filter) => (
                        <button key={filter} className={`px-4 py-2 rounded-lg text-xs font-black transition-all ${filter === t('common.all') ? 'bg-blue-600 text-white' : 'text-gray-400 hover:text-gray-600'}`}>
                          {filter}
                        </button>
                      ))}
                   </div>
                </div>

                {generatedLicenses.length === 0 ? (
                  <div className="text-center py-12 text-gray-400 font-medium italic">
                    Nenhuma licença encontrada
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead>
                        <tr className="border-b border-gray-50 text-[10px] font-black text-gray-400 uppercase tracking-widest">
                          <th className="pb-4">ID</th>
                          <th className="pb-4">Cliente / Dispositivo</th>
                          <th className="pb-4">Plano</th>
                          <th className="pb-4">Valor</th>
                          <th className="pb-4">Expiração</th>
                          <th className="pb-4">Status</th>
                          <th className="pb-4 text-right">Ações</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-50">
                        {generatedLicenses.map((lic) => (
                          <tr key={lic.id} className="group hover:bg-gray-50/50 transition-colors">
                            <td className="py-4 font-mono text-[10px] text-gray-400">{lic.id}</td>
                            <td className="py-4">
                              <p className="text-sm font-bold text-gray-900">{lic.client}</p>
                              <p className="text-[10px] text-gray-400 font-mono flex items-center gap-1">
                                {lic.subscriptionId ? <span className="text-blue-500 font-black uppercase">Plano Ativo</span> : <span className="text-gray-400 italic">Avulsa</span>}
                                {lic.deviceId}
                              </p>
                            </td>
                            <td className="py-4">
                              <span className="px-2 py-1 bg-blue-50 text-blue-600 rounded-lg text-[10px] font-black uppercase">
                                {lic.plan}
                              </span>
                            </td>
                            <td className="py-4 text-[10px] font-black text-gray-900">
                               {PLAN_PRICES[lic.plan as keyof typeof PLAN_PRICES] || '---'}
                            </td>
                            <td className="py-4 text-xs font-bold text-gray-600">
                              {new Date(lic.expiry).toLocaleDateString()}
                            </td>
                            <td className="py-4">
                              <span className="px-2 py-1 bg-green-50 text-green-600 rounded-lg text-[10px] font-black uppercase">
                                {lic.status}
                              </span>
                            </td>
                            <td className="py-4 text-right">
                               <div className="flex justify-end gap-2 pr-2">
                                  <button 
                                    onClick={() => setVisualizingLicense(lic)}
                                    className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
                                    title="Visualizar Detalhes"
                                  >
                                    <Eye className="w-4 h-4" />
                                  </button>
                                  <button 
                                    onClick={() => { setExportingLicense(lic); setShowExportModal(true); }}
                                    className="p-2 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-lg transition-all"
                                    title="Exportar Licença"
                                  >
                                    <Share2 className="w-4 h-4" />
                                  </button>
                                  <button 
                                    onClick={() => handleDeleteLicense(lic.id, lic.client)}
                                    className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                                    title="Eliminar"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                               </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Modal de Visualizar Licença */}
        <AnimatePresence>
          {visualizingLicense && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-white rounded-[32px] shadow-2xl w-full max-w-xl overflow-hidden"
              >
                <div className="p-8 border-b border-gray-50 flex justify-between items-center">
                   <div>
                      <h4 className="text-lg font-black text-gray-900">{t('admin.modals.details.title')}</h4>
                      <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mt-1">ID: {visualizingLicense.id}</p>
                   </div>
                   <button 
                    onClick={() => setVisualizingLicense(null)}
                    className="p-2 hover:bg-gray-50 rounded-xl transition-all"
                   >
                    <Plus className="w-5 h-5 rotate-45 text-gray-400" />
                   </button>
                </div>
                
                <div className="p-8 space-y-6">
                  <div className="grid grid-cols-2 gap-6">
                     <div className="space-y-1">
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-wider">{t('admin.modals.details.client')}</p>
                        <p className="text-sm font-bold text-gray-900">{visualizingLicense.client}</p>
                     </div>
                     <div className="space-y-1">
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-wider">{t('admin.modals.details.plan')}</p>
                        <span className="px-2 py-1 bg-blue-50 text-blue-600 rounded-lg text-[10px] font-black uppercase">
                          {visualizingLicense.plan}
                        </span>
                     </div>
                     <div className="space-y-1 col-span-2">
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-wider">{t('admin.modals.details.device')}</p>
                        <p className="text-xs font-mono text-gray-500 bg-gray-50 p-3 rounded-xl border border-gray-100">{visualizingLicense.deviceId}</p>
                     </div>
                     <div className="space-y-1">
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-wider">{t('admin.modals.details.issuedAt')}</p>
                        <p className="text-sm font-bold text-gray-900">{new Date(visualizingLicense.issuedAt).toLocaleString()}</p>
                     </div>
                     <div className="space-y-1">
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-wider">{t('admin.modals.details.expiry')}</p>
                        <p className="text-sm font-bold text-gray-900">{new Date(visualizingLicense.expiry).toLocaleDateString()}</p>
                     </div>
                     {visualizingLicense.notes && (
                       <div className="space-y-1 col-span-2">
                          <p className="text-[10px] font-black text-gray-400 uppercase tracking-wider">{t('admin.modals.details.notes')}</p>
                          <p className="text-sm font-medium text-gray-600 italic">"{visualizingLicense.notes}"</p>
                       </div>
                     )}
                  </div>
                </div>

                <div className="p-8 bg-gray-50 flex gap-4">
                   <button 
                    onClick={() => { setExportingLicense(visualizingLicense); setShowExportModal(true); setVisualizingLicense(null); }}
                    className="flex-1 py-4 bg-blue-600 text-white font-black rounded-2xl hover:bg-blue-700 transition-all flex items-center justify-center gap-2"
                   >
                    <Download className="w-5 h-5" /> {t('admin.modals.details.export')}
                   </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Modal de Exportação */}
        <AnimatePresence>
          {showExportModal && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-white rounded-[32px] shadow-2xl w-full max-w-sm overflow-hidden"
              >
                <div className="p-6 border-b border-gray-50 flex justify-between items-center bg-gray-50">
                   <h4 className="text-sm font-black text-gray-900 uppercase">{t('admin.modals.export.title')}</h4>
                   <button 
                    onClick={() => setShowExportModal(false)}
                    className="p-1 hover:bg-white rounded-lg transition-all shadow-sm"
                   >
                    <Plus className="w-4 h-4 rotate-45 text-gray-400" />
                   </button>
                </div>

                <div className="p-8 space-y-4">
                  <p className="text-xs text-gray-500 font-bold text-center mb-4">{t('admin.modals.export.subtitle')} <span className="text-gray-900">{exportingLicense?.client}</span></p>
                  
                  <button 
                    onClick={() => handleExport('pdf')}
                    className="w-full p-4 bg-white border border-gray-100 rounded-2xl flex items-center gap-4 hover:border-blue-100 hover:bg-blue-50 transition-all"
                  >
                    <div className="p-2 bg-red-50 text-red-500 rounded-lg"><FileText className="w-5 h-5" /></div>
                    <div className="text-left">
                       <p className="text-sm font-black text-gray-900">{t('admin.modals.export.pdf')}</p>
                       <p className="text-[10px] text-gray-400 font-bold uppercase">{t('admin.modals.export.pdfSub')}</p>
                    </div>
                  </button>

                  <button 
                    onClick={() => handleExport('csv')}
                    className="w-full p-4 bg-white border border-gray-100 rounded-2xl flex items-center gap-4 hover:border-blue-100 hover:bg-blue-50 transition-all"
                  >
                    <div className="p-2 bg-green-50 text-green-500 rounded-lg"><FileUp className="w-5 h-5" /></div>
                    <div className="text-left">
                       <p className="text-sm font-black text-gray-900">{t('admin.modals.export.csv')}</p>
                       <p className="text-[10px] text-gray-400 font-bold uppercase">{t('admin.modals.export.csvSub')}</p>
                    </div>
                  </button>

                  <button 
                    onClick={() => handleExport('json')}
                    className="w-full p-4 bg-white border border-gray-100 rounded-2xl flex items-center gap-4 hover:border-blue-100 hover:bg-blue-50 transition-all"
                  >
                    <div className="p-2 bg-blue-50 text-blue-500 rounded-lg"><Key className="w-5 h-5" /></div>
                    <div className="text-left">
                       <p className="text-sm font-black text-gray-900">{t('admin.modals.export.json')}</p>
                       <p className="text-[10px] text-gray-400 font-bold uppercase">{t('admin.modals.export.jsonSub')}</p>
                    </div>
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
