import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useTranslation } from 'react-i18next';
import { 
  Globe, 
  Moon, 
  Sun, 
  Cpu, 
  Download, 
  Lock, 
  ShieldCheck, 
  Database, 
  Trash2, 
  RefreshCw,
  Save,
  ChevronDown,
  RotateCcw
} from 'lucide-react';
import { AppSettings } from '../types';

interface SettingsProps {
  settings: AppSettings;
  onUpdate: (settings: AppSettings) => void;
  onExportBackup: () => void;
  onImportBackup: () => void;
  onClearData: () => void;
}

export default function Settings({ 
  settings, 
  onUpdate, 
  onExportBackup, 
  onImportBackup, 
  onClearData 
}: SettingsProps) {
  const { t, i18n } = useTranslation();
  const [localSettings, setLocalSettings] = useState<AppSettings>(settings);
  const [isLangMenuOpen, setIsLangMenuOpen] = useState(false);

  const languages = [
    { id: 'pt', label: 'Português(Angola)', flag: '🇦🇴' },
    { id: 'en', label: 'English', flag: '🇺🇸' },
    { id: 'fr', label: 'Français', flag: '🇫🇷' },
  ];

  const currentLang = languages.find(l => l.id === localSettings.language) || languages[0];

  const handleChange = (path: string, value: any) => {
    const newSettings = { ...localSettings };
    const parts = path.split('.');
    
    if (parts.length === 1) {
      (newSettings as any)[parts[0]] = value;
    } else if (parts.length === 2) {
      (newSettings as any)[parts[0]] = {
        ...(newSettings as any)[parts[0]],
        [parts[1]]: value
      };
    } else if (parts.length === 3) {
      (newSettings as any)[parts[0]][parts[1]] = {
        ...(newSettings as any)[parts[0]][parts[1]],
        [parts[2]]: value
      };
    }
    
    setLocalSettings(newSettings);
    
    // Auto-update language in i18n if changed
    if (path === 'language') {
        const langCode = value.split('-')[0];
        i18n.changeLanguage(langCode);
    }
  };

  const handleSave = () => {
    onUpdate(localSettings);
  };

  const handleThemeChange = (theme: 'light' | 'dark') => {
    handleChange('theme', theme);
    onUpdate({ ...localSettings, theme });
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-5xl mx-auto pb-12"
    >
      <div className="mb-8">
        <h1 className="text-3xl font-black text-gray-900 tracking-tight">{t('settings.title')}</h1>
        <p className="text-gray-500 font-medium">{t('settings.subtitle')}</p>
      </div>

      <div className="space-y-8">
        {/* General Preferences */}
        <section className="bg-white rounded-[40px] p-10 border border-gray-100 shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-64 h-64 bg-blue-50/30 rounded-full blur-3xl -mr-32 -mt-32 transition-colors group-hover:bg-blue-100/30" />
          
          <div className="flex items-center gap-4 mb-10 relative">
            <div className="p-3 bg-blue-50 rounded-2xl">
              <Globe className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <h2 className="text-xl font-black text-gray-900 tracking-tight">{t('settings.general.title')}</h2>
              <p className="text-sm text-gray-400 font-medium">{t('settings.general.subtitle')}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 relative">
            <div className="space-y-3">
              <label className="block text-xs font-black text-gray-900 px-1 uppercase tracking-widest opacity-60">
                {t('settings.general.language')}
              </label>
              <div className="relative">
                <button 
                  onClick={() => setIsLangMenuOpen(!isLangMenuOpen)}
                  className="w-full flex items-center justify-between bg-gray-50/50 border border-transparent rounded-[20px] px-5 py-4.5 text-sm font-bold text-gray-900 transition-all cursor-pointer outline-none shadow-sm hover:bg-white hover:border-gray-200"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xl">{currentLang.flag}</span>
                    <span>{currentLang.label}</span>
                  </div>
                  <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform ${isLangMenuOpen ? 'rotate-180' : ''}`} />
                </button>

                <AnimatePresence>
                  {isLangMenuOpen && (
                    <>
                      <div className="fixed inset-0 z-10" onClick={() => setIsLangMenuOpen(false)} />
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.95, y: -10 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95, y: -10 }}
                        className="absolute left-0 right-0 mt-2 bg-white rounded-2xl shadow-xl border border-gray-100 py-2 z-20"
                      >
                        {languages.map((lang) => (
                          <button
                            key={lang.id}
                            onClick={() => {
                              handleChange('language', lang.id);
                              setIsLangMenuOpen(false);
                            }}
                            className={`flex items-center w-full px-5 py-3 text-sm transition-all ${
                              localSettings.language === lang.id 
                                ? 'bg-blue-50 text-blue-600 font-bold' 
                                : 'text-gray-600 hover:bg-gray-50'
                            }`}
                          >
                            <span className="mr-3 text-xl">{lang.flag}</span>
                            {lang.label}
                          </button>
                        ))}
                      </motion.div>
                    </>
                  )}
                </AnimatePresence>
              </div>
              <p className="text-[11px] text-gray-400 font-medium px-2">{t('settings.general.languageHint')}</p>
            </div>

            <div className="space-y-3">
              <label className="block text-xs font-black text-gray-900 px-1 uppercase tracking-widest opacity-60">
                {t('settings.general.timezone')}
              </label>
              <div className="relative group/select">
                <select 
                  value={localSettings.timezone}
                  onChange={(e) => handleChange('timezone', e.target.value)}
                  className="w-full bg-gray-50/50 border border-transparent rounded-[20px] px-5 py-4.5 text-sm font-bold text-gray-900 appearance-none focus:bg-white focus:border-blue-500 focus:ring-4 focus:ring-blue-500/5 transition-all cursor-pointer outline-none shadow-sm"
                >
                  <option>(UTC-03:00) Brasília</option>
                  <option>(UTC+01:00) Luanda</option>
                  <option>(UTC+00:00) Lisboa</option>
                </select>
                <div className="absolute right-5 top-1/2 -translate-y-1/2 p-1.5 bg-white rounded-lg shadow-sm pointer-events-none">
                  <ChevronDown className="w-3.5 h-3.5 text-gray-400 group-hover/select:text-blue-500 transition-colors" />
                </div>
              </div>
              <p className="text-[11px] text-gray-400 font-medium px-2">{t('settings.general.timezoneHint')}</p>
            </div>

            <div className="space-y-3">
              <label className="block text-xs font-black text-gray-900 px-1 uppercase tracking-widest opacity-60">
                {t('settings.general.dateFormat')}
              </label>
              <div className="relative group/select">
                <select 
                  value={localSettings.dateFormat}
                  onChange={(e) => handleChange('dateFormat', e.target.value)}
                  className="w-full bg-gray-50/50 border border-transparent rounded-[20px] px-5 py-4.5 text-sm font-bold text-gray-900 appearance-none focus:bg-white focus:border-blue-50 focus:ring-4 focus:ring-blue-500/5 transition-all cursor-pointer outline-none shadow-sm"
                >
                  <option value="DD/MM/AAAA">DD/MM/AAAA</option>
                  <option value="MM/DD/AAAA">MM/DD/AAAA</option>
                  <option value="AAAA-MM-DD">AAAA-MM-DD</option>
                </select>
                <div className="absolute right-5 top-1/2 -translate-y-1/2 p-1.5 bg-white rounded-lg shadow-sm pointer-events-none">
                  <ChevronDown className="w-3.5 h-3.5 text-gray-400 group-hover/select:text-blue-500 transition-colors" />
                </div>
              </div>
              <p className="text-[11px] text-gray-400 font-medium px-2">{t('extraction.preview')}: {new Date().toLocaleDateString()}</p>
            </div>

            <div className="space-y-3">
              <label className="block text-xs font-black text-gray-900 px-1 uppercase tracking-widest opacity-60">
                {t('settings.general.theme')}
              </label>
              <div className="flex bg-gray-100/50 p-2 rounded-[24px] border border-gray-100 dark:bg-gray-800/20">
                <button 
                  onClick={() => handleThemeChange('light')}
                  className={`flex-1 flex items-center justify-center gap-3 py-3.5 text-xs font-black rounded-[18px] transition-all ${localSettings.theme === 'light' ? 'bg-blue-600 text-white shadow-xl shadow-blue-100' : 'text-gray-400 hover:text-gray-600'}`}
                >
                  <Sun className="w-4 h-4" /> {t('settings.general.light')}
                </button>
                <button 
                  onClick={() => handleThemeChange('dark')}
                  className={`flex-1 flex items-center justify-center gap-3 py-3.5 text-xs font-black rounded-[18px] transition-all ${localSettings.theme === 'dark' ? 'bg-blue-600 text-white shadow-xl shadow-blue-100' : 'text-gray-400 hover:text-gray-600'}`}
                >
                  <Moon className="w-4 h-4" /> {t('settings.general.dark')}
                </button>
              </div>
              <p className="text-[11px] text-gray-400 font-medium px-2">{t('settings.general.themeHint')}</p>
            </div>
          </div>
        </section>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* OCR Settings */}
          <section className="bg-white rounded-[40px] p-10 border border-gray-100 shadow-sm flex flex-col">
            <div className="flex items-center gap-4 mb-10">
              <div className="p-3 bg-purple-50 rounded-2xl">
                <Cpu className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <h2 className="text-xl font-black text-gray-900 tracking-tight">{t('settings.ocr.title')}</h2>
                <p className="text-sm text-gray-400 font-medium">{t('settings.ocr.subtitle')}</p>
              </div>
            </div>

            <div className="space-y-5 flex-1">
              {[
                { id: 'highQuality', label: t('settings.ocr.highQuality'), desc: t('settings.ocr.highQualityDesc') },
                { id: 'autoLanguage', label: t('settings.ocr.autoLanguage'), desc: t('settings.ocr.autoLanguageDesc') },
                { id: 'autoCorrection', label: t('settings.ocr.autoCorrection'), desc: t('settings.ocr.autoCorrectionDesc') },
                { id: 'preserveFormatting', label: t('settings.ocr.preserveFormatting'), desc: t('settings.ocr.preserveFormattingDesc') },
              ].map((opt) => (
                <div key={opt.id} className="flex items-center justify-between p-5 bg-gray-50/30 rounded-[24px] border border-transparent hover:border-gray-100 hover:bg-white hover:shadow-sm transition-all group">
                  <div className="space-y-0.5">
                    <p className="text-sm font-black text-gray-900 group-hover:text-blue-600 transition-colors">{opt.label}</p>
                    <p className="text-[11px] text-gray-400 font-medium">{opt.desc}</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer" 
                      checked={(localSettings.ocr as any)[opt.id]}
                      onChange={(e) => handleChange(`ocr.${opt.id}`, e.target.checked)}
                    />
                    <div className="w-12 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-6 rtl:peer-checked:after:-translate-x-6 peer-checked:after:border-white after:content-[''] after:absolute after:top-[3px] after:start-[3px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-[18px] after:w-[18px] after:transition-all peer-checked:bg-blue-600"></div>
                  </label>
                </div>
              ))}
            </div>
          </section>

          {/* Export Settings */}
          <section className="bg-white rounded-[40px] p-10 border border-gray-100 shadow-sm flex flex-col">
            <div className="flex items-center gap-4 mb-10">
              <div className="p-3 bg-green-50 rounded-2xl">
                <Download className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <h2 className="text-xl font-black text-gray-900 tracking-tight">{t('settings.export.title')}</h2>
                <p className="text-sm text-gray-400 font-medium">{t('settings.export.subtitle')}</p>
              </div>
            </div>

            <div className="space-y-8 flex-1">
              <div className="space-y-3">
                <label className="block text-xs font-black text-gray-900 px-1 uppercase tracking-widest opacity-60">
                  {t('settings.export.format')}
                </label>
                <div className="relative group/select">
                  <select 
                    value={localSettings.export.format}
                    onChange={(e) => handleChange('export.format', e.target.value)}
                    className="w-full bg-gray-50/50 border border-transparent rounded-[20px] px-5 py-4.5 text-sm font-bold text-gray-900 appearance-none focus:bg-white focus:border-blue-500 transition-all cursor-pointer outline-none shadow-sm"
                  >
                    <option value="csv">CSV ({t('modals.export.csvSub')})</option>
                    <option value="json">JSON ({t('modals.export.jsonSub')})</option>
                    <option value="txt">TXT</option>
                  </select>
                  <div className="absolute right-5 top-1/2 -translate-y-1/2 p-1.5 bg-white rounded-lg shadow-sm pointer-events-none">
                    <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <label className="block text-xs font-black text-gray-900 px-1 uppercase tracking-widest opacity-60">
                  {t('settings.export.delimiter')}
                </label>
                <div className="relative group/select">
                  <select 
                    value={localSettings.export.delimiter}
                    onChange={(e) => handleChange('export.delimiter', e.target.value)}
                    className="w-full bg-gray-50/50 border border-transparent rounded-[20px] px-5 py-4.5 text-sm font-bold text-gray-900 appearance-none focus:bg-white focus:border-blue-500 transition-all cursor-pointer outline-none shadow-sm"
                  >
                    <option value=";">Ponto e vírgula (;)</option>
                    <option value=",">Vírgula (,)</option>
                    <option value="\t">Tabulação (\t)</option>
                  </select>
                  <div className="absolute right-5 top-1/2 -translate-y-1/2 p-1.5 bg-white rounded-lg shadow-sm pointer-events-none">
                    <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between p-5 bg-blue-50/30 rounded-[24px] border border-blue-100/50">
                <div className="space-y-0.5">
                  <p className="text-sm font-black text-gray-900">{t('settings.export.headers')}</p>
                  <p className="text-[11px] text-gray-400 font-medium">{t('settings.export.headersDesc')}</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    className="sr-only peer" 
                    checked={localSettings.export.includeHeaders}
                    onChange={(e) => handleChange('export.includeHeaders', e.target.checked)}
                  />
                  <div className="w-12 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-6 rtl:peer-checked:after:-translate-x-6 peer-checked:after:border-white after:content-[''] after:absolute after:top-[3px] after:start-[3px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-[18px] after:w-[18px] after:transition-all peer-checked:bg-blue-600"></div>
                </label>
              </div>
            </div>
          </section>
        </div>

        {/* Security Settings */}
        <section className="bg-white rounded-[40px] p-10 border border-gray-100 shadow-sm overflow-hidden relative">
          <div className="absolute top-0 right-0 w-32 h-32 bg-amber-50/50 blur-3xl -mr-16 -mt-16" />
          
          <div className="flex items-center justify-between mb-12 relative">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-amber-50 rounded-2xl">
                <Lock className="w-6 h-6 text-amber-600" />
              </div>
              <div>
                <h2 className="text-xl font-black text-gray-900 tracking-tight">{t('settings.security.title')}</h2>
                <p className="text-sm text-gray-400 font-medium">{t('settings.security.subtitle')}</p>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" defaultChecked />
              <div className="w-14 h-7 bg-gray-100 peer-focus:outline-none rounded-[20px] peer peer-checked:after:translate-x-7 rtl:peer-checked:after:-translate-x-7 peer-checked:after:border-white after:content-[''] after:absolute after:top-[4px] after:start-[4px] after:bg-white after:shadow-sm after:rounded-full after:h-[22px] after:w-[22px] after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="space-y-6">
              <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest">{t('settings.security.procedure')}</h3>
              <div className="space-y-5">
                {[
                  { label: t('settings.security.currentCode'), placeholder: '••••••' },
                  { label: t('settings.security.newCode'), placeholder: t('profile.newCode') },
                  { label: t('settings.security.confirm'), placeholder: t('settings.security.confirmPlaceholder') },
                ].map((input) => (
                  <div key={input.label} className="space-y-2.5">
                    <label className="text-[11px] font-black text-gray-900 px-1">{input.label}</label>
                    <input 
                      type="password" 
                      placeholder={input.placeholder} 
                      className="w-full bg-gray-50/50 border border-transparent rounded-[20px] px-6 py-4 text-sm focus:bg-white focus:border-blue-500 focus:ring-4 focus:ring-blue-500/5 outline-none transition-all shadow-sm" 
                    />
                  </div>
                ))}
                <button className="w-full py-4.5 bg-gray-900 text-white rounded-[20px] text-sm font-black shadow-xl shadow-gray-200 hover:bg-black transition-all active:scale-[0.98]">
                  {t('settings.security.update')}
                </button>
              </div>
            </div>

            <div className="bg-red-50/30 rounded-[32px] p-8 border border-red-100/50 flex flex-col justify-center gap-6">
              <div className="space-y-2">
                <p className="text-sm font-black text-red-600 flex items-center gap-2">
                  <Trash2 className="w-4 h-4" /> {t('settings.security.riskZone')}
                </p>
                <p className="text-[12px] text-red-500/60 font-medium leading-relaxed">
                  {t('settings.security.riskText')}
                </p>
              </div>
              <button className="w-full py-4 bg-white border-2 border-red-100 text-red-500 rounded-[20px] text-xs font-black hover:bg-red-50 hover:border-red-200 transition-all shadow-sm">
                {t('settings.security.disable')}
              </button>
            </div>
          </div>
        </section>

        {/* Data Management */}
        <section className="bg-white rounded-[40px] p-10 border border-gray-100 shadow-sm relative group">
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-indigo-50/30 rounded-full blur-3xl -ml-24 -mb-24" />
          
          <div className="flex items-center gap-4 mb-10">
            <div className="p-3 bg-indigo-50 rounded-2xl">
              <Database className="w-6 h-6 text-indigo-600" />
            </div>
            <div>
              <h2 className="text-xl font-black text-gray-900 tracking-tight">{t('settings.data.title')}</h2>
              <p className="text-sm text-gray-400 font-medium">{t('settings.data.subtitle')}</p>
            </div>
          </div>

          <div className="flex items-center gap-4 p-6 bg-blue-50/50 rounded-[28px] mb-10 border border-blue-100 relative">
            <div className="p-2.5 bg-white rounded-xl shadow-sm">
              <ShieldCheck className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-sm font-black text-blue-900">{t('settings.data.sovereignty')}</p>
              <p className="text-[11px] text-blue-600/70 font-medium">{t('settings.data.sovereigntyDesc')}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 mb-12">
            <div className="space-y-3">
              <label className="block text-xs font-black text-gray-900 px-1 uppercase tracking-widest opacity-60">
                {t('settings.data.retention')}
              </label>
              <div className="relative group/select">
                <select 
                  value={localSettings.data.retention}
                  onChange={(e) => handleChange('data.retention', parseInt(e.target.value))}
                  className="w-full bg-gray-50/50 border border-transparent rounded-[20px] px-5 py-4.5 text-sm font-bold text-gray-900 appearance-none focus:bg-white focus:border-blue-500 transition-all cursor-pointer outline-none shadow-sm"
                >
                  <option value={30}>{t('settings.data.retentionOptions.30')}</option>
                  <option value={90}>{t('settings.data.retentionOptions.90')}</option>
                  <option value={365}>{t('settings.data.retentionOptions.365')}</option>
                  <option value={0}>{t('settings.data.retentionOptions.0')}</option>
                </select>
                <div className="absolute right-5 top-1/2 -translate-y-1/2 p-1.5 bg-white rounded-lg shadow-sm">
                  <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
                </div>
              </div>
              <p className="text-[11px] text-gray-400 font-medium px-2 italic">{t('settings.data.retentionHint')}</p>
            </div>

            <div className="space-y-3">
              <label className="block text-xs font-black text-gray-900 px-1 uppercase tracking-widest opacity-60">
                {t('settings.data.activity')}
              </label>
              <div className="flex items-center justify-between p-4.5 bg-white border border-gray-100 rounded-[24px] shadow-sm">
                <p className="text-xs font-bold text-gray-500">{t('settings.data.activityDesc')}</p>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    className="sr-only peer" 
                    checked={localSettings.data.saveActivityHistory}
                    onChange={(e) => handleChange('data.saveActivityHistory', e.target.checked)}
                  />
                  <div className="w-12 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-6 rtl:peer-checked:after:-translate-x-6 peer-checked:after:border-white after:content-[''] after:absolute after:top-[3px] after:start-[3px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-[18px] after:w-[18px] after:transition-all peer-checked:bg-blue-600"></div>
                </label>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pb-4">
            <button 
              onClick={onExportBackup}
              className="flex items-center justify-center gap-3 px-8 py-5 bg-white border border-gray-100 text-gray-900 rounded-[24px] text-sm font-black hover:bg-gray-50 hover:shadow-lg hover:shadow-gray-100/50 transition-all active:scale-[0.98]"
            >
              <Download className="w-4 h-4 text-blue-500" /> {t('settings.data.backup')}
            </button>
            
            <button 
              onClick={onImportBackup}
              className="flex items-center justify-center gap-3 px-8 py-5 bg-white border border-gray-100 text-gray-900 rounded-[24px] text-sm font-black hover:bg-gray-50 hover:shadow-lg hover:shadow-gray-100/50 transition-all active:scale-[0.98]"
            >
              <RefreshCw className="w-4 h-4 text-indigo-500" /> {t('settings.data.restore')}
            </button>
          </div>

          <div className="pt-8 border-t border-gray-50 flex justify-center">
            <button 
              onClick={onClearData}
              className="flex items-center gap-2 text-xs text-red-400 hover:text-red-600 font-bold tracking-wide transition-all uppercase px-6 py-2 rounded-full hover:bg-red-50"
            >
              <Trash2 className="w-3.5 h-3.5" /> {t('settings.data.clearAll')}
            </button>
          </div>
        </section>
      </div>

      {/* Footer Actions */}
      <div className="mt-8 bg-white/50 backdrop-blur-sm border border-gray-100 p-6 rounded-[32px] flex items-center justify-end gap-4 shadow-sm">
        <button 
          onClick={() => setLocalSettings(settings)}
          className="flex items-center gap-2 px-8 py-4 bg-white border border-gray-200 text-gray-600 rounded-[18px] text-sm font-black hover:bg-gray-50 transition-all"
        >
          <RotateCcw className="w-4 h-4" /> {t('settings.actions.restoreDefaults')}
        </button>
        <button 
          onClick={handleSave}
          className="flex items-center gap-2 px-12 py-4 bg-blue-600 text-white rounded-[18px] text-sm font-black shadow-xl shadow-blue-100 hover:bg-blue-700 transition-all active:scale-[0.98]"
        >
          <Save className="w-4 h-4" /> {t('settings.actions.save')}
        </button>
      </div>
    </motion.div>
  );
}
