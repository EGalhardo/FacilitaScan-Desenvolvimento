/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
    ShieldCheck, 
    Smartphone,
    Download,
    Mail,
    ChevronRight,
    Play,
    WifiOff,
    Zap,
    FileText,
    PlayCircle,
    Star
} from 'lucide-react';
import { useTranslation } from 'react-i18next';

export function TutorialsPage() {
    const { t } = useTranslation();
    const tutorials = [
        {
            id: '1',
            title: t('tutorials.items.t1.title'),
            description: t('tutorials.items.t1.desc'),
            duration: '5:30',
            type: 'featured',
            color: 'purple'
        },
        {
            id: '2',
            title: t('tutorials.items.t2.title'),
            duration: '5:10',
            color: 'blue',
            bgColor: 'bg-blue-50',
            iconColor: 'bg-blue-600'
        },
        {
            id: '3',
            title: t('tutorials.items.t3.title'),
            duration: '8:45',
            color: 'green',
            bgColor: 'bg-green-50',
            iconColor: 'bg-green-600'
        },
        {
            id: '4',
            title: t('tutorials.items.t4.title'),
            duration: '6:20',
            color: 'orange',
            bgColor: 'bg-orange-50',
            iconColor: 'bg-orange-600'
        },
        {
            id: '5',
            title: t('tutorials.items.t5.title'),
            duration: '7:00',
            color: 'pink',
            bgColor: 'bg-pink-50',
            iconColor: 'bg-pink-600'
        }
    ];

    const featured = tutorials[0];
    const others = tutorials.slice(1);

    return (
        <div className="space-y-8 animate-fade-in pb-20">
            <header>
                <h1 className="text-3xl font-black text-gray-900 mb-2">{t('tutorials.title')}</h1>
                <p className="text-gray-600 font-medium">{t('tutorials.subtitle')}</p>
            </header>

            {/* Featured Tutorial */}
            <div className="bg-white rounded-[2rem] shadow-xl border border-gray-100 p-8 overflow-hidden group">
                <div className="flex items-center gap-2 mb-6">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-purple-50 text-purple-600 rounded-full text-[10px] font-black uppercase tracking-wider border border-purple-100">
                        <Star className="w-3 h-3 fill-current" /> {t('tutorials.featured')}
                    </span>
                </div>
                
                <div className="flex items-center gap-4 mb-8">
                    <div className="w-12 h-12 bg-purple-50 rounded-2xl flex items-center justify-center text-purple-600">
                        <PlayCircle className="w-7 h-7" />
                    </div>
                    <div>
                        <h2 className="text-2xl font-black text-gray-900">{featured.title}</h2>
                        <p className="text-gray-500 font-medium">{featured.description}</p>
                    </div>
                </div>

                <div className="relative aspect-video bg-gradient-to-br from-gray-100 to-gray-200 rounded-[2rem] flex flex-col items-center justify-center cursor-pointer hover:shadow-2xl transition-all duration-500 overflow-hidden group">
                    <div className="absolute inset-0 bg-black/5 group-hover:bg-black/0 transition-colors"></div>
                    <div className="w-20 h-20 bg-purple-600 text-white rounded-full flex items-center justify-center shadow-2xl group-hover:scale-110 transition-transform duration-500 relative z-10">
                        <Play className="w-10 h-10 fill-current ml-1" />
                    </div>
                    <div className="mt-4 text-center relative z-10">
                        <p className="font-black text-gray-800">{t('tutorials.clickToWatch')}</p>
                        <p className="text-sm font-bold text-gray-400">{t('tutorials.duration')}: {featured.duration}</p>
                    </div>
                </div>
            </div>

            {/* Grid Tutorials */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {others.map((item) => (
                    <div key={item.id} className="bg-white rounded-[2rem] shadow-lg border border-gray-100 p-6 hover:shadow-2xl transition-all duration-300 group cursor-pointer">
                        <div className="flex items-center gap-3 mb-6">
                            <div className={`w-8 h-8 ${item.bgColor} rounded-full flex items-center justify-center`}>
                                <PlayCircle className={`w-5 h-5 ${item.iconColor?.replace('bg-', 'text-')}`} />
                            </div>
                            <h3 className="text-lg font-black text-gray-900">{item.title}</h3>
                        </div>

                        <div className={`aspect-[16/9] ${item.bgColor} rounded-[1.5rem] flex flex-col items-center justify-center transition-transform group-hover:scale-[1.02] duration-300 relative overflow-hidden`}>
                            <div className={`w-14 h-14 ${item.iconColor} text-white rounded-full flex items-center justify-center shadow-xl group-hover:scale-110 transition-transform duration-500`}>
                                <Play className="w-6 h-6 fill-current ml-0.5" />
                            </div>
                            <div className="mt-4 text-center">
                                <p className="font-bold text-gray-700">{t('tutorials.watch')}</p>
                                <p className="text-sm font-bold text-gray-400 opacity-60">{item.duration}</p>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}

export function HelpPage() {
  const { t } = useTranslation();
  return (
    <div className="space-y-6 animate-fade-in max-w-4xl">
      <header>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">{t('help.title')}</h1>
        <p className="text-gray-600">{t('help.subtitle')}</p>
      </header>

      <div className="bg-white rounded-2xl shadow-md p-8 border border-gray-200">
        <h2 className="text-xl font-bold text-gray-900 mb-6 font-sans">{t('help.faq')}</h2>
        <div className="space-y-4">
          <FaqItem 
            question={t('help.questions.q1')} 
            answer={t('help.questions.a1')}
          />
          <FaqItem 
            question={t('help.questions.q2')} 
            answer={t('help.questions.a2')}
          />
          <FaqItem 
            question={t('help.questions.q3')} 
            answer={t('help.questions.a3')}
          />
          <FaqItem 
            question={t('help.questions.q4')} 
            answer={t('help.questions.a4')}
          />
          <FaqItem 
            question={t('help.questions.q5')} 
            answer={t('help.questions.a5')}
          />
          <FaqItem 
            question={t('help.questions.q6')} 
            answer={t('help.questions.a6')}
          />
          <FaqItem 
            question={t('help.questions.q7')} 
            answer={t('help.questions.a7')}
          />
          <FaqItem 
            question={t('help.questions.q8')} 
            answer={t('help.questions.a8')}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-green-50 border border-green-100 rounded-2xl p-6">
            <h3 className="font-bold text-green-900 flex items-center gap-2 mb-2">
                <Smartphone className="w-5 h-5" /> WhatsApp
            </h3>
            <p className="text-sm text-green-800 mb-4">{t('help.channels.whatsapp')}</p>
            <a href="https://wa.me/951006421" className="inline-block bg-green-600 text-white px-6 py-2 rounded-xl font-bold text-sm">{t('help.channels.contact')}</a>
        </div>
        <div className="bg-blue-50 border border-blue-100 rounded-2xl p-6">
            <h3 className="font-bold text-blue-900 flex items-center gap-2 mb-2">
                <Mail className="w-5 h-5" /> Email
            </h3>
            <p className="text-sm text-blue-800 mb-4">{t('help.channels.email')}</p>
            <a href="mailto:suporte@facilitascan.com" className="inline-block bg-blue-600 text-white px-6 py-2 rounded-xl font-bold text-sm">{t('help.channels.sendEmail')}</a>
        </div>
      </div>
    </div>
  );
}

function FaqItem({ question, answer }: { question: string, answer: string }) {
    return (
        <details className="group border-b border-gray-100 pb-4">
            <summary className="list-none flex items-center justify-between cursor-pointer focus:outline-none">
                <span className="font-bold text-gray-800 group-hover:text-blue-600 transition-colors">{question}</span>
                <ChevronRight className="w-5 h-5 text-gray-400 group-open:rotate-90 transition-transform" />
            </summary>
            <p className="mt-3 text-sm text-gray-600 leading-relaxed font-medium">{answer}</p>
        </details>
    );
}

export function AboutPage() {
    const { t } = useTranslation();
    return (
        <div className="animate-fade-in max-w-4xl space-y-8 pb-10">
            <header className="mb-8">
                <h1 className="text-3xl font-bold text-gray-900 mb-2">{t('about.title')}</h1>
                <p className="text-gray-600 font-medium text-lg">{t('about.subtitle')}</p>
            </header>

            <div className="bg-white rounded-[2.5rem] shadow-xl overflow-hidden border border-gray-100">
                <div className="bg-gradient-to-br from-blue-600 to-indigo-700 p-12 text-center text-white relative">
                    <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
                        <div className="absolute top-10 left-10 w-32 h-32 rounded-full bg-white blur-3xl"></div>
                        <div className="absolute bottom-10 right-10 w-32 h-32 rounded-full bg-blue-300 blur-3xl"></div>
                    </div>
                    <div className="mb-6 relative z-10 flex justify-center">
                        <img 
                            src="https://i.postimg.cc/jdtbwWnP/Icone-de-scanner-minimalista-em-vetor-novo.png" 
                            alt="FacilitaScan Logo" 
                            className="w-24 h-24 rounded-3xl shadow-2xl border-4 border-white/20 object-cover"
                        />
                    </div>
                    <h2 className="text-5xl font-black mb-1 tracking-tight">FacilitaScan</h2>
                    <p className="text-blue-100 text-xl font-medium mb-6">{t('about.tagline')}</p>
                    <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-white/20 backdrop-blur-md rounded-full border border-white/20 text-xs font-bold uppercase tracking-wider">
                        {t('about.version')} 1.0.0
                    </div>
                </div>

                <div className="p-10 md:p-12 space-y-12">
                    <section>
                        <div className="flex items-center gap-3 mb-6">
                            <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600">
                                <ShieldCheck className="w-6 h-6" />
                            </div>
                            <h3 className="text-2xl font-black text-gray-900">{t('about.offlineTitle')}</h3>
                        </div>
                        <p className="text-gray-600 text-lg leading-relaxed font-medium">
                            {t('about.offlineDesc')}
                        </p>
                    </section>

                    <section>
                        <h3 className="text-xl font-black text-gray-900 mb-8 flex items-center gap-2">
                            <div className="w-1 h-6 bg-blue-600 rounded-full"></div>
                            {t('about.featuresTitle')}
                        </h3>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                            <FeatureCard 
                                icon={<FileText className="w-6 h-6" />}
                                title={t('about.features.models')}
                                desc={t('about.features.modelsDesc')}
                                color="blue"
                            />
                            <FeatureCard 
                                icon={<Zap className="w-6 h-6" />}
                                title={t('about.features.extraction')}
                                desc={t('about.features.extractionDesc')}
                                color="green"
                            />
                            <FeatureCard 
                                icon={<WifiOff className="w-6 h-6" />}
                                title={t('about.features.offline')}
                                desc={t('about.features.offlineDesc')}
                                color="amber"
                            />
                            <FeatureCard 
                                icon={<Download className="w-6 h-6" />}
                                title={t('about.features.formats')}
                                desc={t('about.features.formatsDesc')}
                                color="purple"
                            />
                        </div>
                    </section>

                    <section className="bg-gray-50 rounded-[2rem] p-10 border border-gray-100 shadow-inner">
                        <div className="mb-8">
                            <h3 className="text-2xl font-black text-gray-900 mb-2 font-sans">{t('about.technical.title')}</h3>
                            <div className="w-12 h-1 bg-blue-600 rounded-full"></div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-y-6 gap-x-16">
                            <TechInfo label={t('about.version')} value="1.0.0" />
                            <TechInfo label={t('about.technical.appType')} value="Web App (PWA)" />
                            <TechInfo label={t('about.technical.storage')} value="Local (IndexedDB/LocalStorage)" />
                            <TechInfo label={t('about.technical.compatibility')} value="Desktop, Tablet, Mobile" />
                            <TechInfo label={t('about.technical.developer')} value="Edlasio Galhardo" />
                        </div>
                    </section>
                </div>

                <div className="px-12 py-8 bg-gray-50 border-t border-gray-100 text-center">
                    <p className="text-gray-400 text-sm font-bold">
                        {t('about.copyright')}
                    </p>
                    <p className="text-gray-300 text-[10px] font-black uppercase tracking-widest mt-2">
                        {t('about.footer')}
                    </p>
                </div>
            </div>
        </div>
    );
}

function FeatureCard({ icon, title, desc, color }: any) {
    const colors: any = {
        blue: 'bg-blue-50 text-blue-600',
        green: 'bg-green-50 text-green-600',
        amber: 'bg-amber-50 text-amber-600',
        purple: 'bg-purple-50 text-purple-600'
    };
    return (
        <div className="flex gap-4 p-5 rounded-2xl border border-gray-100 hover:border-blue-100 transition-colors bg-white shadow-sm group">
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${colors[color]} group-hover:scale-110 transition-transform`}>
                {icon}
            </div>
            <div>
                <h4 className="font-black text-gray-900">{title}</h4>
                <p className="text-sm text-gray-500 font-medium">{desc}</p>
            </div>
        </div>
    );
}

function TechInfo({ label, value }: { label: string, value: string }) {
    return (
        <div className="flex flex-col gap-1 group">
            <span className="text-gray-400 font-bold text-[10px] uppercase tracking-[0.15em]">{label}</span>
            <span className="text-gray-900 font-black text-base transition-colors group-hover:text-blue-600">
                {value}
            </span>
        </div>
    );
}

export function PlansPage() {
    const { t } = useTranslation();
    return (
        <div className="space-y-12 animate-fade-in max-w-6xl mx-auto py-8">
             <header className="text-center max-w-2xl mx-auto mb-16 px-4">
                <h1 className="text-4xl md:text-5xl font-black text-gray-900 mb-4 tracking-tight">{t('plans.title')}</h1>
                <p className="text-gray-600 text-lg">{t('plans.subtitle')}</p>
                <div className="w-20 h-1.5 bg-blue-600 mx-auto mt-6 rounded-full"></div>
            </header>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 px-4">
                <PlanCard 
                    name={t('plans.basic')}
                    price="45.000 Kz"
                    features={[`100 ${t('plans.features.extractions')}`, `10 ${t('plans.features.models')}`, `1 ${t('plans.features.licenses')}`, 'Exportação JSON/CSV/TXT', `${t('plans.features.support')} (48h)`]}
                    color="blue"
                />
                <PlanCard 
                    name="Pro"
                    price="120.000 Kz"
                    features={[`600 ${t('plans.features.extractions')} (120/PC)`, `40 ${t('plans.features.models')}`, `5 ${t('plans.features.licenses')}`, t('plans.features.facialLogin'), 'Exportação JSON/CSV/TXT', `${t('plans.features.support')} (24h)`]}
                    popular
                    color="blue"
                />
                <PlanCard 
                    name={t('plans.enterprise')}
                    price="350.000 Kz"
                    features={[`3.000 ${t('plans.features.extractions')} (300/PC)`, `200 ${t('plans.features.models')}`, `10 ${t('plans.features.licenses')}`, t('plans.features.facialLogin'), t('plans.features.api'), `${t('plans.features.support')} (24h)`]}
                    color="gray"
                />
            </div>
        </div>
    );
}

function PlanCard({ name, price, features, popular, color }: any) {
    const { t } = useTranslation();
    return (
        <div className={`group relative flex flex-col bg-white rounded-[2.5rem] p-10 border-2 transition-all duration-500 hover:scale-[1.02] hover:shadow-2xl ${popular ? 'border-blue-600 shadow-xl' : 'border-gray-100 shadow-lg hover:border-blue-200'}`}>
            <div className="mb-8">
                <h3 className="text-2xl font-black text-gray-900 mb-2">{name}</h3>
                <div className="flex items-baseline gap-1">
                    <span className="text-4xl font-black text-gray-900 tracking-tighter">{price}</span>
                    <span className="text-gray-400 font-bold">/{t('plans.monthly')}</span>
                </div>
            </div>

            <div className="h-px w-full bg-gray-100 mb-8"></div>

            <ul className="space-y-4 mb-10 flex-grow">
                {features.map((f: string) => (
                    <li key={f} className="flex items-start text-sm text-gray-600 font-semibold group/item">
                        <div className={`mt-0.5 mr-3 w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${popular ? 'bg-blue-600 text-white' : 'bg-blue-50 text-blue-600'}`}>
                            <ShieldCheck className="w-3 h-3" />
                        </div>
                        <span className="leading-snug">{f}</span>
                    </li>
                ))}
            </ul>

            <button className="w-full py-5 rounded-2xl font-black text-sm uppercase tracking-widest transition-all duration-300 bg-blue-600 text-white hover:bg-blue-700 border-2 border-blue-600 shadow-xl shadow-blue-200">
                {t('plans.startNow')}
            </button>
        </div>
    );
}
