/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  User, 
  Mail, 
  Smartphone, 
  Building2, 
  MapPin, 
  Save, 
  Shield, 
  Camera, 
  ShieldCheck, 
  Trash2,
  Lock,
  ArrowUpCircle,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useTranslation } from 'react-i18next';
import { UserProfile } from '../types';
import FaceAuthModal from './FaceAuthModal';
import { saveBiometricData, getBiometricData, deleteBiometricData } from '../lib/license';

interface ProfileProps {
  profile: UserProfile;
  onUpdate: (updated: UserProfile) => void;
}

export default function ProfileView({ profile, onUpdate }: ProfileProps) {
  const { t } = useTranslation();
  const [localProfile, setLocalProfile] = useState<UserProfile>(profile);
  const [showFaceModal, setShowFaceModal] = useState(false);
  const [showRemoveConfirm, setShowRemoveConfirm] = useState(false);
  const [hasBiometry, setHasBiometry] = useState(false);
  const [sensitivity, setSensitivity] = useState(0.62);
  const [passwords, setPasswords] = useState({ current: '', next: '', confirm: '' });

  useEffect(() => {
     checkBiometry();
  }, [profile.email]);

  const checkBiometry = async () => {
    const data = await getBiometricData(profile.email || 'default-local-user');
    setHasBiometry(!!data?.embeddings?.length);
  };

  const handleFaceSuccess = async (samples?: number[][]) => {
      if (samples) {
          await saveBiometricData(profile.email || 'default-local-user', samples);
          alert(t('profile.alerts.faceSuccess'));
          setHasBiometry(true);
      }
      setShowFaceModal(false);
  };

  const clearBiometry = async () => {
      await deleteBiometricData(profile.email || 'default-local-user');
      setHasBiometry(false);
      setShowRemoveConfirm(false);
      alert(t('profile.alerts.biometryRemoved'));
  };

  const handleSubmit = (section: string) => {
    onUpdate(localProfile);
    alert(`${section} ${t('profile.alerts.updated')}`);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setLocalProfile(prev => ({ ...prev, [name]: value }));
  };

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setPasswords(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="animate-fade-in pb-12">
      <header className="mb-8">
        <h1 className="text-3xl font-black text-gray-900 mb-1">{t('profile.title')}</h1>
        <p className="text-gray-600 font-medium tracking-tight whitespace-pre-line">{t('profile.subtitle')}</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Summary Card */}
        <div className="lg:col-span-4 sticky top-6">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-[32px] border border-gray-200 shadow-xl shadow-gray-200/50 overflow-hidden"
          >
            <div className="p-8 text-center border-b border-gray-100">
              <div className="relative inline-block mb-4">
                <div 
                  onClick={() => document.getElementById('profile-upload')?.click()}
                  className="w-24 h-24 rounded-[32px] overflow-hidden border-4 border-blue-100 shadow-inner group relative cursor-pointer bg-gray-100 flex items-center justify-center"
                >
                   {localProfile.avatar ? (
                     <img 
                      src={localProfile.avatar} 
                      alt="Profile" 
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                     />
                   ) : (
                     <User className="w-10 h-10 text-gray-400 group-hover:scale-110 transition-transform duration-500" />
                   )}
                   <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <Camera className="w-8 h-8 text-white" />
                   </div>
                </div>
                <input 
                  id="profile-upload"
                  type="file" 
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onload = (event) => {
                        const base64 = event.target?.result as string;
                        const updated = { ...localProfile, avatar: base64 };
                        setLocalProfile(updated);
                        onUpdate(updated);
                      };
                      reader.readAsDataURL(file);
                    }
                  }}
                />
              </div>
              <h2 className="text-xl font-black text-gray-900 leading-tight">{localProfile.firstName} {localProfile.lastName}</h2>
              <p className="text-sm font-bold text-gray-500 mt-1">{localProfile.email || 'usuario@ocrstudio.com'}</p>
            </div>
            
            <div className="grid grid-cols-2 divide-x divide-gray-100 py-6">
              <div className="text-center">
                <p className="text-lg font-black text-gray-900">2</p>
                <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">{t('profile.models')}</p>
              </div>
              <div className="text-center">
                <p className="text-lg font-black text-gray-900">4</p>
                <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">{t('profile.extractions')}</p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Right Column: Detailed Sections */}
        <div className="lg:col-span-8 space-y-6">
          {/* Informações Pessoais */}
          <motion.section 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white rounded-[24px] border border-gray-200 shadow-sm p-8"
          >
            <h3 className="text-lg font-black text-gray-900 mb-6">{t('profile.personalInfo')}</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">{t('profile.firstName')}</label>
                <input 
                  type="text" name="firstName" value={localProfile.firstName} onChange={handleChange}
                  className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:bg-white focus:ring-4 focus:ring-blue-50/50 focus:border-blue-200 transition-all font-medium text-sm text-gray-900" 
                  placeholder={t('profile.firstNamePlaceholder')}
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">{t('profile.lastName')}</label>
                <input 
                  type="text" name="lastName" value={localProfile.lastName} onChange={handleChange}
                  className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:bg-white focus:ring-4 focus:ring-blue-50/50 focus:border-blue-200 transition-all font-medium text-sm text-gray-900" 
                  placeholder={t('profile.lastNamePlaceholder')}
                />
              </div>
              <div className="sm:col-span-2 space-y-1.5 pt-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">{t('profile.email')}</label>
                <input 
                  type="email" name="email" value={localProfile.email} onChange={handleChange}
                  className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:bg-white focus:ring-4 focus:ring-blue-50/50 focus:border-blue-200 transition-all font-medium text-sm text-gray-900" 
                />
              </div>
              <div className="sm:col-span-2 space-y-1.5 pt-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">{t('profile.whatsapp')}</label>
                <input 
                  type="text" name="whatsapp" value={localProfile.whatsapp} onChange={handleChange}
                  className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:bg-white focus:ring-4 focus:ring-blue-50/50 focus:border-blue-200 transition-all font-medium text-sm text-gray-900" 
                  placeholder="+244 9XX XXX XXX"
                />
              </div>
            </div>
            <button 
              onClick={() => handleSubmit(t('profile.personalInfo'))}
              className="mt-8 px-8 py-4 bg-blue-600 text-white font-bold rounded-2xl shadow-lg shadow-blue-100 hover:bg-blue-700 transition-all active:scale-95 text-sm"
            >
              {t('profile.updateInfo')}
            </button>
          </motion.section>

          <motion.section 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white rounded-[24px] border border-gray-200 shadow-sm p-8"
          >
            <h3 className="text-lg font-black text-gray-900 mb-6">{t('profile.company')}</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">{t('profile.companyName')}</label>
                <input 
                  type="text" name="companyName" value={localProfile.companyName} onChange={handleChange}
                  className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:bg-white focus:ring-4 focus:ring-blue-50/50 focus:border-blue-200 transition-all font-medium text-sm text-gray-900" 
                  placeholder={t('profile.companyNamePlaceholder')}
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">{t('profile.nif')}</label>
                <input 
                  type="text" name="companyNif" value={localProfile.companyNif} onChange={handleChange}
                  className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:bg-white focus:ring-4 focus:ring-blue-50/50 focus:border-blue-200 transition-all font-medium text-sm text-gray-900" 
                  placeholder={t('profile.nifPlaceholder')}
                />
              </div>
              <div className="sm:col-span-2 space-y-1.5 pt-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">{t('profile.address')}</label>
                <input 
                  type="text" name="companyAddress" value={localProfile.companyAddress} onChange={handleChange}
                  className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:bg-white focus:ring-4 focus:ring-blue-50/50 focus:border-blue-200 transition-all font-medium text-sm text-gray-900" 
                   placeholder={t('profile.addressPlaceholder')}
                />
              </div>
            </div>
            <button 
              onClick={() => handleSubmit(t('profile.company'))}
              className="mt-8 px-8 py-4 bg-blue-600 text-white font-bold rounded-2xl shadow-lg shadow-blue-100 hover:bg-blue-700 transition-all active:scale-95 text-sm"
            >
              {t('profile.updateCompany')}
            </button>
          </motion.section>

          {/* Código de Acesso */}
          <motion.section 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-white rounded-[24px] border border-gray-200 shadow-sm p-8"
          >
            <h3 className="text-lg font-black text-gray-900 mb-6">{t('profile.accessCode')}</h3>
            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">{t('profile.currentCode')}</label>
                <input 
                  type="password" name="current" value={passwords.current} onChange={handlePasswordChange}
                  className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:bg-white focus:ring-4 focus:ring-blue-50/50 focus:border-blue-200 transition-all font-medium text-sm text-gray-900" 
                  placeholder="••••••••"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">{t('profile.newCode')}</label>
                <input 
                  type="password" name="next" value={passwords.next} onChange={handlePasswordChange}
                  className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:bg-white focus:ring-4 focus:ring-blue-50/50 focus:border-blue-200 transition-all font-medium text-sm text-gray-900" 
                  placeholder="••••••••"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">{t('profile.confirmNewCode')}</label>
                <input 
                  type="password" name="confirm" value={passwords.confirm} onChange={handlePasswordChange}
                  className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:bg-white focus:ring-4 focus:ring-blue-50/50 focus:border-blue-200 transition-all font-medium text-sm text-gray-900" 
                  placeholder="••••••••"
                />
              </div>
            </div>
            <button 
              onClick={() => handleSubmit(t('profile.accessCode'))}
              className="mt-8 px-8 py-4 bg-blue-600 text-white font-bold rounded-2xl shadow-lg shadow-blue-100 hover:bg-blue-700 transition-all active:scale-95 text-sm"
            >
              {t('profile.changeCode')}
            </button>
          </motion.section>

          {/* Login Facial */}
          <motion.section 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white rounded-[24px] border border-gray-200 shadow-sm p-8"
          >
            <h3 className="text-lg font-black text-gray-900 mb-6">{t('profile.faceLogin')}</h3>
            
            <div className={`p-4 rounded-xl border mb-8 flex items-center gap-3 ${hasBiometry ? 'bg-green-50 border-green-200 text-green-800' : 'bg-amber-50 border-amber-200 text-amber-800'}`}>
              {hasBiometry ? <CheckCircle2 className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
              <span className="text-xs font-bold leading-tight">
                {hasBiometry 
                  ? `${t('profile.biometryActive')} ${sensitivity}` 
                  : t('profile.biometryNone')
                }
              </span>
            </div>

            {hasBiometry && (
              <div className="space-y-6 mb-8">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">{t('profile.sensitivity')}</span>
                  <span className="text-sm font-black text-blue-700">{sensitivity}</span>
                </div>
                <input 
                  type="range" min="0.1" max="0.9" step="0.01" 
                  value={sensitivity} onChange={(e) => setSensitivity(parseFloat(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                />
                <p className="text-[10px] font-bold text-gray-500 italic">{t('profile.sensitivityHint')}</p>
                <button 
                  onClick={() => handleSubmit(t('profile.sensitivity'))}
                  className="w-full py-4 bg-blue-600 text-white font-bold rounded-2xl shadow-lg shadow-blue-100 hover:bg-blue-700 transition-all active:scale-95 text-sm"
                >
                  {t('profile.saveSensitivity')}
                </button>
              </div>
            )}

            <div className="flex flex-col sm:flex-row gap-3">
              <button 
                onClick={() => setShowFaceModal(true)}
                className="flex-1 py-4 bg-blue-700 text-white font-bold rounded-2xl shadow-lg shadow-blue-100 hover:bg-blue-800 transition-all active:scale-95 text-sm flex items-center justify-center gap-2"
              >
                <Camera className="w-4 h-4" /> {t('profile.registerFace')}
              </button>
              {hasBiometry && (
                <button 
                  onClick={() => setShowRemoveConfirm(true)}
                  className="flex-1 py-4 bg-gray-600 text-white font-bold rounded-2xl shadow-lg shadow-gray-200 hover:bg-gray-700 transition-all active:scale-95 text-sm flex items-center justify-center gap-2"
                >
                  <Trash2 className="w-4 h-4" /> {t('profile.clearBiometry')}
                </button>
              )}
            </div>
            <p className="mt-4 text-[10px] font-bold text-gray-500 text-center">{t('profile.biometryFooter')}</p>
          </motion.section>

          {/* Plano Atual */}
          <motion.section 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="bg-blue-600 rounded-[24px] p-8 text-white flex items-center justify-between overflow-hidden relative"
          >
            <div className="relative z-10">
               <p className="text-[10px] font-black text-blue-100 uppercase tracking-widest mb-2">{t('profile.planCurrent') || t('dashboard.plan')}</p>
               <h3 className="text-2xl font-black mb-1">{t('plans.free')}</h3>
               <p className="text-sm font-medium text-blue-100">{t('plans.unlimitedLocal')}</p>
            </div>
            <button className="relative z-10 px-8 py-3.5 bg-white text-blue-600 font-extrabold rounded-2xl hover:bg-blue-50 transition-all shadow-xl shadow-blue-900/20 active:scale-95 text-xs">
              {t('plans.upgrade')}
            </button>

            {/* Pattern Overlay */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -mr-20 -mt-20 blur-3xl pointer-events-none" />
            <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/5 rounded-full -ml-10 -mb-10 blur-2xl pointer-events-none" />
          </motion.section>
        </div>
      </div>

      {/* Face Auth Modal */}
      {showFaceModal && (
        <FaceAuthModal 
          mode="enroll"
          userId={profile.email || 'default-local-user'}
          onSuccess={handleFaceSuccess}
          onClose={() => setShowFaceModal(false)}
        />
      )}

      {/* Remove Biometry Confirm */}
      <AnimatePresence>
        {showRemoveConfirm && (
          <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white rounded-3xl shadow-2xl w-full max-w-sm overflow-hidden p-10 text-center space-y-6"
            >
              <div className="w-20 h-20 bg-red-50 text-red-600 rounded-[24px] flex items-center justify-center mx-auto">
                <Shield className="w-10 h-10" />
              </div>
              <div>
                <h3 className="text-2xl font-black text-gray-900">{t('profile.removeBiometryTitle')}</h3>
                <p className="text-sm text-gray-500 mt-2 font-medium leading-relaxed">
                  {t('profile.removeBiometryConfirm')}
                </p>
              </div>
              <div className="flex gap-3">
                <button 
                  onClick={() => setShowRemoveConfirm(false)}
                  className="flex-1 py-4 bg-gray-100 text-gray-600 font-bold rounded-2xl hover:bg-gray-200 transition-colors"
                >
                  {t('common.cancel')}
                </button>
                <button 
                  onClick={clearBiometry}
                  className="flex-1 py-4 bg-red-600 text-white font-black rounded-2xl shadow-lg shadow-red-100 hover:bg-red-700 transition-all active:scale-95"
                >
                  {t('dashboard.deleteFile.confirmAction')}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
