/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  FileText, 
  CheckCircle, 
  Files, 
  ArrowRight,
  Zap,
  Clock,
  ExternalLink,
  PlusCircle,
  FileSearch,
  Eye,
  Trash2,
  Download,
  X,
  Info,
  CheckCircle2,
  Table,
  Files as FilesIcon,
  RotateCcw,
  HelpCircle,
  Video,
  LifeBuoy,
  CreditCard,
  ShieldCheck
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { OCRModel, ExtractionResult, UserProfile } from '../types';

interface DashboardProps {
  stats: {
    models: number;
    extractions: number;
    files: number;
  };
  profile: UserProfile;
  licenseStatus: {
    valid: boolean;
    plan: string;
    expiry?: number;
    extractionsUsed: number;
    maxExtractions: number;
  };
  recentFiles: ExtractionResult[];
  onNavigate: (page: string) => void;
  onViewSelected: (ids: string[]) => void;
  onExportSelected: (ids: string[]) => void;
  onDeleteSelected: (ids: string[], skipConfirm?: boolean) => void;
  onResetLicense?: () => void;
}

export default function Dashboard({ 
    stats, 
    profile, 
    licenseStatus,
    recentFiles, 
    onNavigate,
    onViewSelected,
    onExportSelected,
    onDeleteSelected,
    onResetLicense
}: DashboardProps) {
  const { t } = useTranslation();
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [selectedFile, setSelectedFile] = useState<ExtractionResult | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [downloadConfirmId, setDownloadConfirmId] = useState<string | null>(null);

  const toggleSelect = (id: string) => {
    setSelectedIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '---';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleDownload = (result: ExtractionResult, format: 'json' | 'csv' | 'txt') => {
    if (format === 'json') {
      const dataStr = JSON.stringify(result.data, null, 2);
      const blob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = `extração_${result.fileName}.json`; a.click();
    } else if (format === 'csv') {
      const entries = Object.entries(result.data);
      const headers = entries.map(([key]) => `"${key.replace(/"/g, '""')}"`).join(";");
      const values = entries.map(([, value]) => `"${value.toString().replace(/"/g, '""')}"`).join(";");
      const csvContent = "\uFEFF" + headers + "\n" + values;
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = `extração_${result.fileName}.csv`; a.click();
    } else if (format === 'txt') {
      const textContent = Object.entries(result.data)
          .map(([key, value]) => `${key}: ${value}`)
          .join("\n");
      const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = `extração_${result.fileName}.txt`; a.click();
    }
    setDownloadConfirmId(null);
  };
  return (
    <div className="space-y-8 animate-fade-in">
      <header>
        <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">{t('dashboard.title')}</h1>
        <p className="text-gray-500 text-sm md:text-base">{t('dashboard.subtitle')}</p>
      </header>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard 
          label={t('dashboard.modelsCreated')} 
          value={stats.models} 
          icon={<FileText />}
          color="blue"
        />
        <StatCard 
          label={t('dashboard.extractionsPerformed')} 
          value={stats.extractions} 
          icon={<Zap />}
          color="blue"
          iconColor="text-green-600"
        />
        <StatCard 
          label={t('dashboard.filesProcessed')} 
          value={stats.files} 
          icon={<Files />}
          color="blue"
          iconColor="text-purple-600"
        />
      </div>

      {/* Quick Actions */}
      <section className="bg-white rounded-2xl shadow-md p-6 border border-gray-200">
        <h2 className="text-lg font-bold text-gray-900 mb-5 flex items-center">
          <span className="bg-gradient-to-r from-blue-600 to-purple-600 w-1.5 h-6 rounded-full mr-3"></span>
          {t('dashboard.quickActions')}
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <ActionButton 
            label={t('nav.createModel')} 
            icon={<PlusCircle className="w-6 h-6" />}
            color="blue"
            onClick={() => onNavigate('create-model')}
          />
          <ActionButton 
            label={t('nav.extract')} 
            icon={<FileSearch className="w-6 h-6" />}
            color="green"
            onClick={() => onNavigate('extract')}
          />
          <ActionButton 
            label={t('dashboard.viewAll')} 
            icon={<Files className="w-6 h-6" />}
            color="purple"
            onClick={() => onNavigate('files')}
          />
        </div>
      </section>

      {/* Subscription Info */}
      <section className="bg-white rounded-2xl shadow-md border border-gray-200 overflow-hidden">
        <div 
          className="p-5 border-b border-gray-200 flex justify-between items-center"
          style={{ backgroundColor: '#155DFC' }}
        >
          <h2 className="text-lg font-bold text-white">{t('dashboard.subscription')}</h2>
          {onResetLicense && (
            <button 
              type="button"
              onClick={onResetLicense}
              className="px-4 py-2 bg-white/20 hover:bg-red-500 hover:text-white text-white rounded-xl transition-all flex items-center gap-2 group border border-white/10 active:scale-95 shadow-sm relative z-50"
            >
              <RotateCcw className="w-4 h-4 group-hover:rotate-180 transition-transform duration-500" />
              <div className="text-left pointer-events-none">
                <p className="text-[10px] font-black uppercase tracking-widest leading-none opacity-70">{t('dashboard.test')}</p>
                <p className="text-xs font-bold leading-none mt-1">{t('dashboard.clearLicense')}</p>
              </div>
            </button>
          )}
        </div>
        <div className="p-5 grid grid-cols-1 md:grid-cols-4 gap-4">
          <InfoBox label={t('dashboard.plan')} value={licenseStatus.plan} color="blue" icon={<CreditCard className="w-5 h-5" />} />
          <InfoBox label={t('dashboard.extractions')} value={`${licenseStatus.extractionsUsed} / ${licenseStatus.maxExtractions >= 999999 ? t('common.unlimited') || 'ILIMITADO' : licenseStatus.maxExtractions}`} color="blue" icon={<Zap className="w-5 h-5" />} />
          <InfoBox label={t('dashboard.expiry')} value={licenseStatus.expiry ? new Date(licenseStatus.expiry).toLocaleDateString() : 'N/A'} color="blue" icon={<Clock className="w-5 h-5" />} />
          <InfoBox 
            label={t('dashboard.status')} 
            value={
              licenseStatus.plan === 'Trial' 
                ? (licenseStatus.valid 
                    ? t('dashboard.trialStatus', { days: Math.max(0, Math.ceil(((licenseStatus.expiry || 0) - Date.now()) / (1000 * 60 * 60 * 24))) })
                    : t('dashboard.trialStatusExpired'))
                : (licenseStatus.valid ? t('dashboard.active') : t('dashboard.pending'))
            } 
            color={licenseStatus.plan === 'Trial' ? 'indigo' : 'blue'} 
            icon={<ShieldCheck className="w-5 h-5" />} 
          />
        </div>
      </section>

      {/* Recent Files */}
      <section className="bg-white rounded-2xl shadow-md border border-gray-200 overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-200 bg-blue-600 flex items-center justify-between">
          <h2 className="text-lg font-bold text-white">{t('dashboard.recentFiles')}</h2>
          <div className="flex items-center gap-3">
            {selectedIds.length > 0 && (
                <div className="flex items-center gap-2 animate-fade-in">
                    <button onClick={() => onViewSelected(selectedIds)} title={t('common.view')} className="p-1.5 bg-white/20 hover:bg-white/30 text-white rounded-lg transition-colors">
                        <Eye className="w-4 h-4" />
                    </button>
                    <button onClick={() => onExportSelected(selectedIds)} title={t('common.export')} className="p-1.5 bg-white/20 hover:bg-white/30 text-white rounded-lg transition-colors">
                        <Download className="w-4 h-4" />
                    </button>
                    <button onClick={() => onDeleteSelected(selectedIds)} title={t('common.delete')} className="p-1.5 bg-red-500/80 hover:bg-red-500 text-white rounded-lg transition-colors">
                        <Trash2 className="w-4 h-4" />
                    </button>
                </div>
            )}
            <button 
                onClick={() => onNavigate('files')}
                className="text-white text-sm font-semibold flex items-center hover:underline"
            >
                {t('dashboard.viewAll')} <ArrowRight className="ml-1 w-4 h-4" />
            </button>
          </div>
        </div>
        <div className="p-0">
          {recentFiles.length > 0 ? (
            <div className="divide-y divide-gray-100">
              {recentFiles.map(file => (
                <div key={file.id} className={`p-4 flex items-center justify-between hover:bg-gray-50 transition-colors ${selectedIds.includes(file.id) ? 'bg-blue-50/50' : ''}`}>
                  <div className="flex items-center space-x-3">
                    <input 
                        type="checkbox" 
                        checked={selectedIds.includes(file.id)}
                        onChange={() => toggleSelect(file.id)}
                        className="w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500 cursor-pointer" 
                    />
                    <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center text-blue-600">
                      <FileText className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-gray-900">{file.fileName}</p>
                      <p className="text-xs text-gray-500">{file.modelName} • {new Date(file.date).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-green-100 text-green-700 uppercase mr-2">
                      {file.status}
                    </span>
                    <button 
                      onClick={() => setSelectedFile(file)}
                      className="p-1.5 text-gray-400 hover:text-blue-600 transition-colors"
                      title={t('common.view')}
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => setDownloadConfirmId(file.id)}
                      className="p-1.5 text-gray-400 hover:text-green-600 transition-colors"
                      title={t('common.download') || 'Download'}
                    >
                      <Download className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => setDeleteConfirmId(file.id)}
                      className="p-1.5 text-gray-400 hover:text-red-500 transition-colors"
                      title={t('common.delete')}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-10 text-center text-gray-400">
              <p>{t('dashboard.noFiles')}</p>
            </div>
          )}
        </div>
      </section>

      {/* Detail Modal */}
      <AnimatePresence>
        {selectedFile && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white rounded-[32px] shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col relative"
            >
              {/* Header */}
              <div className="p-8 pb-4 flex items-start justify-between">
                <div>
                  <h2 className="text-2xl font-black text-gray-900 mb-1">{t('dashboard.fileDetails.title')}</h2>
                  <p className="text-gray-400 font-medium text-sm">{t('dashboard.fileDetails.subtitle')}</p>
                </div>
                <button 
                  onClick={() => setSelectedFile(null)}
                  className="w-10 h-10 rounded-full bg-gray-50 flex items-center justify-center text-gray-400 hover:bg-gray-100 hover:text-gray-900 transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="px-8 pb-8 overflow-y-auto flex-1 custom-scrollbar">
                <div className="pt-4 border-t border-gray-100 mb-8">
                   <div className="flex items-center gap-4">
                      <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600">
                         <FilesIcon className="w-8 h-8" />
                      </div>
                      <div>
                        <h3 className="text-lg font-black text-gray-900 leading-tight">{selectedFile.fileName}</h3>
                        <p className="text-sm font-bold text-gray-400">{t('dashboard.fileDetails.model')}: <span className="text-blue-600">{selectedFile.modelName}</span></p>
                      </div>
                   </div>
                </div>

                {/* Info Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
                  <div className="p-5 bg-white border border-gray-100 rounded-2xl shadow-sm hover:border-blue-100 transition-all">
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-2">{t('dashboard.fileDetails.typeFormat')}</span>
                    <span className="text-sm font-black text-gray-900 uppercase">
                      {selectedFile.fileType.split('/')[1]?.toUpperCase() || selectedFile.fileType || '---'}
                    </span>
                  </div>
                  <div className="p-5 bg-white border border-gray-100 rounded-2xl shadow-sm hover:border-blue-100 transition-all">
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-1">{t('dashboard.fileDetails.size')}</span>
                    <span className="text-sm font-black text-gray-900">{formatFileSize(selectedFile.fileSize)}</span>
                  </div>
                  <div className="p-5 bg-white border border-gray-100 rounded-2xl shadow-sm hover:border-blue-100 transition-all">
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-2">{t('dashboard.fileDetails.uploadDate')}</span>
                    <span className="text-sm font-black text-gray-900">{new Date(selectedFile.date).toLocaleString()}</span>
                  </div>
                  <div className="p-5 bg-white border border-gray-100 rounded-2xl shadow-sm hover:border-blue-100 transition-all">
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-2">{t('dashboard.fileDetails.status')}</span>
                    <div className="flex items-center gap-1.5">
                       <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                       <span className="text-sm font-black text-gray-900 uppercase">{selectedFile.status === 'completed' ? t('dashboard.fileDetails.completed') : t('dashboard.fileDetails.failed')}</span>
                    </div>
                  </div>
                </div>

                <div className="mb-8">
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-2">{t('dashboard.fileDetails.description')}</span>
                    <div className="p-5 bg-white border border-gray-100 rounded-2xl shadow-sm min-h-[60px] text-sm text-gray-500 font-medium">
                      ---
                    </div>
                </div>

                <div>
                   <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-2">{t('dashboard.fileDetails.jsonResult')}</span>
                   <div className="bg-gray-900 rounded-2xl p-6 font-mono text-[11px] text-green-400 overflow-x-auto shadow-inner leading-relaxed">
                      <pre>{JSON.stringify(selectedFile.data, null, 2)}</pre>
                   </div>
                </div>
              </div>

              {/* Footer */}
              <div className="p-8 pt-0 border-t border-gray-50 mt-auto flex justify-end">
                <button 
                  onClick={() => setSelectedFile(null)}
                  className="px-8 py-3.5 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 transition-all active:scale-[0.98] shadow-lg shadow-blue-100"
                >
                  Sair
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {deleteConfirmId && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-8 text-center"
            >
              <div className="w-20 h-20 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-6">
                <Trash2 className="w-10 h-10 text-red-500" />
              </div>
              <h3 className="text-2xl font-black text-gray-900 mb-3">{t('dashboard.deleteFile.title')}</h3>
              <p className="text-gray-500 font-medium mb-8 leading-relaxed">
                {t('dashboard.deleteFile.confirm')} <span className="text-gray-900 font-bold">"{recentFiles.find(r => r.id === deleteConfirmId)?.fileName}"</span>? {t('dashboard.deleteFile.actionCannotBeUndone')}
              </p>
              <div className="flex gap-4">
                <button 
                  onClick={() => setDeleteConfirmId(null)}
                  className="flex-1 px-6 py-4 bg-gray-100 text-gray-600 font-bold rounded-2xl hover:bg-gray-200 transition-all"
                >
                  {t('common.cancel')}
                </button>
                <button 
                  onClick={() => { 
                    if (deleteConfirmId) {
                      onDeleteSelected([deleteConfirmId], true); 
                      setDeleteConfirmId(null); 
                    }
                  }}
                  className="flex-1 px-6 py-4 bg-red-600 text-white font-bold rounded-2xl hover:bg-red-700 shadow-lg shadow-red-100 transition-all"
                >
                  {t('dashboard.deleteFile.confirmAction')}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Download Confirmation Modal */}
      <AnimatePresence>
        {downloadConfirmId && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white rounded-3xl shadow-2xl max-w-lg w-full p-8 text-center"
            >
              <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-6">
                <Download className="w-10 h-10 text-green-600" />
              </div>
              <h3 className="text-2xl font-black text-gray-900 mb-3">{t('dashboard.downloadFile.title')}</h3>
              <p className="text-gray-500 font-medium mb-8 leading-relaxed">
                {t('dashboard.downloadFile.subtitle')} <span className="text-gray-900 font-bold">"{recentFiles.find(r => r.id === downloadConfirmId)?.fileName}"</span>.
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-8">
                <button 
                  onClick={() => {
                    const file = recentFiles.find(r => r.id === downloadConfirmId);
                    if (file) handleDownload(file, 'csv');
                  }}
                  className="p-4 bg-green-50 hover:bg-green-100 text-green-700 rounded-2xl transition-all border border-green-100 group"
                >
                  <Table className="w-6 h-6 mx-auto mb-2 group-hover:scale-110 transition-transform" />
                  <span className="font-bold text-xs uppercase tracking-wider">CSV</span>
                </button>
                <button 
                   onClick={() => {
                    const file = recentFiles.find(r => r.id === downloadConfirmId);
                    if (file) handleDownload(file, 'txt');
                  }}
                  className="p-4 bg-gray-50 hover:bg-gray-100 text-gray-700 rounded-2xl transition-all border border-gray-100 group"
                >
                  <FileText className="w-6 h-6 mx-auto mb-2 group-hover:scale-110 transition-transform" />
                  <span className="font-bold text-xs uppercase tracking-wider">TXT</span>
                </button>
                <button 
                   onClick={() => {
                    const file = recentFiles.find(r => r.id === downloadConfirmId);
                    if (file) handleDownload(file, 'json');
                  }}
                  className="p-4 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-2xl transition-all border border-blue-100 group"
                >
                  <Zap className="w-6 h-6 mx-auto mb-2 group-hover:scale-110 transition-transform" />
                  <span className="font-bold text-xs uppercase tracking-wider">JSON</span>
                </button>
              </div>

              <div className="flex gap-4">
                <button 
                  onClick={() => setDownloadConfirmId(null)}
                  className="flex-1 px-6 py-4 bg-gray-100 text-gray-600 font-bold rounded-2xl hover:bg-gray-200 transition-all focus:outline-none"
                >
                  {t('common.cancel')}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <section className="bg-white rounded-2xl shadow-md border border-gray-200 overflow-hidden">
        <header className="px-5 py-4 border-b border-gray-200 bg-blue-600 flex items-center justify-between">
          <h2 className="text-lg font-bold text-white">{t('dashboard.support.title')}</h2>
        </header>
        <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-4">
          <SupportCard 
            label={t('dashboard.support.help')} 
            icon={<HelpCircle className="w-5 h-5" />} 
            onClick={() => onNavigate('help')}
          />
          <SupportCard 
            label={t('dashboard.support.tutorials')} 
            icon={<Video className="w-5 h-5" />} 
            iconColor="text-purple-600"
            onClick={() => onNavigate('tutorials')}
          />
          <SupportCard 
            label={t('dashboard.support.customerSupport')} 
            icon={<LifeBuoy className="w-5 h-5" />} 
            iconColor="text-pink-600"
            onClick={() => window.open('https://wa.me/951006421', '_blank')}
          />
        </div>
      </section>
    </div>
  );
}

function SupportCard({ label, icon, iconColor, onClick }: any) {
  return (
    <motion.button
      whileHover={{ scale: 1.02, y: -2 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className="flex items-center gap-4 p-4 rounded-2xl transition-all text-left w-full border border-blue-100 bg-blue-50 hover:bg-blue-100/50 shadow-sm group"
    >
      <div className={`w-11 h-11 rounded-xl bg-white border border-blue-50 flex items-center justify-center shrink-0 shadow-sm group-hover:scale-110 transition-transform ${iconColor || 'text-blue-600'}`}>
        {icon}
      </div>
      <span className="font-bold text-blue-900 text-base">{label}</span>
    </motion.button>
  );
}

function StatCard({ label, value, icon, color, iconColor }: any) {
  const borderColors: any = {
    blue: 'border-blue-100',
    green: 'border-green-100',
    purple: 'border-purple-100',
  };
  
  return (
    <motion.article 
      whileHover={{ y: -5, shadow: "0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1)" }}
      className={`group bg-white rounded-[2rem] border ${borderColors[color] || 'border-gray-100'} p-6 transition-all duration-300 flex items-center gap-6 shadow-sm`}
    >
      <div className={`w-16 h-16 rounded-2xl bg-blue-50 shadow-md flex items-center justify-center shrink-0 group-hover:rotate-12 group-hover:scale-110 transition-transform duration-500 ${iconColor || 'text-blue-600'}`}>
        {React.cloneElement(icon as React.ReactElement, { className: 'w-8 h-8' })}
      </div>
      <div>
        <p className="text-[10px] font-black uppercase text-gray-500 tracking-[0.2em] mb-1">{label}</p>
        <p className="text-4xl font-black text-gray-900 leading-none tracking-tight">{value}</p>
      </div>
    </motion.article>
  );
}

function ActionButton({ label, icon, color, onClick }: any) {
  const colors: any = {
    blue: 'from-blue-500 to-blue-700 hover:from-blue-600 hover:to-blue-800',
    green: 'from-green-500 to-green-700 hover:from-green-600 hover:to-green-800',
    purple: 'from-purple-500 to-purple-700 hover:from-purple-600 hover:to-purple-800'
  };
  
  return (
    <button 
      onClick={onClick}
      className={`relative overflow-hidden flex items-center justify-center gap-3 bg-gradient-to-r ${colors[color]} text-white px-6 py-4 rounded-xl shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1 w-full`}
    >
      <span className="relative z-10">{icon}</span>
      <span className="font-bold relative z-10">{label}</span>
    </button>
  );
}

function InfoBox({ label, value, color, icon }: any) {
  const bgColors: any = {
    blue: 'bg-blue-50 text-blue-600 border-blue-100',
    purple: 'bg-purple-50 text-purple-600 border-purple-100',
    indigo: 'bg-indigo-50 text-indigo-600 border-indigo-100',
    green: 'bg-green-50 text-green-600 border-green-100',
    red: 'bg-red-50 text-red-600 border-red-100'
  };
  
  return (
    <div className={`${bgColors[color]} rounded-2xl p-4 border flex items-center gap-4 transition-all hover:shadow-md group`}>
      {icon && (
        <div className="w-10 h-10 rounded-xl bg-white shadow-sm flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
          {icon}
        </div>
      )}
      <div>
        <p className="text-[10px] font-black uppercase mb-0.5 opacity-70 tracking-widest">{label}</p>
        <p className="text-lg font-black leading-tight tracking-tight">{value}</p>
      </div>
    </div>
  );
}
