/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Shield, Smartphone, Copy, Download, Upload, CheckCircle2, ChevronRight, HardDrive } from 'lucide-react';
import { generateDeviceFingerprint, generateLicenseRequest } from '../lib/license';
import { motion, AnimatePresence } from 'motion/react';

interface OfflineActivationProps {
  onActivate: (license: any) => void;
}

export default function OfflineActivation({ onActivate }: OfflineActivationProps) {
  const [deviceId, setDeviceId] = useState('');
  const [name, setName] = useState('');
  const [plan, setPlan] = useState('');
  const [step, setStep] = useState(1); // 1: Select Plan, 2: Name/Generate, 3: Instructions, 4: Import
  const [isGenerated, setIsGenerated] = useState(false);

  useEffect(() => {
    setDeviceId(generateDeviceFingerprint());
  }, []);

  const plans = [
    { 
      id: 'Basico', 
      name: 'Básico', 
      price: '45.000 Kz', 
      features: [
        '100 Extrações mensais', 
        '1 Licença (1 PC)', 
        'Até 10 Modelos personalizados',
        'Exportação: JSON / CSV / TXT',
        'Suporte (48h)',
        'Carryover de extrações'
      ],
      color: 'blue'
    },
    { 
      id: 'Pro', 
      name: 'Pro ⭐', 
      price: '120.000 Kz', 
      features: [
        '600 Extrações mensais (120/PC)', 
        'Até 5 Licenças (5 PCs)', 
        'Até 40 Modelos personalizados',
        'Login Facial (Biometria)',
        'Exportação: JSON / CSV / TXT',
        'Suporte (24h)',
        'Carryover de extrações'
      ],
      color: 'indigo'
    },
    { 
      id: 'Empresarial', 
      name: 'Enterprise', 
      price: '350.000 Kz', 
      features: [
        '3.000 Extrações mensais (300/PC)', 
        'Até 10 Licenças (10 PCs)', 
        'Até 200 Modelos personalizados',
        'Login Facial (Biometria)',
        'API + Integrações',
        'Exportação: JSON / CSV / TXT',
        'Suporte (24h)',
        'Carryover de extrações'
      ],
      color: 'slate'
    }
  ];

  const handleSelectPlan = (planId: string) => {
    setPlan(planId);
    setStep(2);
  };

  const handleGenerateRequest = () => {
    if (!name) return alert('Por favor insira o seu nome.');
    const encrypted = generateLicenseRequest(name, plan);
    const blob = new Blob([encrypted], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pedido_${Date.now()}.enc`;
    a.click();
    setIsGenerated(true);
    setStep(3);
  };

  const copyPaymentNumber = () => {
    navigator.clipboard.writeText('951006421');
    alert('Número 951006421 copiado!');
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-fade-in pb-20 px-4">
      <header className="pt-8 text-center md:text-left">
        <h1 className="text-4xl font-black text-gray-900 mb-3 tracking-tight">Ativação Offline</h1>
        <p className="text-gray-500 font-medium text-lg">Ative a sua licença em apenas 3 passos simples.</p>
      </header>

      {/* Progress */}
      <div className="flex items-center justify-center space-x-4 mb-8">
        {[1, 2, 3, 4].map(i => (
          <div key={i} className="flex items-center space-x-4">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-base transition-all duration-300 ${step >= i ? 'bg-blue-600 text-white shadow-lg shadow-blue-200' : 'bg-gray-100 text-gray-400'}`}>
              {i}
            </div>
            {i < 4 && <div className={`w-12 md:w-20 h-1 rounded-full transition-all duration-500 ${step > i ? 'bg-blue-600' : 'bg-gray-100'}`} />}
          </div>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {/* Step 1: Select Plan */}
        {step === 1 && (
          <motion.div 
            key="step1"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="space-y-8"
          >
            <div className="text-center">
              <h2 className="text-2xl font-bold text-gray-900">Escolha o seu plano</h2>
              <p className="text-gray-500 mt-2">Selecione o plano que melhor se adapta às suas necessidades.</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {plans.map((p) => (
                <motion.button
                  key={p.id}
                  whileHover={{ y: -5 }}
                  onClick={() => handleSelectPlan(p.id)}
                  className={`bg-white rounded-3xl p-8 border-2 text-left transition-all ${plan === p.id ? 'border-blue-600 ring-4 ring-blue-50' : 'border-gray-100 hover:border-blue-200'}`}
                >
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-6 ${p.id === 'Basico' ? 'bg-blue-50 text-blue-600' : p.id === 'Pro' ? 'bg-indigo-50 text-indigo-600' : 'bg-slate-50 text-slate-600'}`}>
                    <Shield className="w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-black text-gray-900 mb-1">{p.name}</h3>
                  <div className="text-2xl font-black text-blue-600 mb-6">{p.price}</div>
                  <ul className="space-y-4 mb-8">
                    {p.features.map((f, i) => (
                      <li key={i} className="flex items-start gap-3 text-sm text-gray-600 font-medium">
                        <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                        {f}
                      </li>
                    ))}
                  </ul>
                  <div className="w-full py-4 text-center rounded-2xl bg-gray-50 font-bold text-gray-600 transition-colors group-hover:bg-blue-600 group-hover:text-white">
                    Selecionar
                  </div>
                </motion.button>
              ))}
            </div>
          </motion.div>
        )}

        {/* Step 2: Name and ID */}
        {step === 2 && (
          <motion.div 
            key="step2"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="max-w-2xl mx-auto space-y-6"
          >
            <div className="bg-white rounded-3xl shadow-xl shadow-gray-100 p-8 border border-gray-100">
              <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-3">
                <span className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-sm">2</span>
                Dados da Licença
              </h3>

              {/* Device ID Display */}
              <div className="mb-8">
                <label className="block text-xs font-bold text-gray-400 uppercase mb-3 tracking-widest">ID do Dispositivo (Deste Computador)</label>
                <div className="flex items-center gap-4 bg-gray-50 p-5 rounded-2xl border border-gray-100">
                  <HardDrive className="w-6 h-6 text-gray-400 flex-shrink-0" />
                  <code className="flex-1 font-mono text-blue-700 font-bold break-all text-sm leading-relaxed">{deviceId}</code>
                  <button onClick={() => { navigator.clipboard.writeText(deviceId); alert('Copiado!'); }} className="p-3 hover:bg-white rounded-xl transition shadow-sm border border-transparent hover:border-gray-100">
                    <Copy className="w-5 h-5 text-gray-600" />
                  </button>
                </div>
                <p className="text-[10px] text-gray-400 mt-2 italic">* Este ID vincula a licença a este PC específico.</p>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-3 tracking-widest">Seu Nome / Nome da Empresa</label>
                  <input 
                    type="text" value={name} onChange={e => setName(e.target.value)}
                    placeholder="Ex: João Silva ou Empresa LDA"
                    className="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all text-gray-900 font-medium placeholder:text-gray-300" 
                  />
                </div>
                
                <div className="pt-4 flex flex-col sm:flex-row gap-4">
                  <button onClick={() => setStep(1)} className="px-8 py-4 bg-gray-100 text-gray-600 font-bold rounded-2xl hover:bg-gray-200 transition-all">
                    Voltar
                  </button>
                  <button 
                    onClick={handleGenerateRequest} 
                    disabled={!name}
                    className="flex-1 bg-blue-600 text-white font-black py-4 rounded-2xl hover:bg-blue-700 shadow-xl shadow-blue-200 transition-all flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <Download className="w-5 h-5" /> Gerar Ficheiro de Pedido (.enc)
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Step 3: Payment and Send */}
        {step === 3 && (
          <motion.div 
            key="step3"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8"
          >
            <div className="bg-white rounded-3xl shadow-xl p-8 border border-gray-100 text-center flex flex-col items-center justify-center">
              <div className="w-20 h-20 bg-green-50 text-green-600 rounded-full flex items-center justify-center mb-6">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h3 className="text-2xl font-black text-gray-900 mb-4">Pedido Gerado!</h3>
              <p className="text-gray-500 font-medium mb-8">
                O ficheiro para o plano <span className="text-blue-600 font-bold">{plan}</span> foi descarregado. Agora envie-o para o administrador.
              </p>
              <div className="w-full space-y-4">
                <a href="https://wa.me/951006421" target="_blank" className="w-full bg-[#25D366] text-white py-4 rounded-2xl font-black flex items-center justify-center gap-3 shadow-lg shadow-green-100 hover:scale-[1.02] transition-transform">
                  <Smartphone className="w-6 h-6" /> Enviar por WhatsApp
                </a>
                <button onClick={() => setStep(4)} className="w-full bg-blue-600 text-white py-4 rounded-2xl font-black flex items-center justify-center gap-3 hover:bg-blue-700 transition-colors">
                  Já recebi a Licença (.lic) <ChevronRight className="w-6 h-6" />
                </button>
              </div>
            </div>

            <div className="bg-slate-900 rounded-3xl p-8 text-white">
              <h3 className="text-xl font-bold mb-6 flex items-center gap-3">
                <span className="w-8 h-8 rounded-full bg-white/10 text-white flex items-center justify-center text-sm">3</span>
                Pagamento
              </h3>
              <div className="space-y-6">
                <div className="p-6 bg-white/5 rounded-2xl border border-white/10">
                  <p className="text-white/60 text-xs font-bold uppercase tracking-widest mb-2">Total a Pagar</p>
                  <p className="text-3xl font-black text-blue-400">{plans.find(p => p.id === plan)?.price || 'N/A'}</p>
                </div>

                <div className="p-6 bg-white/5 rounded-2xl border border-white/10">
                  <p className="text-white/60 text-xs font-bold uppercase tracking-widest mb-3">Multicaixa / Kwik / Afrimoney</p>
                  <div className="flex items-center justify-between gap-4">
                    <p className="text-2xl font-black tracking-wider text-green-400">951 006 421</p>
                    <button onClick={copyPaymentNumber} className="p-3 bg-white/10 hover:bg-white/20 rounded-xl transition">
                      <Copy className="w-5 h-5" />
                    </button>
                  </div>
                </div>

                <div className="text-sm text-white/40 italic">
                  * Após o envio do ficheiro e comprovativo, receberá a sua licença no espaço de 24 horas.
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Step 4: Import */}
        {step === 4 && (
          <motion.div 
            key="step4"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-2xl mx-auto"
          >
            <div className="bg-white rounded-[40px] border-4 border-dashed border-gray-100 p-16 text-center shadow-2xl shadow-gray-100/50">
              <div className="w-24 h-24 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-8 animate-bounce">
                <Upload className="w-10 h-10" />
              </div>
              <h3 className="text-2xl font-black text-gray-900 mb-4">Importar Licença Final</h3>
              <p className="text-gray-500 mb-10 max-w-sm mx-auto text-base font-medium leading-relaxed">
                Selecione o ficheiro <span className="text-blue-600 font-bold">.lic</span> enviado pelo administrador para ativar definitivamente o seu Facilitascan.
              </p>
              
              <label className="inline-block bg-blue-600 text-white px-12 py-5 rounded-2xl font-black shadow-xl shadow-blue-200 cursor-pointer hover:bg-blue-700 hover:scale-[1.02] transition-all">
                Selecionar Ficheiro (.lic)
                <input type="file" className="hidden" accept=".lic" onChange={e => {
                  const file = e.target.files?.[0];
                  if (file) {
                    const reader = new FileReader();
                    reader.onload = (event) => {
                      try {
                        const content = event.target?.result as string;
                        localStorage.setItem('facilitascan_license', content);
                        alert('Parabéns! Facilitascan ativado com sucesso.');
                        location.reload();
                      } catch (e) {
                        alert('Ficheiro de licença corrompido ou inválido.');
                      }
                    };
                    reader.readAsText(file);
                  }
                }} />
              </label>

              <button onClick={() => setStep(3)} className="block w-full mt-8 text-gray-400 font-bold text-sm hover:text-gray-600 transition-colors">
                Voltar para instruções
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
