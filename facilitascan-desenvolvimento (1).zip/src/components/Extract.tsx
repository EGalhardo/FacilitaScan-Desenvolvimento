/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Zap,
  Trash2,
  Clock,
  Eye,
  FileSearch, 
  Upload, 
  Play, 
  Download, 
  Copy, 
  Table as TableIcon,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Palette
} from 'lucide-react';
import { createWorker } from 'tesseract.js';
import * as pdfjs from 'pdfjs-dist';

// Configure PDF.js worker using Vite-native pattern
pdfjs.GlobalWorkerOptions.workerSrc = new URL(
  'pdfjs-dist/build/pdf.worker.min.mjs',
  import.meta.url
).toString();

import { motion } from 'motion/react';
import { useTranslation } from 'react-i18next';
import { applyGrayContrast, applyAdaptiveBinarize, scoreOcrCandidate, processImageWithSettings } from '../lib/imageUtils';
import { OCRModel, ExtractionResult } from '../types';
import ImagePreprocessModal, { PreprocessSettings } from './ImagePreprocessModal';

interface ExtractProps {
  models: OCRModel[];
  onExtractionComplete: (result: ExtractionResult) => void;
  onIncrementExtractions: (count: number) => void;
  onDeleteModel?: (id: string) => void;
  licenseStatus: {
    valid: boolean;
    plan: string;
    extractionsUsed: number;
    maxExtractions: number;
  };
}

export default function Extract({ models, onExtractionComplete, onIncrementExtractions, onDeleteModel, licenseStatus }: ExtractProps) {
  const { t } = useTranslation();
  const [selectedModelId, setSelectedModelId] = useState('');
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentResult, setCurrentResult] = useState<ExtractionResult | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [showModelPreviewId, setShowModelPreviewId] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isExtracted, setIsExtracted] = useState(false);
  const [preprocessSettings, setPreprocessSettings] = useState<PreprocessSettings>({
    denoise: false,
    contrast: false,
    binarize: false,
    sharpen: false,
    deskew: false,
    zoom: 100
  });

  useEffect(() => {
    if (selectedModelId) {
      const model = models.find(m => m.id === selectedModelId);
      if (model?.preprocessSettings) {
        setPreprocessSettings(model.preprocessSettings);
      }
    }
  }, [selectedModelId, models]);

  // Cleanup preview URLs
  useEffect(() => {
    return () => {
      if (previewUrl && previewUrl.startsWith('blob:')) {
        URL.revokeObjectURL(previewUrl);
      }
    };
  }, [previewUrl]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files) as File[];
      setSelectedFiles(prev => [...prev, ...files]);
      setIsExtracted(false);
      
      // Auto-preview first file if none selected
      if (files.length > 0 && !previewUrl) {
        showPreview(files[0]);
      }
    }
  };

  const showPreview = async (file: File) => {
    if (previewUrl && previewUrl.startsWith('blob:')) URL.revokeObjectURL(previewUrl);

    if (file.type === 'application/pdf') {
      try {
        const arrayBuffer = await file.arrayBuffer();
        
        // Ensure worker is set
        if (!pdfjs.GlobalWorkerOptions.workerSrc) {
          pdfjs.GlobalWorkerOptions.workerSrc = new URL(
            'pdfjs-dist/build/pdf.worker.min.mjs',
            import.meta.url
          ).toString();
        }

        const pdf = await pdfjs.getDocument({
          data: arrayBuffer,
          useWorkerFetch: true,
          isEvalSupported: false
        } as any).promise;
        const page = await pdf.getPage(1);
        const viewport = page.getViewport({ scale: 1.5 });
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d')!;
        canvas.height = viewport.height;
        canvas.width = viewport.width;
        await page.render({ 
          canvasContext: context, 
          viewport: viewport, 
          canvas: canvas 
        } as any).promise;
        setPreviewUrl(canvas.toDataURL());
      } catch (err) {
        console.error('PDF preview failed', err);
        setPreviewUrl(null);
      }
    } else {
      setPreviewUrl(URL.createObjectURL(file));
    }
    setCurrentResult(null); // Clear result view when switching to image preview
  };

  const removeFile = (idx: number) => {
    setSelectedFiles(prev => {
      const newFiles = prev.filter((_, i) => i !== idx);
      if (newFiles.length === 0) setPreviewUrl(null);
      return newFiles;
    });
  };

  const clearFiles = () => {
    setSelectedFiles([]);
    setPreviewUrl(null);
    setCurrentResult(null);
    setIsExtracted(false);
  };

  const isOverLimit = licenseStatus.extractionsUsed >= licenseStatus.maxExtractions;

  const processFile = async (isTest: boolean = false) => {
    if (!selectedModelId || selectedFiles.length === 0) return;
    
    if (!isTest && isOverLimit) {
      alert(`${t('extraction.limitReached') || 'Limite de extrações excedido'} para o plano ${licenseStatus.plan}. ${t('plans.upgrade') || 'Por favor, atualize sua licença'}.`);
      return;
    }
    
    const model = models.find(m => m.id === selectedModelId);
    if (!model) return;

    setIsProcessing(true);
    setProgress(0);

    try {
      const worker = await createWorker(model.language, 1);
      
      // If it's a test, only process the first file
      const filesToProcess = isTest ? [selectedFiles[0]] : selectedFiles;

      for (let i = 0; i < filesToProcess.length; i++) {
        const file = filesToProcess[i];
        
        // Incrementar contador de licença por arquivo (documento)
        if (!isTest) onIncrementExtractions(1);

        let imagesToProcess: (HTMLImageElement | HTMLCanvasElement)[] = [];

        if (file.type === 'application/pdf') {
          const arrayBuffer = await file.arrayBuffer();

          // Ensure worker is set
          if (!pdfjs.GlobalWorkerOptions.workerSrc) {
            pdfjs.GlobalWorkerOptions.workerSrc = new URL(
              'pdfjs-dist/build/pdf.worker.min.mjs',
              import.meta.url
            ).toString();
          }

          const pdf = await pdfjs.getDocument({
            data: arrayBuffer,
            useWorkerFetch: true,
            isEvalSupported: false
          } as any).promise;
          
          for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
            const page = await pdf.getPage(pageNum);
            const viewport = page.getViewport({ scale: 2.0 }); // Higher scale for better OCR
            const canvas = document.createElement('canvas');
            const context = canvas.getContext('2d')!;
            canvas.height = viewport.height;
            canvas.width = viewport.width;
            
            await page.render({ 
              canvasContext: context, 
              viewport: viewport, 
              canvas: canvas 
            } as any).promise;
            imagesToProcess.push(canvas);
          }
        } else {
          const imageUrl = URL.createObjectURL(file);
          const img = new Image();
          await new Promise((resolve) => {
            img.onload = resolve;
            img.src = imageUrl;
          });
          imagesToProcess.push(img);
          URL.revokeObjectURL(imageUrl);
        }

        for (const imgSource of imagesToProcess) {
          // Apply preprocessing
          let processedImg: HTMLImageElement | HTMLCanvasElement = imgSource;
          const hasActiveSettings = preprocessSettings.denoise || 
                                   preprocessSettings.contrast || 
                                   preprocessSettings.binarize || 
                                   preprocessSettings.sharpen || 
                                   preprocessSettings.deskew || 
                                   preprocessSettings.zoom !== 100;

          if (hasActiveSettings) {
            const mainCanvas = document.createElement('canvas');
            mainCanvas.width = imgSource instanceof HTMLCanvasElement ? imgSource.width : imgSource.naturalWidth;
            mainCanvas.height = imgSource instanceof HTMLCanvasElement ? imgSource.height : imgSource.naturalHeight;
            const mctx = mainCanvas.getContext('2d')!;
            mctx.drawImage(imgSource, 0, 0);
            processedImg = await processImageWithSettings(mainCanvas, preprocessSettings);
          }

          const extractedData: Record<string, string> = {};

          for (const field of model.fields) {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            if (!ctx) continue;

            const factorX = processedImg instanceof HTMLCanvasElement ? processedImg.width : processedImg.naturalWidth;
            const factorY = processedImg instanceof HTMLCanvasElement ? processedImg.height : processedImg.naturalHeight;

            const cropX = field.x * factorX;
            const cropY = field.y * factorY;
            const cropW = field.width * factorX;
            const cropH = field.height * factorY;

            canvas.width = cropW;
            canvas.height = cropH;
            ctx.drawImage(processedImg, cropX, cropY, cropW, cropH, 0, 0, cropW, cropH);

            const variants = [
              { id: 'original', canvas: canvas },
              { id: 'contrast', canvas: (() => { 
                  const c = document.createElement('canvas'); c.width = canvas.width; c.height = canvas.height;
                  const xc = c.getContext('2d')!; xc.drawImage(canvas, 0, 0); 
                  applyGrayContrast(xc, c.width, c.height); 
                  return c; 
                })()
              },
              { id: 'binarize', canvas: (() => {
                  const c = document.createElement('canvas'); c.width = canvas.width; c.height = canvas.height;
                  const xc = c.getContext('2d')!; xc.drawImage(canvas, 0, 0);
                  applyAdaptiveBinarize(xc, c.width, c.height);
                  return c;
                })()
              }
            ];

            let bestText = '';
            let bestScore = -1;

            for (const variant of variants) {
              const { data: { text, confidence } } = await worker.recognize(variant.canvas);
              const score = scoreOcrCandidate(text, confidence);
              if (score > bestScore) {
                bestScore = score;
                bestText = text;
              }
              if (confidence > 85) break; 
            }

            extractedData[field.name] = bestText.trim();
          }

          const result: ExtractionResult = {
            id: Math.random().toString(36).substr(2, 9),
            fileName: file.name,
            modelName: model.name,
            modelId: model.id,
            date: Date.now(),
            data: extractedData,
            status: 'completed',
            fileSize: file.size,
            fileType: file.type
          };

          setCurrentResult(result);
          if (!isTest) {
            onExtractionComplete(result);
            setIsExtracted(true);
          }
        }
        
        setProgress(Math.round(((i + 1) / filesToProcess.length) * 100));
      }

      await worker.terminate();
    } catch (error) {
      console.error('Extraction failed:', error);
      alert(t('createModel.errors.ocrFailed'));
    } finally {
      setIsProcessing(false);
    }
  };

  const handleViewModel = () => {
    if (!selectedModelId) return;
    setShowModelPreviewId(selectedModelId);
  };

  const handleDeleteClick = () => {
    if (!selectedModelId) return;
    setShowDeleteConfirm(true);
  };

  const confirmDelete = () => {
    if (selectedModelId && onDeleteModel) {
      onDeleteModel(selectedModelId);
      setSelectedModelId('');
      setShowDeleteConfirm(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <header>
        <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">{t('extraction.title')}</h1>
        <p className="text-gray-500 text-sm md:text-base">{t('extraction.subtitle')}</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Config Side */}
        <div className="lg:col-span-4 lg:sticky lg:top-6 self-start space-y-6">
          <section className="bg-white rounded-2xl shadow-md border border-gray-100 overflow-hidden">
            <div className="p-1 px-5 pt-5">
               <h2 className="text-lg font-bold text-gray-900">{t('nav.settings')}</h2>
            </div>
            
            <div className="p-5 space-y-6">
              <div>
                <div className="flex items-center justify-between mb-2">
                   <label className="text-sm font-semibold text-gray-700">{t('extraction.selectModel')}</label>
                   <div className="flex gap-2">
                      <button 
                        onClick={handleViewModel}
                        disabled={!selectedModelId}
                        className="text-[10px] font-bold text-blue-600 flex items-center gap-1 hover:underline disabled:opacity-50"
                      >
                         <Eye className="w-3 h-3" /> {t('common.view')}
                      </button>
                      <button 
                         onClick={handleDeleteClick}
                         disabled={!selectedModelId}
                         className="text-[10px] font-bold text-red-600 flex items-center gap-1 hover:underline disabled:opacity-50"
                      >
                         <Trash2 className="w-3 h-3" /> {t('common.delete')}
                      </button>
                   </div>
                </div>
                <select 
                   value={selectedModelId}
                   onChange={(e) => setSelectedModelId(e.target.value)}
                   className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 transition shadow-sm outline-none cursor-pointer"
                >
                  <option value="">{t('extraction.chooseModel') || 'Escolha um modelo...'}</option>
                  {models.map(model => (
                    <option key={model.id} value={model.id}>{model.name}</option>
                  ))}
                </select>
                <p className="mt-2 text-[10px] text-gray-400 font-medium">Selecione e clique em Eliminar para remover..</p>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">{t('extraction.uploadFiles') || 'Carregar Arquivo(s)'}</label>
                <label 
                  htmlFor="file-upload-extract"
                  className="w-full flex flex-col items-center justify-center gap-2 px-4 py-8 border-2 border-dashed border-gray-300 rounded-xl hover:border-blue-500 hover:bg-blue-50 cursor-pointer transition-all active:scale-[0.99]"
                >
                  <Upload className="w-10 h-10 text-gray-400" />
                  <span className="text-sm text-gray-600 font-bold text-center">
                    {t('extraction.dropFiles')}
                  </span>
                  <input 
                    id="file-upload-extract"
                    type="file" 
                    className="hidden" 
                    multiple 
                    accept="image/*,.pdf" 
                    onChange={handleFileChange} 
                  />
                </label>
              </div>

              {selectedFiles.length > 0 && (
                <div className="bg-gray-50/50 rounded-xl p-4 border border-gray-100 animate-fade-in">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-bold text-gray-700 uppercase tracking-wider">
                       {selectedFiles.length} {t('extraction.filesSelected') || 'arquivo(s) selecionado(s)'}
                    </span>
                  </div>
                  
                  <div className="space-y-2 max-h-48 overflow-y-auto pr-1 custom-scrollbar">
                    {selectedFiles.map((file, idx) => (
                      <div key={idx} className="flex items-center justify-between p-2 bg-white rounded-lg border border-gray-100 shadow-sm group">
                        <div 
                          onClick={() => showPreview(file)}
                          className="flex items-center gap-2 overflow-hidden flex-1 cursor-pointer"
                        >
                           <div className="w-8 h-8 rounded bg-gray-50 flex items-center justify-center text-[8px] font-black text-gray-400 shrink-0 uppercase">
                              {file.name.split('.').pop()?.substr(0, 3) || 'DOC'}
                           </div>
                           <div className="flex flex-col min-w-0">
                               <span className="text-[11px] font-bold text-gray-800 truncate leading-tight group-hover:text-blue-600 transition-colors">{file.name}</span>
                               <span className="text-[9px] text-gray-400 font-medium uppercase font-mono">{(file.size / 1024).toFixed(1)} KB</span>
                           </div>
                        </div>
                        <button 
                          onClick={(e) => { e.stopPropagation(); removeFile(idx); }}
                          className="text-gray-400 hover:text-red-500 transition-colors p-1"
                        >
                          <span className="text-[10px] font-bold">Remover</span>
                        </button>
                      </div>
                    ))}
                  </div>
                  <p className="mt-4 text-[10px] text-gray-400 font-medium leading-relaxed italic">
                    Dica: clique no nome do arquivo para ver o preview. Você pode remover arquivos antes de extrair.
                  </p>
                </div>
              )}

              <div className="space-y-3">
                <button 
                  onClick={() => processFile(true)}
                  disabled={isProcessing || !selectedModelId || selectedFiles.length === 0}
                  className="w-full flex items-center justify-center gap-2 px-4 py-4 bg-green-600 text-white font-black rounded-xl hover:bg-green-700 transition-all shadow-lg shadow-green-100 disabled:opacity-50 active:scale-[0.98]"
                >
                  <Play className="w-5 h-5 fill-current" />
                  Testar
                </button>

                <button 
                  onClick={() => processFile(false)}
                  disabled={isProcessing || !selectedModelId || selectedFiles.length === 0 || isOverLimit}
                  className="w-full flex items-center justify-center gap-2 px-4 py-4 bg-blue-600 text-white font-black rounded-xl hover:bg-blue-700 transition-all shadow-lg shadow-blue-100 disabled:opacity-50 disabled:bg-gray-400 active:scale-[0.98] relative"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      {t('extraction.processing')} {progress > 0 ? `${progress}%` : ''}
                    </>
                  ) : (
                    <>
                      <Zap className="w-5 h-5 fill-current" />
                      {isOverLimit ? t('extraction.limitReached') : t('extraction.extract')}
                    </>
                  )}
                </button>
                {isOverLimit && (
                  <p className="text-[10px] text-red-500 font-bold text-center animate-pulse">
                    Limite do plano {licenseStatus.plan} excedido ({licenseStatus.extractionsUsed}/{licenseStatus.maxExtractions})
                  </p>
                )}
              </div>
            </div>
          </section>
        </div>

        {/* Results/Preview Content */}
        <div className="lg:col-span-8">
          <div className="bg-white rounded-2xl shadow-md border border-gray-100 p-6 min-h-[600px] flex flex-col">
            {!previewUrl && !currentResult && !isProcessing && (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-10 animate-fade-in opacity-80">
                <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mb-6 border border-gray-100">
                   <Clock className="w-10 h-10 text-gray-300" />
                </div>
                <h3 className="text-xl font-black text-gray-900 mb-2">{t('extraction.waiting')}</h3>
                <p className="text-gray-500 max-w-sm font-medium leading-relaxed text-sm">
                  {t('extraction.waitingSubtitle')}
                </p>
              </div>
            )}

            {isProcessing && (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-10">
                <div className="w-24 h-24 relative mb-6">
                    <div className="absolute inset-0 border-4 border-gray-100 rounded-full"></div>
                    <div className="absolute inset-0 border-4 border-blue-600 rounded-full border-t-transparent animate-spin"></div>
                    <div className="absolute inset-0 flex items-center justify-center text-blue-600 font-black text-lg">
                        {progress}%
                    </div>
                </div>
                <h3 className="text-xl font-black text-gray-900 mb-2">Processando Documento</h3>
                <p className="text-gray-500 max-w-sm font-medium">Isso pode levar alguns segundos dependendo da complexidade...</p>
              </div>
            )}

            {(previewUrl || currentResult) && !isProcessing && (
              <div className="flex-1 flex flex-col animate-fade-in h-full">
                <div className="flex items-center justify-between mb-6 pb-4 border-b border-gray-100">
                   <h2 className="text-lg font-black text-gray-900 uppercase tracking-widest bg-gray-50 px-4 py-2 rounded-xl">
                      {currentResult ? t('extraction.result') : t('extraction.preview')}
                   </h2>
                   {currentResult && (
                      <span className="text-[10px] font-bold text-green-600 bg-green-50 px-3 py-1 rounded-full border border-green-100 flex items-center gap-1">
                         <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" /> {t('dashboard.active')}
                      </span>
                   )}
                </div>

                <div className="flex-1 overflow-auto bg-gray-50 border border-gray-100 p-4 rounded-2xl">
                  {currentResult ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {Object.entries(currentResult.data).map(([key, value]) => (
                        <motion.div 
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          key={key} 
                          className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm hover:border-blue-200 transition-all group"
                        >
                          <label className="text-[10px] font-black text-blue-600 uppercase tracking-tighter block mb-2">{key}</label>
                          <div className="text-sm font-bold text-gray-800 break-words leading-relaxed">{value || <span className="text-gray-300 italic">Vazio</span>}</div>
                        </motion.div>
                      ))}
                    </div>
                  ) : (
                    <div className="flex flex-col items-center">
                        <img 
                          src={previewUrl!} 
                          alt="Preview" 
                          className="max-w-full rounded-xl shadow-2xl border-4 border-white" 
                        />
                    </div>
                  )}
                </div>

                {currentResult && isExtracted && (
                    <div className="mt-6 flex items-center justify-end gap-3 animate-fade-in">
                        <button 
                            onClick={() => {
                                const entries = Object.entries(currentResult.data);
                                // Using semicolon (;) as separator for better compatibility with Excel in Portuguese locale
                                const headers = entries.map(([key]) => `"${key.replace(/"/g, '""')}"`).join(";");
                                const values = entries.map(([, value]) => `"${value.toString().replace(/"/g, '""')}"`).join(";");
                                
                                const csvContent = "\uFEFF" + headers + "\n" + values;
                                const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
                                const url = URL.createObjectURL(blob);
                                const a = document.createElement('a');
                                a.href = url; a.download = `extração_${currentResult.fileName}.csv`; a.click();
                            }}
                            className="px-6 py-3 bg-green-600 text-white font-black rounded-xl text-xs hover:bg-green-700 transition-all flex items-center gap-2"
                        >
                            <TableIcon className="w-4 h-4" /> Descarregar CSV
                        </button>
                        <button 
                            onClick={() => {
                                const textContent = Object.entries(currentResult.data)
                                    .map(([key, value]) => `${key}: ${value}`)
                                    .join("\n");
                                const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8;' });
                                const url = URL.createObjectURL(blob);
                                const a = document.createElement('a');
                                a.href = url; a.download = `extração_${currentResult.fileName}.txt`; a.click();
                            }}
                            className="px-6 py-3 bg-green-600 text-white font-black rounded-xl text-xs hover:bg-green-700 transition-all flex items-center gap-2"
                        >
                            <FileSearch className="w-4 h-4" /> Descarregar TXT
                        </button>
                        <button 
                            onClick={() => {
                                const dataStr = JSON.stringify(currentResult.data, null, 2);
                                const blob = new Blob([dataStr], { type: 'application/json' });
                                const url = URL.createObjectURL(blob);
                                const a = document.createElement('a');
                                a.href = url; a.download = `extração_${currentResult.fileName}.json`; a.click();
                            }}
                            className="px-6 py-3 bg-green-600 text-white font-black rounded-xl text-xs hover:bg-green-700 transition-all flex items-center gap-2"
                        >
                            <Download className="w-4 h-4" /> Descarregar JSON
                        </button>
                    </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Model Preview Modal */}
      {showModelPreviewId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-white rounded-3xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col"
          >
            <div className="p-6 border-b border-gray-100 flex items-center justify-between bg-white sticky top-0">
              <div>
                <h3 className="text-xl font-bold text-gray-900">
                  {models.find(m => m.id === showModelPreviewId)?.name}
                </h3>
                <p className="text-sm text-gray-400">Modelo de extração original</p>
              </div>
              <button 
                onClick={() => setShowModelPreviewId(null)}
                className="w-10 h-10 rounded-full bg-gray-50 flex items-center justify-center text-gray-400 hover:bg-gray-100 hover:text-gray-900 transition-colors"
              >
                &times;
              </button>
            </div>
            <div className="p-8 overflow-auto flex-1 bg-gray-50">
              <div className="flex justify-center">
                <img 
                  src={models.find(m => m.id === showModelPreviewId)?.templateImage} 
                  alt="Model Template" 
                  className="max-w-full rounded-lg shadow-xl border-4 border-white"
                />
              </div>
            </div>
            <div className="p-6 border-t border-gray-100 bg-white flex justify-end">
               <button 
                onClick={() => setShowModelPreviewId(null)}
                className="px-8 py-3 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 transition-colors"
               >
                 Fechar
               </button>
            </div>
          </motion.div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-8 text-center"
          >
            <div className="w-20 h-20 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-6">
              <Trash2 className="w-10 h-10 text-red-500" />
            </div>
            <h3 className="text-2xl font-black text-gray-900 mb-3">Confirmar Exclusão</h3>
            <p className="text-gray-500 font-medium mb-8">
              Tem certeza que deseja eliminar o modelo <span className="text-gray-900 font-bold">"{models.find(m => m.id === selectedModelId)?.name}"</span>? Esta ação não pode ser desfeita.
            </p>
            <div className="flex gap-3">
              <button 
                onClick={() => setShowDeleteConfirm(false)}
                className="flex-1 px-6 py-4 bg-gray-100 text-gray-600 font-bold rounded-2xl hover:bg-gray-200 transition-all"
              >
                Cancelar
              </button>
              <button 
                onClick={confirmDelete}
                className="flex-1 px-6 py-4 bg-red-600 text-white font-bold rounded-2xl hover:bg-red-700 shadow-lg shadow-red-100 transition-all"
              >
                Sim, Eliminar
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}

