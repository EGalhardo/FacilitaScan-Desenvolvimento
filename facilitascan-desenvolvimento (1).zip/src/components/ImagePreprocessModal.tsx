/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  X, 
  RotateCcw, 
  Zap, 
  Maximize2, 
  Layers, 
  Eye, 
  Wind,
  AlignLeft
} from 'lucide-react';

export interface PreprocessSettings {
  denoise: boolean;
  contrast: boolean;
  binarize: boolean;
  sharpen: boolean;
  deskew: boolean;
  zoom: number;
}

interface ImagePreprocessModalProps {
  settings: PreprocessSettings;
  onSave: (settings: PreprocessSettings) => void;
  onClose: () => void;
}

export default function ImagePreprocessModal({ settings, onSave, onClose }: ImagePreprocessModalProps) {
  const [localSettings, setLocalSettings] = useState<PreprocessSettings>(settings);

  const toggle = (key: keyof PreprocessSettings) => {
    setLocalSettings(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const reset = () => {
    setLocalSettings({
      denoise: false,
      contrast: false,
      binarize: false,
      sharpen: false,
      deskew: false,
      zoom: 100
    });
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden border border-gray-100">
        <header className="bg-blue-600 px-6 py-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5" />
            <h2 className="font-bold">Opções de Imagem</h2>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-white/20 rounded-full transition-colors">
            <X className="w-6 h-6" />
          </button>
        </header>

        <div className="p-6 space-y-6">
          <p className="text-sm text-gray-500 font-medium">Use estas opções para melhorar a qualidade do OCR em documentos de baixa qualidade.</p>
          
          <div className="grid grid-cols-1 gap-4">
            <ToggleOption 
                icon={<Wind className="w-5 h-5" />}
                label="Remover Ruído" 
                active={localSettings.denoise} 
                onClick={() => toggle('denoise')} 
            />
            <ToggleOption 
                icon={<Eye className="w-5 h-5" />}
                label="Melhorar Contraste" 
                active={localSettings.contrast} 
                onClick={() => toggle('contrast')} 
            />
            <ToggleOption 
                icon={<Layers className="w-5 h-5" />}
                label="Binarizar (Preto e Branco)" 
                active={localSettings.binarize} 
                onClick={() => toggle('binarize')} 
            />
            <ToggleOption 
                icon={<Zap className="w-5 h-5 text-yellow-500" />}
                label="Aumentar Nitidez" 
                active={localSettings.sharpen} 
                onClick={() => toggle('sharpen')} 
            />
            <ToggleOption 
                icon={<AlignLeft className="w-5 h-5" />}
                label="Corrigir Inclinação" 
                active={localSettings.deskew} 
                onClick={() => toggle('deskew')} 
            />
          </div>

          <div className="space-y-3 pt-2">
            <div className="flex justify-between items-center text-xs font-bold text-gray-400 uppercase tracking-widest leading-none">
                <span>Ampliação (Zoom)</span>
                <span className="text-blue-600 bg-blue-50 px-2 py-1 rounded-md">{localSettings.zoom}%</span>
            </div>
            <input 
                type="range" min="50" max="250" step="10"
                value={localSettings.zoom}
                onChange={e => setLocalSettings(prev => ({ ...prev, zoom: parseInt(e.target.value) }))}
                className="w-full h-2 bg-gray-100 rounded-lg appearance-none cursor-pointer accent-blue-600"
            />
          </div>

          <div className="flex gap-4 pt-4 border-t border-gray-100">
            <button 
                onClick={reset}
                className="flex-1 flex items-center justify-center gap-2 py-3 px-4 bg-gray-50 text-gray-600 font-bold rounded-xl hover:bg-gray-100 transition-colors"
            >
                <RotateCcw className="w-4 h-4" /> Restaurar
            </button>
            <button 
                onClick={() => onSave(localSettings)}
                className="flex-1 py-3 px-4 bg-blue-600 text-white font-black rounded-xl shadow-lg shadow-blue-200 hover:bg-blue-700 active:scale-95 transition-all"
            >
                Aplicar Opções
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function ToggleOption({ icon, label, active, onClick }: any) {
    return (
        <button 
            onClick={onClick}
            className={`flex items-center justify-between p-4 rounded-2xl border-2 transition-all ${
                active 
                ? 'border-blue-600 bg-blue-50 text-blue-900 group shadow-md' 
                : 'border-gray-100 bg-white text-gray-700 hover:border-gray-200'
            }`}
        >
            <div className="flex items-center gap-3">
                <div className={`p-2 rounded-xl ${active ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-400 group-hover:bg-gray-200'}`}>
                    {icon}
                </div>
                <span className="font-bold text-sm">{label}</span>
            </div>
            <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${active ? 'border-blue-600 bg-blue-600 text-white' : 'border-gray-200'}`}>
                {active && <div className="w-2.5 h-2.5 bg-white rounded-full" />}
            </div>
        </button>
    );
}
