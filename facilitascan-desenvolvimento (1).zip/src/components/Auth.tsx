/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Lock, Fingerprint, Camera, ShieldCheck, UserCheck } from 'lucide-react';
import { motion } from 'motion/react';
import FaceAuthModal from './FaceAuthModal';
import { getBiometricData, calculateL2Distance } from '../lib/license';

interface AuthProps {
  mode: 'create' | 'login';
  onAuth: (code?: string) => void;
  userId?: string;
}

export default function Auth({ mode, onAuth, userId }: AuthProps) {
  const [code, setCode] = useState('');
  const [confirmCode, setConfirmCode] = useState('');
  const [error, setError] = useState('');
  const [showFaceModal, setShowFaceModal] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (mode === 'create') {
      if (code !== confirmCode) {
        setError('Os códigos não coincidem.');
        return;
      }
      if (code.length < 4) {
        setError('O código deve ter pelo menos 4 dígitos.');
        return;
      }
    }
    onAuth(code);
  };

  const handleFaceSuccess = () => {
    setShowFaceModal(false);
    onAuth(); // Desbloquear
  };

  return (
    <div className="fixed inset-0 z-[100] bg-white flex items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-[360px] bg-white rounded-3xl border border-gray-200 shadow-2xl overflow-hidden"
      >
        <div className="bg-blue-600 px-6 pt-10 pb-12 text-center relative">
          <div className="absolute -bottom-8 left-1/2 -track-x-1/2 translate-x-[-50%]">
            <div className="w-16 h-16 rounded-2xl bg-white shadow-xl flex items-center justify-center">
              <Lock className="w-8 h-8 text-blue-600" />
            </div>
          </div>
          <h1 className="text-xl font-bold text-white mb-1">OCR – Extração Inteligente</h1>
          <p className="text-blue-100 text-xs font-medium">
            {mode === 'create' ? 'Configurar acesso seguro' : 'Digite seu código de acesso'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="px-6 pt-16 pb-8 space-y-5">
          <div className="space-y-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-gray-700">
                  {mode === 'create' ? 'Crie seu Código' : 'Código de Acesso'}
                </label>
                {mode === 'login' && (
                  <button 
                    type="button" 
                    onClick={() => setShowFaceModal(true)}
                    className="text-xs font-bold text-blue-600 hover:underline"
                  >
                    Login Facial
                  </button>
                )}
              </div>
              <input 
                type="password" 
                inputMode="numeric"
                maxLength={6}
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
                placeholder={mode === 'create' ? '4-6 dígitos' : '● ● ● ●'}
                className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-center text-lg tracking-widest focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                autoFocus
              />
            </div>

            {mode === 'create' && (
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-700">Confirme o Código</label>
                <input 
                  type="password" 
                  inputMode="numeric"
                  maxLength={6}
                  value={confirmCode}
                  onChange={(e) => setConfirmCode(e.target.value.replace(/\D/g, ''))}
                  placeholder="Repita o código"
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-center text-lg tracking-widest focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                />
              </div>
            )}
          </div>

          {error && <p className="text-[11px] text-red-600 font-bold text-center">{error}</p>}

          <button 
            type="submit"
            disabled={mode === 'create' ? code.length < 4 || confirmCode.length < 4 : code.length < 4}
            className="w-full bg-blue-600 text-white font-bold py-4 rounded-xl hover:bg-blue-700 transition-all shadow-lg active:scale-95 disabled:opacity-50"
          >
            {mode === 'create' ? 'Definir Código' : 'Desbloquear'}
          </button>

          <p className="text-center text-[10px] text-gray-400 font-medium px-4">
            Este código e a sua biometria facial são armazenados e processados de forma 100% offline no seu dispositivo para sua total privacidade.
          </p>
        </form>
      </motion.div>

      {showFaceModal && (
        <FaceAuthModal 
          mode="login"
          userId={userId || 'default-local-user'}
          onSuccess={handleFaceSuccess}
          onClose={() => setShowFaceModal(false)}
        />
      )}
    </div>
  );
}
