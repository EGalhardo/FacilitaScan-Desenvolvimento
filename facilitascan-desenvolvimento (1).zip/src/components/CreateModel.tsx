/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { 
  Plus, 
  Trash2, 
  Save, 
  Upload, 
  MousePointer2, 
  Maximize2,
  FileText,
  AlertCircle,
  HelpCircle,
  Play,
  Palette,
  Eye,
  EyeOff,
  ZoomIn,
  ZoomOut,
  RefreshCcw,
  Move,
  CheckCircle,
  Check,
  X
} from 'lucide-react';
import { createWorker } from 'tesseract.js';
import { motion } from 'motion/react';
import { useTranslation } from 'react-i18next';
import { OCRField, OCRModel } from '../types';
import { processImageWithSettings, makeCanvasCopy, convertPdfToImage } from '../lib/imageUtils';
import ImagePreprocessModal, { PreprocessSettings } from './ImagePreprocessModal';

interface CreateModelProps {
  onSave: (model: OCRModel) => void;
}

export default function CreateModel({ onSave }: CreateModelProps) {
  const { t } = useTranslation();
  const [modelName, setModelName] = useState('');
  const [language, setLanguage] = useState('por');
  const [templateImage, setTemplateImage] = useState<string | null>(null);
  const [processedImage, setProcessedImage] = useState<string | null>(null);
  const [fields, setFields] = useState<OCRField[]>([]);
  const [currentFieldName, setCurrentFieldName] = useState('');
  const [isSelecting, setIsSelecting] = useState(false);
  const [activeTool, setActiveTool] = useState<'select' | 'pan'>('select');
  const [zoom, setZoom] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [lastPanPos, setLastPanPos] = useState({ x: 0, y: 0 });
  
  const [showPreview, setShowPreview] = useState(false);
  const [showPreprocessModal, setShowPreprocessModal] = useState(false);
  const [testResults, setTestResults] = useState<Record<string, string>>({});
  const [isTesting, setIsTesting] = useState(false);
  const [preprocessSettings, setPreprocessSettings] = useState<PreprocessSettings>({
    denoise: false,
    contrast: false,
    binarize: false,
    sharpen: false,
    deskew: false,
    zoom: 100
  });
  const [startPos, setStartPos] = useState({ x: 0, y: 0 });
  const [currentRect, setCurrentRect] = useState<{ x: number, y: number, w: number, h: number } | null>(null);
  
  const containerRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);

  useEffect(() => {
    if (templateImage) {
        updateProcessedImage();
    }
  }, [preprocessSettings, templateImage]);

  const updateProcessedImage = async () => {
      if (!templateImage) return;
      const img = new Image();
      img.src = templateImage;
      await img.decode();

      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      const ctx = canvas.getContext('2d')!;
      ctx.drawImage(img, 0, 0);

      const processedCanvas = await processImageWithSettings(canvas, preprocessSettings);
      setProcessedImage(processedCanvas.toDataURL());
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        if (file.type === 'application/pdf') {
          const imageData = await convertPdfToImage(file);
          setTemplateImage(imageData);
        } else {
          const reader = new FileReader();
          reader.onload = (event) => {
            setTemplateImage(event.target?.result as string);
          };
          reader.readAsDataURL(file);
        }
        setFields([]); // Reset fields for new image
        setZoom(1);
        setOffset({ x: 0, y: 0 });
      } catch (err) {
        console.error('File upload failed:', err);
        alert(t('common.error') || 'Error uploading file');
      }
    }
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (!templateImage) return;

    if (activeTool === 'pan') {
      setIsPanning(true);
      setLastPanPos({ x: e.clientX, y: e.clientY });
      return;
    }

    // Allow selection but warn if no name is set
    if (!currentFieldName) {
      // Optional: auto-focus the field name input if empty
      const input = document.querySelector('input[placeholder="Ex: Valor Total"]') as HTMLInputElement;
      input?.focus();
    }
    
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;
    
    // Adjust coordinates for zoom and pan offset
    const x = (e.clientX - rect.left - offset.x) / zoom;
    const y = (e.clientY - rect.top - offset.y) / zoom;
    
    setIsSelecting(true);
    setStartPos({ x, y });
    setCurrentRect({ x, y, w: 0, h: 0 });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isPanning) {
      const dx = e.clientX - lastPanPos.x;
      const dy = e.clientY - lastPanPos.y;
      setOffset(prev => ({ x: prev.x + dx, y: prev.y + dy }));
      setLastPanPos({ x: e.clientX, y: e.clientY });
      return;
    }

    if (!isSelecting || !currentRect) return;
    
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;
    
    const x = (e.clientX - rect.left - offset.x) / zoom;
    const y = (e.clientY - rect.top - offset.y) / zoom;
    
    setCurrentRect({
      x: Math.min(x, startPos.x),
      y: Math.min(y, startPos.y),
      w: Math.abs(x - startPos.x),
      h: Math.abs(y - startPos.y)
    });
  };

  const handleMouseUp = () => {
    setIsSelecting(false);
    setIsPanning(false);
  };

  const handleZoom = (delta: number) => {
    setZoom(prev => Math.min(Math.max(prev + delta, 0.2), 3));
  };

  const resetView = () => {
    setZoom(1);
    setOffset({ x: 0, y: 0 });
  };

  const addField = () => {
    if (!currentRect || !currentFieldName || !imageRef.current) return;
    
    // Normalize coordinates relative to actual image dimensions
    const imgWidth = imageRef.current.clientWidth;
    const imgHeight = imageRef.current.clientHeight;

    const newField: OCRField = {
      id: Math.random().toString(36).substr(2, 9),
      name: currentFieldName.trim(),
      x: currentRect.x / imgWidth,
      y: currentRect.y / imgHeight,
      width: currentRect.w / imgWidth,
      height: currentRect.h / imgHeight
    };
    
    if (fields.some(f => f.name.toLowerCase() === newField.name.toLowerCase())) {
        alert(t('createModel.errors.fieldExists'));
        return;
    }

    setFields([...fields, newField]);
    setCurrentFieldName('');
    setCurrentRect(null);
    
    // Always trigger a test when adding a field if we have results already
    if (Object.keys(testResults).length > 0) {
        performTestExtraction();
    }
  };

  const deleteField = (id: string) => {
    setFields(fields.filter(f => f.id !== id));
  };

  const performTestExtraction = async () => {
    if (!processedImage || fields.length === 0) return;
    
    setIsTesting(true);
    setTestResults({});
    
    try {
      const worker = await createWorker(language);
      const img = new Image();
      img.src = processedImage;
      await img.decode();

      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      const ctx = canvas.getContext('2d')!;
      ctx.drawImage(img, 0, 0);

      const results: Record<string, string> = {};
      
      for (const field of fields) {
        const fx = field.x * canvas.width;
        const fy = field.y * canvas.height;
        const fw = field.width * canvas.width;
        const fh = field.height * canvas.height;

        const { data: { text } } = await worker.recognize(canvas, {
          rectangle: { top: fy, left: fx, width: fw, height: fh }
        });
        results[field.id] = text.trim();
      }

      setTestResults(results);
      await worker.terminate();
    } catch (err) {
      console.error('Test OCR failed:', err);
      alert(t('createModel.errors.ocrFailed'));
    } finally {
      setIsTesting(false);
    }
  };

  const handleSave = () => {
    if (!modelName || !templateImage || fields.length === 0) {
      alert(t('createModel.errors.missingFields'));
      return;
    }
    
    const newModel: OCRModel = {
      id: Math.random().toString(36).substr(2, 9),
      name: modelName,
      language,
      fields,
      templateImage,
      preprocessSettings, // Save settings with model
      createdAt: Date.now()
    };
    
    onSave(newModel);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">{t('createModel.title')}</h1>
          <p className="text-gray-500 text-sm md:text-base">{t('createModel.subtitle')}</p>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Sidebar Settings */}
        <div className="lg:col-span-1 space-y-6">
          <section className="bg-white rounded-2xl shadow-md p-6 border border-gray-200 sticky top-24">
            <h2 className="text-lg font-bold text-gray-900 mb-4">{t('createModel.settings')}</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">{t('createModel.modelName')}</label>
                <input 
                  type="text" 
                  value={modelName}
                  onChange={(e) => setModelName(e.target.value)}
                  placeholder={t('createModel.modelNamePlaceholder')} 
                  className="w-full px-4 py-3 text-sm border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
              </div>

              <div className="bg-blue-50 p-4 rounded-xl border border-blue-200">
                <label className="block text-sm font-semibold text-blue-900 mb-2">
                  {t('createModel.fieldName')}
                </label>
                <input 
                  type="text" 
                  value={currentFieldName}
                  onChange={(e) => setCurrentFieldName(e.target.value)}
                  placeholder={t('createModel.fieldNamePlaceholder')} 
                  className="w-full px-4 py-3 text-sm border border-blue-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 mb-3 bg-white outline-none"
                />
                <button 
                  onClick={addField}
                  disabled={!currentRect || !currentFieldName}
                  className="w-full bg-blue-600 text-white px-4 py-3 rounded-xl hover:bg-blue-700 transition font-bold text-sm shadow-md flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  <Plus className="w-5 h-5" />
                  {t('createModel.confirmArea')}
                </button>
                <p className="text-[10px] text-blue-700 mt-2 font-medium">
                  {t('createModel.instructions')}
                </p>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">{t('createModel.language')}</label>
                <select 
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                  className="w-full px-4 py-3 text-sm border border-gray-300 rounded-xl bg-white outline-none"
                >
                  <option value="por">{t('createModel.languages.pt')}</option>
                  <option value="eng">{t('createModel.languages.en')}</option>
                  <option value="spa">{t('createModel.languages.es')}</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">{t('createModel.templateImage')}</label>
                <label className="w-full flex flex-col items-center justify-center gap-2 px-4 py-6 border-2 border-dashed border-gray-300 rounded-xl hover:border-blue-500 hover:bg-blue-50 cursor-pointer transition">
                  <Upload className="w-8 h-8 text-gray-400" />
                  <span className="text-sm text-gray-600 font-medium">{t('createModel.selectFile')}</span>
                  <input type="file" className="hidden" accept="image/*,.pdf" onChange={handleImageUpload} />
                </label>
              </div>

              {fields.length > 0 && (
                <div className="space-y-4">
                  <label className="block text-sm font-semibold text-gray-700">{t('createModel.definedFields')} ({fields.length})</label>
                  <div className="max-h-40 overflow-y-auto space-y-2 pr-1">
                    {fields.map(field => (
                      <div key={field.id} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg group border border-gray-100">
                        <span className="text-xs font-bold text-gray-700 flex items-center gap-2">
                           <div className="w-2 h-2 rounded-full bg-blue-500" />
                           {field.name}
                        </span>
                        <button onClick={() => deleteField(field.id)} className="text-gray-400 hover:text-red-500 transition-colors p-1">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="pt-2 space-y-3">
                <button 
                  onClick={performTestExtraction}
                  disabled={isTesting || fields.length === 0 || !templateImage}
                  className="w-full flex items-center justify-center gap-2 px-4 py-4 bg-green-600 text-white font-black rounded-xl hover:bg-green-700 transition-all shadow-lg shadow-green-100 disabled:opacity-50 active:scale-[0.98]"
                >
                  {isTesting ? (
                    <>
                      <RefreshCcw className="w-5 h-5 animate-spin" />
                      {t('createModel.testing')}
                    </>
                  ) : (
                    <>
                      <Play className="w-5 h-5 fill-current" />
                      {t('createModel.test')}
                    </>
                  )}
                </button>

                <button 
                  onClick={handleSave}
                  className="w-full bg-blue-600 text-white px-5 py-4 rounded-xl font-black shadow-lg hover:bg-blue-700 transition-all active:scale-[0.98] border-b-4 border-blue-800"
                >
                  {t('createModel.save')}
                </button>
              </div>
            </div>
          </section>
        </div>

        {/* Workspace */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-2xl shadow-md border border-gray-200 p-4 min-h-[600px] flex flex-col">
            <div className="flex items-center justify-between mb-4 px-2">
              <h2 className="text-lg font-bold text-gray-900">
                {t('createModel.workspace')} 
                {showPreview && <span className="ml-2 text-xs text-blue-600 font-bold bg-blue-50 px-2 py-0.5 rounded-full uppercase tracking-widest">{t('createModel.previewActive')}</span>}
              </h2>
              <div className="flex items-center space-x-2">
                <div className="hidden sm:flex items-center text-[10px] text-gray-400 font-bold uppercase tracking-widest bg-gray-50 px-3 py-1.5 rounded-full border border-gray-100">
                  <MousePointer2 className="w-3 h-3 mr-2 text-blue-500" />
                  <span>{activeTool === 'select' ? 'Arraste para selecionar' : 'Arraste para mover'}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-center mb-4">
               <div className="flex bg-gray-50 p-1.5 rounded-2xl border border-gray-200 gap-1 shadow-sm">
                  <button 
                    onClick={() => setActiveTool('select')}
                    className={`p-2 rounded-xl transition-all ${activeTool === 'select' ? 'bg-blue-600 text-white shadow-md shadow-blue-200 scale-110' : 'text-gray-500 hover:bg-gray-100'}`}
                    title={t('createModel.selection')}
                  >
                    <MousePointer2 className="w-5 h-5" />
                  </button>
                  <button 
                    onClick={() => setActiveTool('pan')}
                    className={`p-2 rounded-xl transition-all ${activeTool === 'pan' ? 'bg-blue-600 text-white shadow-md shadow-blue-200 scale-110' : 'text-gray-500 hover:bg-gray-100'}`}
                    title={t('createModel.move')}
                  >
                    <Move className="w-5 h-5" />
                  </button>
                  <div className="w-px h-6 bg-gray-200 mx-1 self-center" />
                  <button 
                    onClick={() => handleZoom(-0.1)}
                    className="p-2 rounded-xl text-gray-500 hover:bg-gray-100 transition-all"
                    title="Zoom Out"
                  >
                    <ZoomOut className="w-5 h-5" />
                  </button>
                  <button 
                    onClick={resetView}
                    className="p-2 rounded-xl text-gray-500 hover:bg-gray-100 transition-all flex items-center justify-center"
                    title={t('createModel.resetView')}
                  >
                    <RefreshCcw className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => handleZoom(0.1)}
                    className="p-2 rounded-xl text-gray-500 hover:bg-gray-100 transition-all"
                    title="Zoom In"
                  >
                    <ZoomIn className="w-5 h-5" />
                  </button>
               </div>
            </div>

            <div 
              ref={containerRef}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp}
              onContextMenu={(e) => e.preventDefault()}
              className={`flex-1 border-2 border-dashed border-gray-200 rounded-2xl relative overflow-hidden bg-gray-50 transition-colors ${!templateImage ? 'flex items-center justify-center' : ''}`}
            >
              {templateImage ? (
                <div 
                  className={`relative inline-block select-none ${isPanning || isSelecting ? '' : 'transition-transform duration-75'}`}
                  style={{
                    transform: `translate(${offset.x}px, ${offset.y}px) scale(${zoom})`,
                    transformOrigin: '0 0',
                    cursor: activeTool === 'select' ? 'crosshair' : (isPanning ? 'grabbing' : 'grab')
                  }}
                >
                  <img 
                    ref={imageRef}
                    src={showPreview ? (processedImage || templateImage) : templateImage} 
                    alt="Template" 
                    draggable="false"
                    className="max-w-none block shadow-2xl rounded-sm"
                  />
                  
                  {/* Existing Fields */}
                  {fields.map(field => (
                    <div 
                      key={field.id}
                      style={{
                        left: `${field.x * 100}%`,
                        top: `${field.y * 100}%`,
                        width: `${field.width * 100}%`,
                        height: `${field.height * 100}%`
                      }}
                      className="absolute border-2 border-blue-500 bg-blue-500/10 group pointer-events-none"
                    >
                      <div className="absolute top-0 left-0 -translate-y-full bg-blue-600 text-white text-[9px] px-2 py-1 rounded-t-md font-black whitespace-nowrap shadow-sm flex items-center gap-2 pointer-events-auto">
                        <span className="max-w-[80px] truncate">{field.name}</span>
                        <button 
                          onMouseDown={(e) => e.stopPropagation()}
                          onClick={(e) => { e.stopPropagation(); deleteField(field.id); }}
                          className="hover:text-red-300 transition-colors p-0.5"
                          title="Eliminar campo"
                        >
                          <X className="w-2.5 h-2.5" />
                        </button>
                      </div>
                    </div>
                  ))}

                  {/* Selecting Rect */}
                  {currentRect && (
                    <div 
                      style={{
                        left: currentRect.x,
                        top: currentRect.y,
                        width: currentRect.w,
                        height: currentRect.h
                      }}
                      className="absolute border-2 border-dashed border-blue-600 bg-blue-600/20 shadow-[0_0_15px_rgba(37,99,235,0.2)]"
                    />
                  )}
                </div>
              ) : (
                <div className="text-center p-8">
                  <Upload className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500 text-lg font-semibold">{t('createModel.uploadPrompt')}</p>
                  <p className="text-gray-400 text-sm mt-2">{t('createModel.dragPrompt')}</p>
                </div>
              )}
            </div>
            
            {/* Real-time Results Area */}
            {Object.keys(testResults).length > 0 && (
                <div className="mt-4 p-5 bg-gray-50 border border-gray-200 rounded-2xl animate-fade-in">
                    <div className="flex items-center justify-between mb-4">
                        <h3 className="text-sm font-black text-gray-900 uppercase tracking-wider flex items-center gap-2">
                           <CheckCircle className="w-4 h-4 text-green-500" />
                           {t('createModel.results')}
                        </h3>
                        <span className="text-[10px] font-bold text-gray-400 bg-white border border-gray-100 px-2 py-1 rounded-lg">
                            {Object.keys(testResults).length} {t('createModel.fieldsExtracted')}
                        </span>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {fields.map(field => (
                            <div key={field.id} className="bg-white p-3 rounded-xl border border-gray-100 shadow-sm flex flex-col gap-1">
                                <span className="text-[10px] font-black text-blue-600 uppercase tracking-tighter">{field.name}</span>
                                <div className="text-sm font-medium text-gray-800 break-words line-clamp-2">
                                    {testResults[field.id] || <span className="text-gray-300 italic">{t('createModel.pending')}</span>}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
          </div>
        </div>
      </div>

      {showPreprocessModal && (
        <ImagePreprocessModal 
          settings={preprocessSettings}
          onSave={(s) => { setPreprocessSettings(s); setShowPreprocessModal(false); }}
          onClose={() => setShowPreprocessModal(false)}
        />
      )}
    </div>
  );
}
