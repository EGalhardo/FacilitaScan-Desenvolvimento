/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import * as faceapi from 'face-api.js';
import { 
  X, 
  Camera, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCcw,
  ShieldCheck,
  UserCheck
} from 'lucide-react';
import { getBiometricData } from '../lib/license';

interface FaceAuthModalProps {
  mode: 'enroll' | 'login';
  userId: string;
  onSuccess: (descriptor?: number[][]) => void;
  onClose: () => void;
}

export default function FaceAuthModal({ mode, userId, onSuccess, onClose }: FaceAuthModalProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isReady, setIsReady] = useState(false);
  const [feedback, setFeedback] = useState('A carregar modelos...');
  const [samples, setSamples] = useState<number[][]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let stream: MediaStream | null = null;
    const init = async () => {
      try {
        const MODEL_URL = 'https://cdn.jsdelivr.net/gh/justadudewhohacks/face-api.js@master/weights';
        
        setFeedback('A verificar dispositivos...');
        
        // Configurar stream da câmera primeiro para feedback visual imediato
        try {
          stream = await navigator.mediaDevices.getUserMedia({ 
              video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } } 
          });
          
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
          }
        } catch (camErr) {
          console.error('Erro de câmera:', camErr);
          setError('Acesso à câmera negado ou não encontrado.');
          return;
        }

        setFeedback('A carregar IA de reconhecimento...');
        
        // Carregar modelos sequencialmente para evitar gargalo de rede e memória
        try {
          if (!faceapi.nets.tinyFaceDetector.params) {
            await faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL);
          }
          if (!faceapi.nets.faceLandmark68Net.params) {
            await faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL);
          }
          if (!faceapi.nets.faceRecognitionNet.params) {
            await faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL);
          }
          
          setIsReady(true);
          setFeedback('Posicione o rosto');
        } catch (modelErr) {
          console.error('Erro ao carregar modelos:', modelErr);
          setFeedback('Erro ao carregar modelos de IA. Verifique a sua ligação.');
          // Permitir tentar usar se já estiver em cache parcial
          setIsReady(true); 
        }
      } catch (err) {
        console.error('Init error:', err);
        setError('Erro ao inicializar biometria.');
      }
    };
    init();
    return () => {
        if (stream) {
            stream.getTracks().forEach(t => t.stop());
        }
    };
  }, []);

  useEffect(() => {
    if (!isReady || mode !== 'enroll') return;
    
    const detectInterval = setInterval(async () => {
        if (videoRef.current) {
            const detection = await faceapi.detectSingleFace(
                videoRef.current, 
                new faceapi.TinyFaceDetectorOptions({ inputSize: 320, scoreThreshold: 0.5 })
            );
            if (detection) {
                setFeedback('Rosto detectado. Capture uma amostra.');
            } else if (samples.length === 0) {
                setFeedback('Posicione o rosto dentro da moldura.');
            }
        }
    }, 1000);

    return () => clearInterval(detectInterval);
  }, [isReady, mode, samples.length]);

  const captureSample = async () => {
    if (!videoRef.current || !isReady) return;
    
    // Verificar se os modelos estão realmente carregados
    if (!faceapi.nets.tinyFaceDetector.params || !faceapi.nets.faceRecognitionNet.params) {
        setFeedback('Erro: Modelos de IA não carregados.');
        return;
    }

    try {
        setFeedback('A processar...');
        const detection = await faceapi.detectSingleFace(
            videoRef.current, 
            new faceapi.TinyFaceDetectorOptions({ inputSize: 320, scoreThreshold: 0.5 })
        ).withFaceLandmarks().withFaceDescriptor();

        if (detection) {
            const descriptor = Array.from(detection.descriptor);
            if (mode === 'enroll') {
                if (samples.length < 5) {
                    setSamples(prev => [...prev, descriptor]);
                    setFeedback(`Amostra ${samples.length + 1}/5 guardada com sucesso!`);
                }
            } else {
                setFeedback('Autenticando...');
                const result = await getBiometricData(userId);
                const storedData = result?.embeddings;
                
                if (!storedData || storedData.length === 0) {
                    setFeedback('Erro: Nenhuma biometria cadastrada.');
                    return;
                }

                // Comparação de distância Euclidiana
                let matched = false;
                const currentDescriptor = new Float32Array(descriptor);
                let bestMatch = 1.0;

                for (const storedArray of storedData) {
                    const storedDescriptor = new Float32Array(storedArray);
                    const distance = faceapi.euclideanDistance(currentDescriptor, storedDescriptor);
                    if (distance < bestMatch) bestMatch = distance;
                    
                    // Limiar padrão (threshold) para reconhecimento facial
                    if (distance < 0.6) { 
                        matched = true;
                        break;
                    }
                }

                console.log(`Face match result: ${matched} (min distance: ${bestMatch.toFixed(3)})`);

                if (matched) {
                    setFeedback('Sucesso! Bem-vindo.');
                    setTimeout(() => onSuccess([descriptor]), 1000);
                } else {
                    setFeedback(`Falha: Rosto não reconhecido (dist: ${bestMatch.toFixed(2)}).`);
                }
            }
        } else {
            setFeedback('Erro: Rosto não detectado.');
        }
    } catch (err) {
        console.error('Face detection error:', err);
        setFeedback('Erro ao processar imagem.');
    }
  };

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/70 backdrop-blur-[2px] animate-fade-in">
      <div className="bg-white rounded-[32px] shadow-2xl w-full max-w-md flex flex-col overflow-hidden relative">
        <header className="p-8 pb-6 flex items-start justify-between">
            <div>
                <h2 className="text-2xl font-black text-gray-900 leading-tight">
                    {mode === 'enroll' ? 'Registo Facial' : 'Login Facial'}
                </h2>
                <p className="text-gray-400 font-medium text-sm mt-1">
                    {mode === 'enroll' 
                        ? 'Capture até 5 amostras para melhorar o reconhecimento.' 
                        : 'Posicione o seu rosto para validar o acesso.'}
                </p>
            </div>
            <button onClick={onClose} className="w-10 h-10 rounded-full bg-gray-50 flex items-center justify-center text-gray-400 hover:bg-gray-100 hover:text-gray-900 transition-colors">
                <X className="w-6 h-6" />
            </button>
        </header>

        <div className="px-8 pb-8 space-y-6">
            <div className="relative aspect-[4/3] bg-gray-100 rounded-[24px] overflow-hidden shadow-inner flex items-center justify-center">
                <div className="absolute top-3 left-3 z-10 flex items-center gap-1.5 px-3 py-1 bg-green-500/90 backdrop-blur-sm text-white rounded-full shadow-sm">
                    <ShieldCheck className="w-3 h-3" />
                    <span className="text-[10px] font-black uppercase tracking-widest">Processamento Local Offline</span>
                </div>
                {error ? (
                    <div className="p-4 text-center space-y-2">
                        <AlertCircle className="w-10 h-10 text-red-500 mx-auto" />
                        <p className="text-gray-500 text-sm font-bold">{error}</p>
                    </div>
                ) : (
                    <>
                        <video 
                            ref={videoRef} 
                            autoPlay muted playsInline 
                            className="w-full h-full object-cover scale-x-[-1]"
                        />
                        <div className="absolute inset-0 flex items-center justify-center">
                            <div className="w-[60%] h-[75%] border-2 border-white rounded-[100%] shadow-[0_0_0_9999px_rgba(0,0,0,0.2)]" />
                        </div>
                    </>
                )}
            </div>

            <div className="space-y-4">
                <div className={`text-center font-bold text-sm h-5 transition-colors ${
                    feedback.includes('Erro') || feedback.includes('não') || feedback.includes('Falha')
                    ? 'text-red-500'
                    : feedback.includes('Rosto detectado') || feedback.includes('sucesso') || feedback.includes('Bem-vindo')
                    ? 'text-green-600'
                    : 'text-blue-500'
                }`}>
                    {feedback === 'Posicione o rosto' && samples.length === 0 && isReady ? 'Aguardando detecção...' : feedback}
                </div>

                {mode === 'enroll' && (
                  <div className="text-center">
                    <p className="text-sm font-bold text-gray-400">
                      Amostras capturadas: <span className="text-gray-900">{samples.length}/5</span>
                    </p>
                  </div>
                )}

                <div className="grid grid-cols-1 gap-3 pb-1">
                    {mode === 'enroll' ? (
                      <div className="grid grid-cols-2 gap-3 w-full">
                        <button 
                            onClick={captureSample}
                            disabled={!isReady || samples.length >= 5}
                            className="flex items-center justify-center gap-2 py-4 px-4 bg-[#22c55e] text-white font-black text-xs rounded-xl transition-all shadow-lg shadow-green-100 hover:bg-green-600 active:scale-95 disabled:opacity-50"
                        >
                            Capturar Amostra
                        </button>
                        <button 
                            onClick={() => samples.length > 0 && onSuccess(samples)}
                            disabled={samples.length === 0}
                            className="flex items-center justify-center gap-2 py-4 px-4 bg-[#3b82f6] text-white font-black text-xs rounded-xl hover:bg-blue-600 transition-all shadow-lg shadow-blue-100 active:scale-95 disabled:opacity-50"
                        >
                            Guardar Biometria
                        </button>
                      </div>
                    ) : (
                      <button 
                        onClick={captureSample}
                        disabled={!isReady}
                        className="w-full py-4 bg-[#3b82f6] text-white font-black text-xs rounded-xl hover:bg-blue-600 transition-all shadow-lg shadow-blue-100 active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2 uppercase font-black"
                      >
                        <UserCheck className="w-5 h-5" /> Iniciar Login Facial
                      </button>
                    )}
                </div>
                
                <button 
                    onClick={onClose}
                    className="w-full py-4 bg-[#6b7280] text-white font-black text-xs rounded-xl hover:bg-gray-600 transition-all shadow-lg shadow-gray-100 active:scale-95"
                >
                    Cancelar
                </button>
            </div>
        </div>
      </div>
    </div>
  );
}
