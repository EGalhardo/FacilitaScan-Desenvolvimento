import React, { useState, useEffect } from 'react';
import { 
  ShieldAlert, 
  Key, 
  Copy, 
  Download, 
  Send, 
  CheckCircle2, 
  Plus,
  MessageCircle,
  Mail,
  ArrowRight,
  Upload,
  Globe,
  WifiOff,
  Building,
  CreditCard,
  User,
  X,
  FileCheck
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useTranslation } from 'react-i18next';
import { generateDeviceFingerprint, generateLicenseRequest, activateLicense, clearLicense } from '../lib/license';

interface LicenseGateProps {
  onValidated: () => void;
  onAdminClick?: () => void;
}

export function LicenseGate({ onValidated, onAdminClick }: LicenseGateProps) {
  const { t } = useTranslation();
  const [showModal, setShowModal] = useState(false);
  const [step, setStep] = useState(1);
  const [deviceId, setDeviceId] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    plan: 'Pro',
    payment: 'Multicaixa Express'
  });
  const [requestFile, setRequestFile] = useState<string | null>(null);
  const [isActivating, setIsActivating] = useState(false);

  useEffect(() => {
    setDeviceId(generateDeviceFingerprint());
  }, []);

  const handleCopyId = () => {
    navigator.clipboard.writeText(deviceId);
    alert(t('license.gate.copyIdSuccess'));
  };

  const handleGenerateRequest = () => {
    if (!formData.name) return alert(t('license.modal.errorName'));
    
    const encRequest = generateLicenseRequest(formData.name, formData.plan);
    setRequestFile(encRequest);
    
    // Download do arquivo .enc
    const blob = new Blob([encRequest], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pedido_${new Date().toISOString().slice(0,10)}_${deviceId.slice(-6)}.enc`;
    a.click();
    
    setStep(2);
  };

  const handleFileActivate = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setIsActivating(true);
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        if (activateLicense(content)) {
          setTimeout(() => {
            onValidated();
          }, 1500);
        } else {
          setIsActivating(false);
        }
      };
      reader.readAsText(file);
    }
  };

  return (
    <div className="fixed inset-0 bg-blue-600 flex items-center justify-center p-4 z-[9999]">
      <div className="absolute inset-0 opacity-20 pointer-events-none">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-white rounded-full blur-[120px] -mr-64 -mt-64" />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-blue-900 rounded-full blur-[120px] -ml-64 -mb-64" />
      </div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-lg max-h-[90vh] bg-white rounded-[40px] shadow-2xl overflow-y-auto custom-scrollbar relative"
      >
        <div className="p-8 md:p-12 text-center">
          <div className="w-20 h-20 bg-blue-50 rounded-[24px] flex items-center justify-center mx-auto mb-8 text-blue-600 relative">
             <div className="absolute inset-0 bg-blue-600 rounded-[24px] blur-xl opacity-20 animate-pulse" />
             <Key className="w-10 h-10 relative z-10" />
          </div>

          <h2 className="text-3xl font-black text-gray-900 leading-tight">{t('license.gate.title')}</h2>
          <p className="text-gray-400 font-medium mt-3 px-6">
            {t('license.gate.subtitle')}
          </p>

          <div className="mt-10 mb-8 p-6 bg-gray-50 rounded-3xl border border-gray-100 flex flex-col items-center gap-2 group relative">
             <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{t('license.gate.deviceId')}</p>
             <p className="text-sm font-black text-gray-900 font-mono tracking-tighter">{deviceId}</p>
             <button 
                onClick={handleCopyId}
                className="absolute right-4 top-1/2 -translate-y-1/2 p-2 text-gray-300 hover:text-blue-600 transition-colors"
                title={t('license.gate.copyId')}
             >
                <Copy className="w-4 h-4" />
             </button>
          </div>

          <div className="flex flex-col gap-3 mt-10">
            <button 
              onClick={() => setShowModal(true)}
              className="w-full py-5 bg-blue-600 text-white font-black rounded-2xl hover:bg-blue-700 shadow-lg shadow-blue-100 transition-all flex items-center justify-center gap-3 active:scale-95"
            >
              {t('license.gate.startActivation')}
            </button>

            <div className="relative py-2">
              <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-gray-100"></div></div>
              <div className="relative flex justify-center text-[10px] uppercase font-black text-gray-300 bg-white px-4">{t('license.gate.or')}</div>
            </div>

            <button 
              onClick={() => { setShowModal(true); setStep(3); }}
              className="w-full py-5 bg-white border-2 border-gray-100 text-gray-900 font-black rounded-2xl hover:border-blue-600 hover:text-blue-600 transition-all flex items-center justify-center gap-3 active:scale-95"
            >
              <Upload className="w-5 h-5" /> {t('license.gate.activateFile')}
            </button>
          </div>

          <p className="mt-8 text-xs font-bold text-gray-400">
            {t('license.gate.noLicense')} <button className="text-blue-600 hover:underline">{t('license.gate.contactAdmin')}</button>
          </p>

          {onAdminClick && (
            <div className="flex flex-col items-center gap-2 mt-6">
              <button 
                onClick={onAdminClick}
                className="text-[10px] text-gray-300 hover:text-gray-500 font-bold uppercase tracking-tighter"
              >
                {t('license.gate.adminAccess')}
              </button>
              <button 
                onClick={clearLicense}
                className="text-[10px] text-red-400 hover:text-red-500 font-bold uppercase tracking-tighter mt-1"
              >
                {t('license.gate.resetLicense')}
              </button>
            </div>
          )}
        </div>
      </motion.div>

      {/* Activation Modal */}
      <AnimatePresence>
        {showModal && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-gray-900/40 backdrop-blur-md flex items-center justify-center p-4 z-[10000]"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-white w-full max-w-2xl max-h-[90vh] rounded-[32px] shadow-2xl overflow-hidden relative flex flex-col"
            >
              <button 
                onClick={() => setShowModal(false)}
                className="absolute right-6 top-6 p-2 text-gray-400 hover:text-gray-600 bg-gray-50 rounded-full transition-all z-20"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="p-8 border-b border-gray-50 bg-gray-50/50 shrink-0">
                 <h2 className="text-2xl font-black text-gray-900">{t('license.modal.title')}</h2>
                 <p className="text-sm font-black text-blue-600 mt-1 uppercase tracking-wider">{t('nav.settings.changeLanguage.activate') || 'Ativar'}</p>
              </div>

              {/* Content (Scrollable) */}
              <div className="p-8 flex-1 overflow-y-auto custom-scrollbar">
                <div className="bg-blue-600 p-6 rounded-3xl flex items-center gap-5 mb-8 shadow-lg shadow-blue-100">
                  <div className="w-14 h-14 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center text-white shrink-0">
                    <ShieldAlert className="w-8 h-8" />
                  </div>
                  <div>
                    <h4 className="text-lg font-black text-white leading-none">{t('license.modal.offlineProcess')}</h4>
                    <p className="text-xs font-medium text-blue-100 mt-2">{t('license.modal.offlineDesc')}</p>
                  </div>
                </div>

                <div className="bg-gray-50 p-6 rounded-3xl mb-8 flex flex-col items-center gap-2 border border-gray-100 group relative">
                   <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest leading-none">{t('license.gate.deviceId')}</p>
                   <div className="flex items-center gap-3">
                     <p className="text-base font-black text-gray-900 font-mono tracking-tight">{deviceId}</p>
                     <button 
                        onClick={handleCopyId}
                        className="text-gray-300 hover:text-blue-500 transition-colors"
                     >
                        <Copy className="w-4 h-4" />
                     </button>
                   </div>
                </div>

                {/* Stepper */}
                <div className="flex items-center justify-center gap-4 mb-10 px-8">
                   {[1, 2, 3].map((s) => (
                     <React.Fragment key={s}>
                       <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-black transition-all ${
                         step >= s ? 'bg-blue-600 text-white shadow-lg shadow-blue-100' : 'bg-gray-100 text-gray-400'
                       }`}>
                         {step > s ? <CheckCircle2 className="w-5 h-5" /> : s}
                       </div>
                       {s < 3 && <div className={`flex-1 h-0.5 transition-all ${step > s ? 'bg-blue-600' : 'bg-gray-100'}`} />}
                     </React.Fragment>
                   ))}
                </div>

                <div className="min-h-[300px]">
                  {step === 1 && (
                    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-8">
                      {/* Plan Information Cards */}
                      <div className="space-y-4">
                        <h3 className="font-black text-gray-900 flex items-center gap-2">
                          <Building className="w-5 h-5 text-blue-600" />
                          {t('license.modal.plansTitle')}
                        </h3>
                        <div className="grid grid-cols-1 gap-3">
                          <div 
                            onClick={() => setFormData({...formData, plan: 'Basico'})}
                            className={`p-4 rounded-2xl flex justify-between items-center group transition-all cursor-pointer ${
                              formData.plan === 'Basico' ? 'bg-blue-600 text-white shadow-lg shadow-blue-100' : 'bg-blue-50 border border-blue-100 hover:bg-blue-100'
                            }`}
                          >
                            <div>
                              <p className="text-xs font-black uppercase opacity-60">{t('plans.basic')}</p>
                              <p className="text-lg font-black tracking-tight">45.000 Kz <span className="text-[10px] opacity-60 font-medium">/{t('dashboard.month')}</span></p>
                              <p className="text-[10px] font-bold mt-1">100 {t('dashboard.extractions')} • 10 {t('dashboard.totalModels')} • 1 PC</p>
                            </div>
                            <CheckCircle2 className={`w-6 h-6 transition-opacity ${formData.plan === 'Basico' ? 'opacity-100' : 'opacity-20 group-hover:opacity-100'}`} />
                          </div>
                          
                          <div 
                            onClick={() => setFormData({...formData, plan: 'Pro'})}
                            className={`p-4 rounded-2xl flex justify-between items-center group transition-all cursor-pointer relative overflow-hidden ${
                              formData.plan === 'Pro' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-100' : 'bg-indigo-50 border border-indigo-100 hover:bg-indigo-100'
                            }`}
                          >
                            <div className="absolute top-0 right-0 py-1 px-3 bg-amber-400 text-white text-[8px] font-black uppercase rounded-bl-xl">{t('license.modal.mostPopular')}</div>
                            <div>
                              <p className="text-xs font-black uppercase opacity-60">Pro</p>
                              <p className="text-lg font-black tracking-tight">120.000 Kz <span className="text-[10px] opacity-60 font-medium">/{t('dashboard.month')}</span></p>
                              <p className="text-[10px] font-bold mt-1">600 {t('dashboard.extractions')} • 40 {t('dashboard.totalModels')} • 5 PCs • Facial</p>
                            </div>
                            <CheckCircle2 className={`w-6 h-6 transition-opacity ${formData.plan === 'Pro' ? 'opacity-100' : 'opacity-20 group-hover:opacity-100'}`} />
                          </div>

                          <div 
                            onClick={() => setFormData({...formData, plan: 'Empresarial'})}
                            className={`p-4 rounded-2xl flex justify-between items-center group transition-all cursor-pointer ${
                              formData.plan === 'Empresarial' ? 'bg-[#4F39F6] text-white shadow-lg shadow-blue-200' : 'bg-slate-50 border border-slate-200 hover:bg-slate-100'
                            }`}
                          >
                            <div>
                              <p className="text-xs font-black uppercase opacity-60">{t('plans.enterprise')}</p>
                              <p className="text-lg font-black tracking-tight">350.000 Kz <span className="text-[10px] opacity-60 font-medium">/{t('dashboard.month')}</span></p>
                              <p className="text-[10px] font-bold mt-1">3.000 {t('dashboard.extractions')} • 200 {t('dashboard.totalModels')} • 10 PCs • API</p>
                            </div>
                            <CheckCircle2 className={`w-6 h-6 transition-opacity ${formData.plan === 'Empresarial' ? 'opacity-100' : 'opacity-20 group-hover:opacity-100'}`} />
                          </div>
                        </div>
                      </div>

                      {/* Payment Account Details */}
                      <div className="bg-amber-50 border border-amber-100 p-6 rounded-[32px] space-y-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-amber-100 rounded-xl flex items-center justify-center text-amber-600">
                            <CreditCard className="w-6 h-6" />
                          </div>
                          <div>
                            <h4 className="text-sm font-black text-amber-900 leading-none">{t('license.modal.paymentTitle')}</h4>
                            <p className="text-[10px] font-bold text-amber-700 mt-1 uppercase">{t('license.modal.paymentDesc')}</p>
                          </div>
                        </div>
                        
                        <div className="space-y-2 bg-white/50 p-4 rounded-2xl border border-amber-200/50">
                          <div className="flex justify-between items-center">
                            <p className="text-[10px] font-black text-amber-800 uppercase leading-none">{t('license.modal.afrimoney')}</p>
                            <button 
                              onClick={() => { navigator.clipboard.writeText('951006421'); alert(t('license.modal.copySuccess')); }}
                              className="text-[10px] font-black text-amber-600 hover:underline"
                            >
                              {t('license.modal.copy')}
                            </button>
                          </div>
                          <p className="text-xs font-mono font-black text-gray-900">951006421</p>
                          <p className="text-[9px] font-bold text-amber-700">{t('license.modal.beneficiary')}</p>
                        </div>
                      </div>

                      <div className="relative py-2">
                         <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-gray-100"></div></div>
                         <div className="relative flex justify-center text-[10px] uppercase font-black text-gray-300 bg-white px-4 tracking-widest">{t('license.gate.startActivation')}</div>
                      </div>

                      <h3 className="font-black text-gray-900 flex items-center gap-2">
                        <span className="w-6 h-6 bg-blue-600 text-white rounded-full text-[10px] flex items-center justify-center">1</span>
                        {t('license.modal.step1')}
                      </h3>
                      
                      <div className="space-y-4">
                        <div className="space-y-1.5">
                           <label className="text-xs font-black text-gray-500 uppercase">{t('license.modal.fullName')}</label>
                           <input 
                             type="text" 
                             value={formData.name}
                             onChange={e => setFormData({...formData, name: e.target.value})}
                             placeholder={t('license.modal.fullNamePlaceholder')}
                             className="w-full px-5 py-4 bg-white border-2 border-gray-100 rounded-2xl font-bold focus:border-blue-600 outline-none transition-all"
                           />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                           <div className="space-y-1.5">
                              <label className="text-xs font-black text-gray-500 uppercase">{t('license.modal.plan')}</label>
                              <select 
                                value={formData.plan}
                                onChange={e => setFormData({...formData, plan: e.target.value})}
                                className="w-full px-5 py-4 bg-white border-2 border-gray-100 rounded-2xl font-bold focus:border-blue-600 outline-none transition-all appearance-none"
                              >
                                <option value="Basico">{t('plans.basic')} - 45.000 Kz</option>
                                <option value="Pro">Pro - 120.000 Kz</option>
                                <option value="Empresarial">{t('plans.enterprise')} - 350.000 Kz</option>
                              </select>
                           </div>
                           <div className="space-y-1.5">
                              <label className="text-xs font-black text-gray-500 uppercase">{t('license.modal.paymentMethod')}</label>
                              <select 
                                value={formData.payment}
                                onChange={e => setFormData({...formData, payment: e.target.value})}
                                className="w-full px-5 py-4 bg-white border-2 border-gray-100 rounded-2xl font-bold focus:border-blue-600 outline-none transition-all appearance-none"
                              >
                                <option>Multicaixa Express</option>
                                <option>Unitel Money</option>
                                <option>Afrimoney</option>
                                <option>Transferência Bancária</option>
                              </select>
                           </div>
                        </div>
                      </div>

                      <button 
                        onClick={handleGenerateRequest}
                        className="w-full py-5 bg-blue-600 text-white font-black rounded-2xl hover:bg-blue-700 shadow-lg shadow-blue-100 transition-all flex items-center justify-center gap-3 mt-6"
                      >
                        <Download className="w-5 h-5" /> {t('license.modal.generateRequest')}
                      </button>

                      <div className="pt-4 border-t border-gray-100">
                        <button 
                          onClick={() => setStep(3)}
                          className="w-full py-4 text-xs font-black text-blue-600 hover:bg-blue-50 rounded-xl transition-all uppercase tracking-widest"
                        >
                          {t('license.modal.hasFile')}
                        </button>
                      </div>
                    </motion.div>
                  )}

                  {step === 2 && (
                    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-6">
                      <h3 className="font-black text-gray-900 flex items-center gap-2">
                        <span className="w-6 h-6 bg-blue-600 text-white rounded-full text-[10px] flex items-center justify-center">2</span>
                        {t('license.modal.step2')}
                      </h3>

                      <div className="p-6 bg-green-50 rounded-2xl border-2 border-green-100">
                        <div className="flex items-center gap-3 text-green-700 font-bold mb-2">
                           <CheckCircle2 className="w-5 h-5" /> {t('license.modal.requestSuccess')}
                        </div>
                        <p className="text-xs text-green-600 font-medium italic">{t('license.modal.requestHint')}</p>
                      </div>

                      <div className="bg-blue-50 border border-blue-100 p-6 rounded-[32px] space-y-4">
                        <h4 className="text-sm font-black text-blue-900 flex items-center gap-2">
                          <MessageCircle className="w-5 h-5" /> {t('license.modal.instructionsTitle')}
                        </h4>
                        
                        <div className="space-y-4">
                          <div className="flex gap-3">
                            <div className="w-6 h-6 bg-blue-600 text-white rounded-full text-[10px] font-black flex items-center justify-center shrink-0 mt-0.5 shadow-sm">1</div>
                            <div>
                               <p className="text-xs text-blue-800 font-black">{t('license.modal.instr1')}</p>
                               <p className="text-[10px] text-blue-600 font-medium mt-1">{t('license.modal.instr1Sub')}</p>
                            </div>
                          </div>

                          <div className="flex gap-3">
                            <div className="w-6 h-6 bg-blue-600 text-white rounded-full text-[10px] font-black flex items-center justify-center shrink-0 mt-0.5 shadow-sm">2</div>
                            <div>
                               <p className="text-xs text-blue-800 font-black">{t('license.modal.instr2')}</p>
                               <p className="text-[10px] text-blue-600 font-medium mt-1">{t('license.modal.instr2Sub')}</p>
                            </div>
                          </div>

                          <div className="flex gap-3">
                            <div className="w-6 h-6 bg-blue-600 text-white rounded-full text-[10px] font-black flex items-center justify-center shrink-0 mt-0.5 shadow-sm">3</div>
                            <div>
                               <p className="text-xs text-blue-800 font-black">{t('license.modal.instr3')}</p>
                               <p className="text-[10px] text-blue-600 font-medium mt-1">{t('license.modal.instr3Sub')}</p>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="flex gap-4">
                        <button 
                          onClick={() => window.open('https://wa.me/244951006421', '_blank')}
                          className="flex-1 py-4 bg-green-500 text-white font-black rounded-2xl hover:bg-green-600 transition-all flex items-center justify-center gap-3 shadow-lg shadow-green-100"
                        >
                           <MessageCircle className="w-5 h-5" /> {t('license.modal.sendWhatsapp')}
                        </button>
                        <button className="flex-1 py-4 bg-gray-900 text-white font-black rounded-2xl hover:bg-black transition-all flex items-center justify-center gap-3 shadow-lg shadow-gray-100">
                           <Mail className="w-5 h-5" /> {t('license.modal.sendEmail')}
                        </button>
                      </div>

                      <button 
                        onClick={() => setStep(3)}
                        className="w-full py-5 bg-gray-900 text-white font-black rounded-2xl hover:bg-black transition-all flex items-center justify-center gap-3"
                      >
                        {t('license.modal.receivedLicense')} <ArrowRight className="w-5 h-5" />
                      </button>
                    </motion.div>
                  )}

                  {step === 3 && (
                    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-6 pb-8 text-center">
                       <h3 className="font-black text-gray-900 flex items-center gap-2 text-left">
                        <span className="w-6 h-6 bg-blue-600 text-white rounded-full text-[10px] flex items-center justify-center">3</span>
                        {t('license.modal.step3')}
                      </h3>

                      <p className="text-sm font-bold text-gray-500 text-left">{t('license.modal.importSubtitle')}</p>

                      <div className="border-2 border-dashed border-gray-100 rounded-[32px] p-12 flex flex-col items-center justify-center group hover:border-blue-300 transition-all cursor-pointer bg-gray-50/50 relative">
                        <input type="file" accept=".lic" onChange={handleFileActivate} className="absolute inset-0 opacity-0 cursor-pointer" />
                        <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center text-blue-600 mb-4 shadow-sm group-hover:scale-110 transition-all">
                           <Upload className="w-8 h-8" />
                        </div>
                        <p className="font-black text-gray-900">{t('license.modal.clickToSelect')}</p>
                        <p className="text-xs font-bold text-gray-400 mt-1 uppercase tracking-tighter">{t('license.modal.licFiles')}</p>
                      </div>

                      <button className={`w-full py-5 font-black rounded-2xl transition-all flex items-center justify-center gap-3 ${
                        isActivating ? 'bg-green-500 text-white animate-pulse' : 'bg-green-100 text-green-600'
                      }`}>
                         {isActivating ? (
                            <> <CheckCircle2 className="w-5 h-5" /> {t('license.modal.validating')} </>
                         ) : (
                            <> <FileCheck className="w-5 h-5" /> {t('license.modal.activateAction')} </>
                         )}
                      </button>
                    </motion.div>
                  )}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
