/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';

export default function Splash({ onComplete }: { onComplete: () => void }) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const duration = 8000;
    const interval = 50;
    const increment = (interval / duration) * 100;
    
    const timer = setInterval(() => {
      setProgress(prev => {
        if (prev + increment >= 100) {
          clearInterval(timer);
          setTimeout(onComplete, 500);
          return 100;
        }
        return prev + increment;
      });
    }, interval);

    return () => clearInterval(timer);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-[9999] bg-white flex items-center justify-center">
      <div className="w-full max-w-xs px-6 text-center">
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          <div className="mx-auto">
            <img 
              src="https://i.postimg.cc/jdtbwWnP/Icone-de-scanner-minimalista-em-vetor-novo.png" 
              alt="Facilita Scan Logo" 
              className="mx-auto h-24 md:h-28 w-auto object-contain"
            />
          </div>
          
          <div>
            <h1 className="text-2xl font-bold text-blue-600 mb-1">FacilitaScan</h1>
            <p className="text-sm text-gray-500 font-medium">Facilitando a sua vida com segurança</p>
          </div>

          <div className="space-y-3">
            <p className="text-gray-900 font-bold">Carregando…</p>
            <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden">
              <motion.div 
                className="h-full bg-gradient-to-r from-blue-600 to-indigo-600"
                style={{ width: `${progress}%` }}
              />
            </div>
            <p className="text-xs text-gray-400 font-bold">{Math.round(progress)}%</p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
