/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  PlusCircle, 
  FileSearch, 
  Files, 
  User, 
  LogOut, 
  Bell, 
  Settings,
  HelpCircle,
  Video,
  Info,
  Menu,
  Sun,
  Moon,
  ShieldCheck,
  X,
  Globe,
  ChevronDown
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useTranslation } from 'react-i18next';
import { UserProfile, AppNotification } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  activePage: string;
  onNavigate: (page: string) => void;
  profile: UserProfile;
  notifications: AppNotification[];
  extractionCount: number;
  totalLimit: number;
  theme: string;
  onToggleTheme: () => void;
}

export default function Layout({ 
  children, 
  activePage, 
  onNavigate, 
  profile, 
  notifications,
  extractionCount,
  totalLimit,
  theme,
  onToggleTheme
}: LayoutProps) {
  const { t, i18n } = useTranslation();
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [isLangMenuOpen, setIsLangMenuOpen] = useState(false);
  const unreadCount = notifications.filter(n => !n.read).length;

  const languages = [
    { id: 'pt', label: 'Português(Angola)', flag: '🇦🇴' },
    { id: 'en', label: 'English', flag: '🇺🇸' },
    { id: 'fr', label: 'Français', flag: '🇫🇷' },
  ];

  const currentLangLabel = languages.find(l => l.id === i18n.language.split('-')[0])?.label || 'Português(Angola)';

  const navItems = [
    { id: 'dashboard', label: t('nav.dashboard'), icon: LayoutDashboard },
    { id: 'create-model', label: t('nav.createModel'), icon: PlusCircle },
    { id: 'extract', label: t('nav.extract'), icon: FileSearch },
    { id: 'files', label: t('nav.files'), icon: Files },
    { id: 'profile', label: t('nav.profile'), icon: User },
    { id: 'admin', label: t('nav.admin'), icon: ShieldCheck },
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col md:flex-row">
      {/* AppBar */}
      <header className="bg-white border-b border-gray-200 h-16 fixed top-0 w-full z-50 px-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 flex items-center justify-center">
            <img 
              src="https://i.postimg.cc/jdtbwWnP/Icone-de-scanner-minimalista-em-vetor-novo.png" 
              alt="Logo" 
              className="h-8 w-auto object-contain"
            />
          </div>
          <div className="flex flex-col">
            <span className="text-xl font-bold text-blue-600">FacilitaScan</span>
            <span className="text-[10px] text-gray-500 font-medium hidden md:block">Facilitando a sua vida com segurança</span>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          {/* Language Selector */}
          <div className="relative hidden md:block">
            <button 
              onClick={() => setIsLangMenuOpen(!isLangMenuOpen)}
              className="flex items-center space-x-2 px-3 py-2 rounded-xl text-gray-600 hover:bg-gray-50 border border-transparent hover:border-gray-200 transition-all"
            >
              <Globe className="w-4 h-4 text-blue-600" />
              <span className="text-xs font-bold">{languages.find(l => l.id === i18n.language.split('-')[0])?.flag || '🇦🇴'}</span>
              <ChevronDown className={`w-3 h-3 transition-transform ${isLangMenuOpen ? 'rotate-180' : ''}`} />
            </button>

            <AnimatePresence>
              {isLangMenuOpen && (
                <>
                  <div className="fixed inset-0 z-10" onClick={() => setIsLangMenuOpen(false)} />
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95, y: -10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, y: -10 }}
                    className="absolute right-0 mt-2 w-48 bg-white rounded-2xl shadow-xl border border-gray-100 py-2 z-20"
                  >
                    {languages.map((lang) => (
                      <button
                        key={lang.id}
                        onClick={() => {
                          i18n.changeLanguage(lang.id);
                          setIsLangMenuOpen(false);
                        }}
                        className={`flex items-center w-full px-4 py-2 text-sm transition-all ${
                          i18n.language.startsWith(lang.id) 
                            ? 'bg-blue-50 text-blue-600 font-bold' 
                            : 'text-gray-600 hover:bg-gray-50'
                        }`}
                      >
                        <span className="mr-3 text-lg">{lang.flag}</span>
                        {lang.label}
                      </button>
                    ))}
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>

          <button 
            onClick={onToggleTheme}
            className="p-2 rounded-xl text-gray-500 hover:bg-gray-100 transition-colors"
            title={theme === 'dark' ? t('common.lightMode') : t('common.darkMode')}
          >
            {theme === 'dark' ? <Sun className="w-5 h-5 text-yellow-500" /> : <Moon className="w-5 h-5" />}
          </button>

          <span className="text-xs font-bold text-white bg-blue-600 px-2 py-1 rounded-lg shadow-sm">
            {extractionCount}/{totalLimit >= 999999 ? '∞' : totalLimit}
          </span>
          
          <div className="relative">
            <button 
              onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
              className="w-9 h-9 rounded-full overflow-hidden border border-gray-300 bg-white hover:ring-2 hover:ring-blue-400 focus:outline-none flex items-center justify-center transition-all"
            >
              {profile.avatar ? (
                <img src={profile.avatar} alt="Profile" className="w-full h-full object-cover" />
              ) : (
                <User className="w-5 h-5 text-gray-600" />
              )}
            </button>
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-600 text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-badge-pop shadow-md">
                {unreadCount}
              </span>
            )}

            <AnimatePresence>
              {isProfileMenuOpen && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95, y: -10 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: -10 }}
                  className="absolute right-0 top-full mt-2 w-56 bg-white rounded-xl shadow-xl border border-gray-100 py-1 z-50"
                >
                  <button onClick={() => { onNavigate('profile'); setIsProfileMenuOpen(false); }} className={`flex w-full items-center px-4 py-2.5 text-sm transition-all rounded-lg mx-1 w-[calc(100%-8px)] my-0.5 ${activePage === 'profile' ? 'bg-blue-600 text-white font-bold' : 'text-gray-700 hover:bg-gray-100/50'}`}>
                    <User className={`mr-3 h-4.5 w-4.5 ${activePage === 'profile' ? 'text-white' : 'text-gray-500'}`} /> {t('nav.profile')}
                  </button>
                  <button onClick={() => { onNavigate('notifications'); setIsProfileMenuOpen(false); }} className={`flex w-full items-center px-4 py-2.5 text-sm transition-all rounded-lg mx-1 w-[calc(100%-8px)] my-0.5 justify-between ${activePage === 'notifications' ? 'bg-blue-600 text-white font-bold' : 'text-gray-700 hover:bg-gray-100/50'}`}>
                    <div className="flex items-center">
                      <Bell className={`mr-3 h-4.5 w-4.5 ${activePage === 'notifications' ? 'text-white' : 'text-gray-500'}`} /> {t('nav.notifications')}
                    </div>
                    {unreadCount > 0 && (
                      <span className={`w-5 h-5 text-[10px] font-bold rounded-full flex items-center justify-center ${activePage === 'notifications' ? 'bg-white text-blue-600' : 'bg-blue-600 text-white'}`}>
                        {unreadCount}
                      </span>
                    )}
                  </button>
                  <button onClick={() => { onNavigate('plans'); setIsProfileMenuOpen(false); }} className={`flex w-full items-center px-4 py-2.5 text-sm transition-all rounded-lg mx-1 w-[calc(100%-8px)] my-0.5 ${activePage === 'plans' ? 'bg-blue-600 text-white font-bold' : 'text-gray-700 hover:bg-gray-100/50'}`}>
                    <PlusCircle className={`mr-3 h-4.5 w-4.5 ${activePage === 'plans' ? 'text-white' : 'text-gray-500'}`} /> {t('dashboard.subscription')}
                  </button>
                  <button onClick={() => { onNavigate('settings'); setIsProfileMenuOpen(false); }} className={`flex w-full items-center px-4 py-2.5 text-sm transition-all rounded-lg mx-1 w-[calc(100%-8px)] my-0.5 ${activePage === 'settings' ? 'bg-blue-600 text-white font-bold' : 'text-gray-700 hover:bg-gray-100/50'}`}>
                    <Settings className={`mr-3 h-4.5 w-4.5 ${activePage === 'settings' ? 'text-white' : 'text-gray-500'}`} /> {t('nav.settings')}
                  </button>
                  <div className="border-t border-gray-100 my-1.5 mx-2" />
                  <button onClick={() => { onNavigate('help'); setIsProfileMenuOpen(false); }} className={`flex w-full items-center px-4 py-2.5 text-sm transition-all rounded-lg mx-1 w-[calc(100%-8px)] my-0.5 ${activePage === 'help' ? 'bg-blue-600 text-white font-bold' : 'text-gray-700 hover:bg-gray-100/50'}`}>
                    <HelpCircle className={`mr-3 h-4.5 w-4.5 ${activePage === 'help' ? 'text-white' : 'text-gray-500'}`} /> {t('dashboard.support.help')}
                  </button>
                  <button onClick={() => { onNavigate('tutorials'); setIsProfileMenuOpen(false); }} className={`flex w-full items-center px-4 py-2.5 text-sm transition-all rounded-lg mx-1 w-[calc(100%-8px)] my-0.5 ${activePage === 'tutorials' ? 'bg-blue-600 text-white font-bold' : 'text-gray-700 hover:bg-gray-100/50'}`}>
                    <Video className={`mr-3 h-4.5 w-4.5 ${activePage === 'tutorials' ? 'text-white' : 'text-gray-500'}`} /> {t('dashboard.support.tutorials')}
                  </button>
                  <button onClick={() => { onNavigate('about'); setIsProfileMenuOpen(false); }} className={`flex w-full items-center px-4 py-2.5 text-sm transition-all rounded-lg mx-1 w-[calc(100%-8px)] my-0.5 ${activePage === 'about' ? 'bg-blue-600 text-white font-bold' : 'text-gray-700 hover:bg-gray-100/50'}`}>
                    <Info className={`mr-3 h-4.5 w-4.5 ${activePage === 'about' ? 'text-white' : 'text-gray-500'}`} /> {t('dashboard.support.title')}
                  </button>
                  <div className="border-t border-gray-100 my-1.5 mx-2" />
                  <button onClick={() => { onNavigate('logout'); setIsProfileMenuOpen(false); }} className="flex w-full items-center px-4 py-2.5 text-sm text-red-600 hover:bg-red-50 transition-all rounded-lg mx-1 w-[calc(100%-8px)] my-0.5">
                    <LogOut className="mr-3 h-4.5 w-4.5 text-red-400" /> {t('nav.logout')}
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </header>

      {/* Sidebar - Desktop */}
      <aside className="hidden md:flex flex-col w-64 bg-white border-r border-gray-200 fixed left-0 top-16 bottom-0 z-40">
        <nav className="flex-1 px-4 py-6 space-y-2">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-300 font-semibold ${
                activePage === item.id 
                  ? 'bg-blue-600 text-white shadow-lg' 
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <item.icon className={`w-5 h-5 ${activePage === item.id ? 'text-white' : 'text-gray-500'}`} />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>
        
        <div className="p-4 border-t border-gray-100">
          <button 
            onClick={() => onNavigate('logout')}
            className="w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-red-600 hover:bg-red-50 transition-all duration-300 font-semibold"
          >
            <LogOut className="w-5 h-5" />
            <span>{t('nav.logout')}</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-4 md:p-8 mt-16 md:ml-64 mb-16 md:mb-0 max-w-7xl mx-auto w-full">
        {children}
      </main>

      {/* Bottom Nav - Mobile */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 h-16 bg-white border-t border-gray-200 z-50 flex items-center justify-around px-2">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onNavigate(item.id)}
            className={`flex flex-col items-center justify-center space-y-1 transition-all duration-300 ${
              activePage === item.id ? 'text-blue-600' : 'text-gray-500'
            }`}
          >
            <item.icon className="w-6 h-6" />
            <span className="text-[10px] font-bold">{item.label.split(' ')[0]}</span>
          </button>
        ))}
      </nav>
    </div>
  );
}
