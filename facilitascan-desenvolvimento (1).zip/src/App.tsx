/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Layout from './components/Layout';
import Splash from './components/Splash';
import Auth from './components/Auth';
import Dashboard from './components/Dashboard';
import CreateModel from './components/CreateModel';
import Extract from './components/Extract';
import FilesView from './components/Files';
import ProfileView from './components/Profile';
import OfflineActivation from './components/OfflineActivation';
import SettingsView from './components/Settings';
import NotificationsView from './components/Notifications';
import { HelpPage, AboutPage, PlansPage, TutorialsPage } from './components/MiscPages';
import { 
  verifyLicense, 
  incrementExtractions,
  clearLicense,
  activateTrial
} from './lib/license';
import { LicenseGate } from './components/LicenseGate';
import { AdminPanel } from './components/AdminPanel';
import { useTranslation } from 'react-i18next';
import { 
  OCRModel, 
  ExtractionResult, 
  UserProfile, 
  AppNotification,
  AppSettings
} from './types';

export default function App() {
  const { t } = useTranslation();
  const INITIAL_PROFILE: UserProfile = {
    firstName: t('profile.firstNamePlaceholder'),
    lastName: t('profile.lastNamePlaceholder'),
    email: 'usuario@ocrstudio.com',
    whatsapp: '',
    companyName: '',
    companyNif: '',
    companyAddress: '',
    plan: 'Gratuito'
  };

  const INITIAL_SETTINGS: AppSettings = {
    language: 'pt',
    theme: 'light',
    timezone: 'UTC+01:00',
    dateFormat: 'DD/MM/AAAA',
    ocr: {
      highQuality: false,
      autoLanguage: true,
      autoCorrection: false,
      preserveFormatting: true
    },
    export: {
      format: 'json',
      delimiter: ';',
      includeHeaders: true
    },
    data: {
      retention: 30,
      saveActivityHistory: true
    }
  };

  const [showSplash, setShowSplash] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [activePage, setActivePage] = useState('dashboard');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAdminView, setIsAdminView] = useState(false);
  const [licenseStatus, setLicenseStatus] = useState(verifyLicense());
  const [accessCode, setAccessCode] = useState<string | null>(localStorage.getItem('accessCode'));
  
  // Sincronizar o estado da licença periodicamente ou em ações importantes
  const updateLicense = () => {
    setLicenseStatus(verifyLicense());
  };

  // Validar licença ao mudar de página
  useEffect(() => {
    updateLicense();
    // Scroll to top on every page change
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [activePage]);

  // Validar licença periodicamente (a cada minuto)
  useEffect(() => {
    const timer = setInterval(updateLicense, 60000);
    return () => clearInterval(timer);
  }, []);

  // Data State
  const [models, setModels] = useState<OCRModel[]>([]);
  const [results, setResults] = useState<ExtractionResult[]>([]);
  const [profile, setProfile] = useState<UserProfile>(INITIAL_PROFILE);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [settings, setSettings] = useState<AppSettings>(INITIAL_SETTINGS);

  // Load data once
  useEffect(() => {
    const savedModels = localStorage.getItem('models');
    if (savedModels) setModels(JSON.parse(savedModels));

    const savedResults = localStorage.getItem('results');
    if (savedResults) setResults(JSON.parse(savedResults));

    const savedProfile = localStorage.getItem('profile');
    if (savedProfile) setProfile(JSON.parse(savedProfile));

    const savedSettings = localStorage.getItem('settings');
    if (savedSettings) setSettings(JSON.parse(savedSettings));

    const savedNotifications = localStorage.getItem('notifications');
    if (savedNotifications) setNotifications(JSON.parse(savedNotifications));
  }, []);

  // Save data on changes
  useEffect(() => {
    if (models.length > 0) localStorage.setItem('models', JSON.stringify(models));
  }, [models]);

  useEffect(() => {
    localStorage.setItem('results', JSON.stringify(results));
  }, [results]);

  useEffect(() => {
    localStorage.setItem('profile', JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem('settings', JSON.stringify(settings));
    if (settings.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('notifications', JSON.stringify(notifications));
  }, [notifications]);

  // Monitorar limites da licença para notificações automáticas
  useEffect(() => {
    // Carregamento inicial de 2 segundos após o splash
    if (!showSplash) {
      setIsLoading(true);
      const timer = setTimeout(() => setIsLoading(false), 2000);
      return () => clearTimeout(timer);
    }
  }, [showSplash]);

  useEffect(() => {
    if (!licenseStatus.valid) return;

    setNotifications(prev => {
      const pending: AppNotification[] = [];

      // Verificação de expiração (Avisar quando faltar 10 dias ou menos)
      if (licenseStatus.expiry) {
        const expiryDate = new Date(licenseStatus.expiry);
        const diffTime = expiryDate.getTime() - Date.now();
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

        if (diffDays > 0 && diffDays <= 10) {
          // ID único para este dia e esta licença para não repetir o aviso no mesmo dia
          const id = `expiry-warn-${licenseStatus.expiry}-${new Date().toISOString().split('T')[0]}`;
          if (!prev.some(n => n.id === id)) {
            pending.push({
              id,
              title: t('notifications.types.expiryWarn.title'),
              message: t('notifications.types.expiryWarn.message', { 
                days: diffDays, 
                unit: diffDays === 1 ? 'dia' : 'dias' 
              }),
              timestamp: Date.now(),
              read: false,
              type: 'warning'
            });
          }
        }
      }

      // Verificação de extrações (Avisar quando restarem 10 ou menos)
      const extractionsLeft = licenseStatus.maxExtractions - licenseStatus.extractionsUsed;
      if (licenseStatus.maxExtractions < 999999 && extractionsLeft >= 0 && extractionsLeft <= 10) {
        // ID muda conforme o número de extrações para atualizar o aviso se o usuário continuar a extrair
        const id = `low-ext-warn-${extractionsLeft}`;
        if (!prev.some(n => n.id === id)) {
          pending.push({
            id,
            title: t('notifications.types.limitWarn.title'),
            message: t('notifications.types.limitWarn.message', { count: extractionsLeft }),
            timestamp: Date.now(),
            read: false,
            type: 'warning'
          });
        }
      }

      if (pending.length === 0) return prev;
      return [...pending, ...prev];
    });
  }, [licenseStatus.extractionsUsed, licenseStatus.expiry, licenseStatus.valid]);

  useEffect(() => {
    if (isAuthenticated && !localStorage.getItem('hasBeenWelcomed')) {
      const welcomeNotif: AppNotification = {
        id: 'welcome-notification',
        title: t('notifications.types.welcome.title'),
        message: t('notifications.types.welcome.message'),
        timestamp: Date.now(),
        read: false,
        type: 'success'
      };
      
      setNotifications(prev => {
        if (prev.some(n => n.id === 'welcome-notification')) return prev;
        return [welcomeNotif, ...prev];
      });
      
      localStorage.setItem('hasBeenWelcomed', 'true');
    }
  }, [isAuthenticated, t]);

  useEffect(() => {
    if (isAuthenticated && !localStorage.getItem('isTrialActivated') && licenseStatus.plan === 'Gratuito') {
      const success = activateTrial();
      if (success) {
        const status = verifyLicense();
        setLicenseStatus(status);
        
        // Notificação de Trial Ativado
        if (status.expiry) {
          const expiryDate = new Date(status.expiry).toLocaleDateString();
          setNotifications(prev => [{
            id: 'trial-activated-' + Date.now(),
            title: t('notifications.types.trialActivated.title'),
            message: t('notifications.types.trialActivated.message', { date: expiryDate }),
            timestamp: Date.now(),
            read: false,
            type: 'success'
          }, ...prev]);
        }
      }
    }
  }, [isAuthenticated, licenseStatus.plan, t]);

  const handleAuth = (code?: string) => {
    if (!accessCode) {
      if (code) {
        localStorage.setItem('accessCode', code);
        setAccessCode(code);
        setIsAuthenticated(true);
      }
    } else {
      // Se não passar código, assumimos que foi autenticação biométrica com sucesso
      if (!code || code === accessCode) {
        setIsAuthenticated(true);
        setActivePage('dashboard');
      } else {
        alert(t('common.invalidCode'));
      }
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setActivePage('dashboard');
  };

  const saveModel = (model: OCRModel) => {
    if (models.length >= licenseStatus.maxModels) {
      alert(`O seu plano (${licenseStatus.plan}) permite no máximo ${licenseStatus.maxModels} modelos. Por favor, remova modelos existentes ou faça o upgrade da sua licença.`);
      return;
    }
    setModels(prev => [...prev, model]);
    setActivePage('dashboard');
    
    setNotifications(prev => [{
      id: Math.random().toString(36).substr(2, 9),
      title: t('notifications.types.modelCreated.title'),
      message: t('notifications.types.modelCreated.message', { name: model.name }),
      timestamp: Date.now(),
      read: false,
      type: 'success'
    }, ...prev]);
  };

  const saveResult = (result: ExtractionResult) => {
    // Agora o incremento é feito separadamente por arquivo em Extract.tsx
    // para garantir que "+2 documentos = +2 extrações"
    setResults(prev => [result, ...prev]);
    
    setNotifications(prev => [{
      id: Math.random().toString(36).substr(2, 9),
      title: t('notifications.types.extractionSuccess.title'),
      message: t('notifications.types.extractionSuccess.message', { name: result.fileName }),
      timestamp: Date.now(),
      read: false,
      type: 'success'
    }, ...prev]);
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const markAllNotificationsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const deleteNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const deleteResult = (id: string) => {
    if (window.confirm(t('common.deleteConfirm'))) {
        setResults(prev => prev.filter(r => r.id !== id));
    }
  };

  const handleExportBackup = () => {
    const backup = {
      models,
      results,
      profile,
      settings,
      exportedAt: Date.now()
    };
    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `facilitascan_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = JSON.parse(event.target?.result as string);
        if (data.models) setModels(data.models);
        if (data.results) setResults(data.results);
        if (data.profile) setProfile(data.profile);
        if (data.settings) setSettings(data.settings);
        alert(t('common.backupSuccess'));
      } catch (err) {
        alert(t('common.backupError'));
      }
    };
    reader.readAsText(file);
  };

  const handleClearData = () => {
    if (window.confirm(t('settings.security.riskText'))) {
        setModels([]);
        setResults([]);
        localStorage.clear();
        location.reload();
    }
  };

  const handleBulkView = (ids: string[]) => {
    alert(t('common.bulkView', { count: ids.length }));
    setActivePage('files');
  };

  const handleBulkExport = (ids: string[]) => {
    const selected = results.filter(r => ids.includes(r.id));
    const blob = new Blob([JSON.stringify(selected, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `export_${ids.length}_files.json`; a.click();
  };

  const handleBulkDelete = (ids: string[], skipConfirm = false) => {
    if (skipConfirm || window.confirm(t('common.bulkDelete', { count: ids.length }))) {
      setResults(prev => prev.filter(r => !ids.includes(r.id)));
    }
  };

  if (showSplash) {
    return <Splash onComplete={() => setShowSplash(false)} />;
  }

  // Admin View takes precedence for management
  if (isAdminView) {
    return <AdminPanel onBack={() => setIsAdminView(false)} />;
  }

  // License check BEFORE auth
  if (!licenseStatus.valid) {
    return (
      <div className="relative">
        <LicenseGate 
          onValidated={() => setLicenseStatus(verifyLicense())} 
          onAdminClick={() => setIsAdminView(true)}
        />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Auth mode={accessCode ? 'login' : 'create'} onAuth={handleAuth} userId={profile.email} />;
  }

  const deleteModel = (id: string) => {
    setModels(prev => prev.filter(m => m.id !== id));
    
    setNotifications(prev => [{
      id: Math.random().toString(36).substr(2, 9),
      title: t('notifications.types.modelDeleted.title'),
      message: t('notifications.types.modelDeleted.message'),
      timestamp: Date.now(),
      read: false,
      type: 'info'
    }, ...prev]);
  };

  const renderPage = () => {
    switch (activePage) {
      case 'dashboard':
        return (
          <Dashboard 
            stats={{
              models: models.length,
              extractions: results.length,
              files: results.length
            }}
            profile={profile}
            licenseStatus={licenseStatus}
            recentFiles={results.slice(0, 5)}
            onNavigate={setActivePage}
            onViewSelected={handleBulkView}
            onExportSelected={handleBulkExport}
            onDeleteSelected={handleBulkDelete}
            onResetLicense={() => {
              console.log('Resetando licença...');
              clearLicense();
            }}
          />
        );
      case 'create-model':
        return <CreateModel onSave={saveModel} />;
      case 'extract':
        return (
          <Extract 
            models={models} 
            onDeleteModel={deleteModel} 
            onExtractionComplete={saveResult}
            onIncrementExtractions={(count) => {
               incrementExtractions(count);
               updateLicense();
            }}
            licenseStatus={licenseStatus}
          />
        );
      case 'files':
        return <FilesView results={results} onDelete={(id) => setResults(prev => prev.filter(r => r.id !== id))} />;
      case 'profile':
        return <ProfileView profile={profile} onUpdate={setProfile} />;
      case 'help':
        return <HelpPage />;
      case 'tutorials':
        return <TutorialsPage />;
      case 'about':
        return <AboutPage />;
      case 'plans':
        return <PlansPage />;
      case 'notifications':
        return (
          <NotificationsView 
            notifications={notifications}
            onMarkRead={markNotificationAsRead}
            onMarkAllRead={markAllNotificationsRead}
            onDelete={deleteNotification}
          />
        );
      case 'settings':
        return (
          <SettingsView 
            settings={settings} 
            onUpdate={setSettings}
            onExportBackup={handleExportBackup}
            onImportBackup={() => {
              const input = document.createElement('input');
              input.type = 'file';
              input.accept = '.json';
              input.onchange = (e) => handleImportBackup(e as any);
              input.click();
            }}
            onClearData={handleClearData}
          />
        );
      case 'offline-activation':
        return <OfflineActivation onActivate={() => setActivePage('dashboard')} />;
      case 'logout':
        handleLogout();
        return null;
      default:
        return (
          <div className="p-10 text-center bg-white rounded-2xl border border-gray-100 shadow-xl max-w-lg mx-auto mt-10">
            <h2 className="text-2xl font-black text-gray-900 mb-2">{t('common.underConstruction.title')}</h2>
            <p className="text-gray-500 mb-6 font-medium">{t('common.underConstruction.subtitle')}</p>
            <button 
                onClick={() => setActivePage('dashboard')}
                className="px-8 py-3 bg-blue-600 text-white rounded-xl font-bold shadow-lg shadow-blue-200"
            >
                {t('common.underConstruction.back')}
            </button>
          </div>
        );
    }
  };

  const handleNavigate = (page: string) => {
    setIsLoading(true);
    setTimeout(() => {
      if (page === 'admin') {
        setIsAdminView(true);
      } else {
        setActivePage(page);
      }
      setIsLoading(false);
    }, 2000);
  };

  const toggleTheme = () => {
    setSettings(prev => ({
      ...prev,
      theme: prev.theme === 'dark' ? 'light' : 'dark'
    }));
  };

  return (
    <>
      <AnimatePresence>
        {isLoading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[9999] bg-white flex flex-col items-center justify-center"
          >
            <div className="relative w-12 h-12">
              <div className="absolute inset-0 border-4 border-gray-100 rounded-full"></div>
              <div className="absolute inset-0 border-4 border-transparent border-t-[#4285F4] rounded-full animate-spin"></div>
            </div>
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.1 }}
              className="mt-4 text-[#5f6368] font-medium text-lg"
            >
              {t('common.loading')}
            </motion.p>
          </motion.div>
        )}
      </AnimatePresence>

      <Layout 
        activePage={activePage} 
        onNavigate={handleNavigate}
        profile={profile}
        notifications={notifications}
        extractionCount={licenseStatus.extractionsUsed}
        totalLimit={licenseStatus.maxExtractions}
        theme={settings.theme}
        onToggleTheme={toggleTheme}
      >
        {renderPage()}
      </Layout>
    </>
  );
}


